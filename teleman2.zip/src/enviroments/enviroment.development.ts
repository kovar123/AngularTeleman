export const environment = {
    googleAiApiKey: 'AIzaSyD-XZY53eApU74AkLfUZPrWfv49geU1dfw',
  };
  