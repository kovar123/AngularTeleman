import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DxDataGridModule, DxFormModule, DxHtmlEditorModule, DxSwitchModule, DxTextBoxModule,DxLookupModule,
  DxButtonModule, DxProgressBarModule
 } from 'devextreme-angular';
import { WebSpeechComponent } from './pages/My/web-speech/web-speech.component';


//import { ModalHelpComponent } from './components/modal-help/modal-help.component';

@NgModule({
  declarations: [WebSpeechComponent],
  imports: [CommonModule,DxDataGridModule, DxFormModule, DxHtmlEditorModule, DxSwitchModule, DxTextBoxModule,DxLookupModule,
      DxButtonModule, DxProgressBarModule  ],
  exports: [ WebSpeechComponent ]
})
export class SharedModule { }
