import { Injectable } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { SpeechSynthesizerService } from '../web-apis/speech-synthesizer.service';
import { ActionStrategy } from './action-strategy';

@Injectable({
  providedIn: 'root',
})
export class ChangeTitleStrategy extends ActionStrategy {
  private title?: Title;

  constructor(private speechSynthesizer: SpeechSynthesizerService) {
    super();
//    this.mapStartSignal.set('en-US', 'perform change title');
    this.mapStartSignal.set('pl-PL', 'tytuł');
    
//    this.mapEndSignal.set('en-US', 'finish change title');
    this.mapEndSignal.set('pl-PL', 'Zakończ zmianę tytułu');
    

//    this.mapInitResponse.set('en-US', 'Please, tell me the new title');
    this.mapInitResponse.set('pl-PL', 'Proszę, podaj nowy tytuł');
    

//    this.mapActionDone.set('en-US', 'Changing title of the Application to');
    this.mapActionDone.set('pl-PL', 'Zmiana tytułu aplikacji na');
  }

  set titleService(title: Title) {
    this.title = title;
  }

  runAction(input: string, language: string): void {
    this.title?.setTitle(input);
    this.speechSynthesizer.speak(
      `${this.mapActionDone.get(language)}: ${input}`,
      language
    );
  }
}
