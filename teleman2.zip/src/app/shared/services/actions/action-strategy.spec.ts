import { ActionStrategy } from './action-strategy';

describe('ActionStrategy', () => {
  it('should create an instance', () => {
    expect(new ActionStrategy()).toBeTruthy();
  });
});
