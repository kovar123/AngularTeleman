import { ActionStrategy } from './action-strategy';
import { Theme } from '../../model/theme';


import { Injectable } from '@angular/core';
import { SpeechSynthesizerService } from '../web-apis/speech-synthesizer.service';
import { StyleManager } from '../style-manager/style-manager';

@Injectable({
  providedIn: 'root',
})
export class ChangeThemeStrategy extends ActionStrategy {
  private mapThemes: Map<string, Theme[]> = new Map<string, Theme[]>();
  private styleManager: StyleManager = new StyleManager();

  constructor(private speechSynthesizer: SpeechSynthesizerService) {
    super();
    
    this.mapStartSignal.set('pl-PL', 'motyw');
    this.mapEndSignal.set('pl-PL', 'Zakończ zmianę motywu');
    this.mapInitResponse.set('pl-PL', 'Proszę, podaj nazwę motywu.');
    this.mapActionDone.set('pl-PL', 'Zmiana motywu aplikacji na');


    this.mapThemes.set('pl-PL', [
      {
        keyword: 'głęboki fiolet',
        href: 'deeppurple-amber.css',
      },
      {
        keyword: 'niebieski',
        href: 'indigo-pink.css',
      },
      {
        keyword: 'różowy',
        href: 'pink-bluegrey.css',
      },
      {
        keyword: 'fioletowy',
        href: 'purple-green.css',
      },
    ]);
  }

  // this.mapStartSignal.set('en-US', 'perform change theme');
  // this.mapEndSignal.set('en-US', 'finish change theme');
  // this.mapInitResponse.set('en-US', 'Please, tell me your theme name.');
  // this.mapActionDone.set('en-US', 'Changing Theme of the Application to');
  // this.mapThemes.set('en-US', [
  //   {
  //     keyword: 'deep purple',
  //     href: 'deeppurple-amber.css',
  //   },
  //   {
  //     keyword: 'indigo',
  //     href: 'indigo-pink.css',
  //   },
  //   {
  //     keyword: 'pink',
  //     href: 'pink-bluegrey.css',
  //   },
  //   {
  //     keyword: 'purple',
  //     href: 'purple-green.css',
  //   },
  // ]);


  runAction(input: string, language: string): void {
    const themes = this.mapThemes.get(language) || [];
    const theme = themes.find((th) => {
      return input.toLocaleLowerCase() === th.keyword;
    });

    if (theme) {
      this.styleManager.removeStyle('theme');
      this.styleManager.setStyle('theme', `assets/theme/${theme.href}`);
      this.speechSynthesizer.speak(
        `${this.mapActionDone.get(language)}: ${theme.keyword}`,
        language
      );
    }
  }
}
