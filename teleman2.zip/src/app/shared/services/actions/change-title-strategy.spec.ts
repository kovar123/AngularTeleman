import { ChangeTitleStrategy } from './change-title-strategy';

describe('ChangeTitleStrategy', () => {
  it('should create an instance', () => {
    expect(new ChangeTitleStrategy()).toBeTruthy();
  });
});
