export const languages = ['pl-PL','en-US', 'es-ES'];
export const defaultLanguage = languages[0];
