import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ProgramTv } from '../../../Services/programTv';
import { TelemanService } from '../../../Services/teleman.service';
import { ValueChangedEvent } from 'devextreme/ui/select_box';
import { KanalTv,DtoUniElement } from '../../../Services/KanalyTv';
import { sortBy, uniqBy } from 'lodash';
import { merge, Observable, of, Subject } from 'rxjs';
import { map, tap } from 'rxjs/operators';

import { DxDataGridComponent } from 'devextreme-angular';
import { defaultLanguage } from '../../../shared/model/languages';
import { ActionContext } from '../../../shared/services/actions/action-context';
import { SpeechRecognizerService } from '../../../shared/services/web-apis/speech-recognizer.service';
import { SpeechSynthesizerService } from '../../../shared/services/web-apis/speech-synthesizer.service';
import notify from 'devextreme/ui/notify';
import { SpeechError } from '../../../shared/model/speech-error';
import { SpeechEvent } from '../../../shared/model/speech-event';
import { SpeechNotification } from '../../../shared/model/speech-notification';
import { WebSpeechComponent } from '../web-speech/web-speech.component';




@Component({
  selector: 'app-tvprogram',
  templateUrl: './tvprogram.component.html',
  styleUrls: ['./tvprogram.component.css'],
  standalone: false,
})

export class TvprogramComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild(DxDataGridComponent, { static: true }) dGrid: DxDataGridComponent | undefined = undefined;
//  @ViewChild(WebSpeechComponent, { static: false }) speech: WebSpeechComponent | undefined = undefined;

currentLanguage: string = defaultLanguage;
    totalTranscript?: string;
    transcript$?: Observable<string>;
    listening$?: Observable<boolean>;
    errorMessage$?: Observable<string>;
    defaultError$ = new Subject<string | undefined>;
  
  kanaly: KanalTv[] = [];
  programs: ProgramTv[] = [];

  listInitialize=true
  typyProgramow:DtoUniElement[]=[]
  typProgramu: string |null =null;

  store: any;
  keyId: any;
  maxValue = 200;
  seconds = 100;
  tvs: any;
  odTeraz: boolean = true;
  totalCount: any;
  idProgramu: number | null=null;
  idGrid: any;

  constructor(private srv: TelemanService,
    private speechRecognizer: SpeechRecognizerService, 
    private actionContext: ActionContext, 
    private speekSrv: SpeechSynthesizerService) {
    srv.GetProgramsList().subscribe((x) => {
      this.kanaly = x;
      this.kanaly.push({id:null,aktywny:true,kod:-1,programNazwa:'-- clear --',myTvNr:-1})
      this.kanaly=sortBy(this.kanaly,"programNazwa")  
    })
  }

  
  ngOnInit() {
    const webSpeechReady = this.speechRecognizer.initialize(this.currentLanguage);
    if (webSpeechReady) {
      this.initRecognition();
      this.start();
    }
  }

  ngAfterViewInit() {
    // Tutaj instancja dataGrid będzie dostępna
    this.refreshData();
    
    if(this.dGrid?.instance){
      this.idGrid=this.dGrid.instance;

    this.actionContext.setGrid(this.dGrid);  
     
    
  }}

  resetGrid() {
    this.idGrid.searchByText('')
 }
 
  filtruj=()=>{
//      this.idGrid.clearFilter();
//      this.idGrid.filter(['id', '=', '1916434'])
      this.idGrid.searchByText('czekola')     
//      .filterValue('1916434')

    }
    


  fillData=(data:ProgramTv[]) =>{

    if(this.listInitialize){
      this.listInitialize=false
    var dat=uniqBy(data,"idKategorii")
    this.typyProgramow = dat.map(item=>({id:item.idKategorii,ids:item.kategoria,text:item.kategoria,disabled:false}))  
    this.typyProgramow.push({id:-1,ids:'',text:"-- clear --",disabled:false})
    this.typyProgramow=sortBy(this.typyProgramow,"text")  
    
    }
    this.tvs = data

  } 

  setFilter=($typ:string)=>{
    if($typ==='-- clear --') this.typProgramu=null
    else
        this.typProgramu=$typ
    this.refreshData()

  }
  
  programChanged($event: ValueChangedEvent) {
    this.idProgramu=$event.value
    this.refreshData()
  }

  refreshData = () => {
    this.srv.GetProgramsQUERY(this.odTeraz,this.typProgramu,this.idProgramu).subscribe((x) =>this.fillData(x));
  };


  format(ratio: any) {
    return `Loading: ${ratio * 100}%`;
  }

  GetMax(x: any): number {
    return x.postep;
  }
  onValueChanged = ($event: ValueChangedEvent) => {
    this.odTeraz = $event.value;
    this.refreshData();
  };

  ngOnDestroy(): void {
    this.stop
 
}

start(): void {
  if (this.speechRecognizer.isListening) {
    this.stop();
    return;
  }
  this.defaultError$.next(undefined);
  this.speechRecognizer.start();
  notify("start","info" )
}

stop(): void {
  this.speechRecognizer.stop();
  this.speechRecognizer.isListening=false;
  notify("stop","warning" )

}


private initRecognition(): void {
  this.transcript$ = this.speechRecognizer.onResult().pipe(
    tap((notification) => {
      this.processNotification(notification);
    }),
    map((notification) => notification.content || '')
  );

  this.listening$ = merge(
    this.speechRecognizer.onStart(),
    this.speechRecognizer.onEnd()
  ).pipe(map((notification) => notification.event === SpeechEvent.Start));

  this.errorMessage$ = merge(
    this.speechRecognizer.onError(),
    this.defaultError$
  ).pipe(
    map((data) => {
      if (data === undefined) {
        return '';
      }
      if (typeof data === 'string') {
        return data;
      }
      let message;
      switch (data.error) {
        case SpeechError.NotAllowed:
          message = `Cannot run the demo.
          Your browser is not authorized to access your microphone.
          Verify that your browser has access to your microphone and try again.`;
          break;
        case SpeechError.NoSpeech:
          message = `No speech has been detected. Please try again.`;
          break;
        case SpeechError.AudioCapture:
          message = `Microphone is not available. Plese verify the connection of your microphone and try again.`;
          break;
        default:
          message = '';
          break;
      }
      return message;
    })
  );
}

// przetwarza iemy strumienia

private processNotification(notification: SpeechNotification<string>): void {
  if (notification.event === SpeechEvent.FinalContent) {
    const message = notification.content?.trim() || '';
    this.actionContext.processMessage(message, this.currentLanguage);
     this.actionContext.runAction(message, this.currentLanguage);
    this.totalTranscript = this.totalTranscript
      ? `${this.totalTranscript}\n${message}`
      : notification.content;
  }
}



}





