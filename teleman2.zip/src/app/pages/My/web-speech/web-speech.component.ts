import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { merge, Observable, of, Subject } from 'rxjs';
import { map, tap } from 'rxjs/operators';

import { SpeechError } from '../../../shared/model/speech-error';
import { SpeechEvent } from '../../../shared/model/speech-event';
import { SpeechRecognizerService } from '../../../shared/services/web-apis/speech-recognizer.service';
import { ActionContext } from '../../../shared/services/actions/action-context';
import { SpeechNotification } from '../../../shared/model/speech-notification';
import { defaultLanguage, languages } from '../../../shared/model/languages';
import notify from 'devextreme/ui/notify';
import { SpeechSynthesizerService } from '../../../shared/services/web-apis/speech-synthesizer.service';
import { DxDataGridComponent } from 'devextreme-angular';



@Component({
  selector: 'speech-comp',
  templateUrl: './web-speech.component.html',
  styleUrls: ['./web-speech.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: false,
  
})
export class WebSpeechComponent implements OnInit {
  languages: string[] = languages;
  currentLanguage: string = defaultLanguage;
  
  totalTranscript?: string;
  transcript$?: Observable<string>;
  listening$?: Observable<boolean>;
  errorMessage$?: Observable<string>;
  defaultError$ = new Subject<string | undefined>;

  constructor(private speechRecognizer: SpeechRecognizerService, private actionContext: ActionContext, private speekSrv: SpeechSynthesizerService)  {


  }

  ngOnInit(): void {
    const webSpeechReady = this.speechRecognizer.initialize(this.currentLanguage);
    if (webSpeechReady) {
      this.initRecognition();
      this.start();

    }else {
      this.errorMessage$ = of('Your Browser is not supported. Please try Google Chrome.');
    }
  }
  


  ngOnDestroy(): void {
      
  }

  start(): void {
    if (this.speechRecognizer.isListening) {
      this.stop();
      return;
    }
    this.defaultError$.next(undefined);
    this.speechRecognizer.start();
    notify("start","info" )
  }

  stop(): void {
    this.speechRecognizer.stop();
    notify("stop","warning" )
  }


  private initRecognition(): void {
    this.transcript$ = this.speechRecognizer.onResult().pipe(
      tap((notification) => {
        this.processNotification(notification);
      }),
      map((notification) => notification.content || '')
    );

    this.listening$ = merge(
      this.speechRecognizer.onStart(),
      this.speechRecognizer.onEnd()
    ).pipe(map((notification) => notification.event === SpeechEvent.Start));

    this.errorMessage$ = merge(
      this.speechRecognizer.onError(),
      this.defaultError$
    ).pipe(
      map((data) => {
        if (data === undefined) {
          return '';
        }
        if (typeof data === 'string') {
          return data;
        }
        let message;
        switch (data.error) {
          case SpeechError.NotAllowed:
            message = `Cannot run the demo.
            Your browser is not authorized to access your microphone.
            Verify that your browser has access to your microphone and try again.`;
            break;
          case SpeechError.NoSpeech:
            message = `No speech has been detected. Please try again.`;
            break;
          case SpeechError.AudioCapture:
            message = `Microphone is not available. Plese verify the connection of your microphone and try again.`;
            break;
          default:
            message = '';
            break;
        }
        return message;
      })
    );
  }

  private processNotification(notification: SpeechNotification<string>): void {
    if (notification.event === SpeechEvent.FinalContent) {
      const message = notification.content?.trim() || '';
      this.actionContext.processMessage(message, this.currentLanguage);

      this.actionContext.runAction(message, this.currentLanguage);
      
      this.totalTranscript = this.totalTranscript
        ? `${this.totalTranscript}\n${message}`
        : notification.content;
    }
  }

  selectLanguage(language:any): void {
    if (this.speechRecognizer.isListening) {
      this.stop();
    }
    this.currentLanguage = language;
    this.speechRecognizer.setLanguage(this.currentLanguage);
  }


  
  public SetGrid=(grid: any):void=>{
         this.actionContext.setGrid(grid);
    
  }

}
