import {
  list_light_default
} from "./chunk-BW76ND5E.js";
import {
  m_grouped_data_converter_mixin_default,
  ui_popup_default
} from "./chunk-6WF2XDOW.js";
import {
  TextEditorButton,
  text_box_default
} from "./chunk-JXQ6JBGW.js";
import {
  DataSource,
  array_store_default,
  data_helper_default,
  query_default
} from "./chunk-VOSGCXDL.js";
import {
  button_default
} from "./chunk-5HHW3WTB.js";
import {
  message_default
} from "./chunk-M7JKWUQP.js";
import {
  getDefaultAlignment,
  locate,
  move,
  position_default
} from "./chunk-QXE45QVL.js";
import {
  ui_widget_default
} from "./chunk-ZEY4S4J4.js";
import {
  CLICK_EVENT_NAME,
  ChildDefaultTemplate,
  FunctionTemplate,
  addNamespace,
  component_registrator_default,
  focused,
  getPublicElement,
  isCommandKeyPressed,
  normalizeKeyName
} from "./chunk-MM4NENTZ.js";
import {
  devices_default,
  ui_errors_default
} from "./chunk-76GCZVPW.js";
import {
  getOuterHeight,
  getOuterWidth,
  renderer_default
} from "./chunk-MU4Z4OEA.js";
import {
  events_engine_default
} from "./chunk-RC2BNL3X.js";
import {
  Deferred,
  compileGetter,
  dom_adapter_default,
  each,
  ensureDefined,
  fromPromise,
  getWindow,
  grep,
  guid_default,
  hasWindow,
  noop,
  splitPair,
  toComparable,
  variable_wrapper_default
} from "./chunk-4BRW6FUL.js";
import {
  errors_default,
  extend,
  isDefined,
  isFunction,
  isObject,
  isPromise,
  isString,
  isWindow
} from "./chunk-UTUFIS2B.js";

// node_modules/devextreme/esm/__internal/ui/editor/m_data_expression.js
var DataExpressionMixin = extend({}, data_helper_default, {
  _dataExpressionDefaultOptions: () => ({
    items: [],
    dataSource: null,
    itemTemplate: "item",
    value: null,
    valueExpr: "this",
    displayExpr: void 0
  }),
  _initDataExpressions() {
    this._compileValueGetter();
    this._compileDisplayGetter();
    this._initDynamicTemplates();
    this._initDataSource();
    this._itemsToDataSource();
  },
  _itemsToDataSource() {
    if (!this.option("dataSource")) {
      this._dataSource = new DataSource({
        store: new array_store_default(this.option("items")),
        pageSize: 0
      });
      this._initDataController();
    }
  },
  _compileDisplayGetter() {
    this._displayGetter = compileGetter(this._displayGetterExpr());
  },
  _displayGetterExpr() {
    return this.option("displayExpr");
  },
  _compileValueGetter() {
    this._valueGetter = compileGetter(this._valueGetterExpr());
  },
  _valueGetterExpr() {
    return this.option("valueExpr") || "this";
  },
  _loadValue(value) {
    const deferred = Deferred();
    value = this._unwrappedValue(value);
    if (!isDefined(value)) {
      return deferred.reject().promise();
    }
    this._loadSingle(this._valueGetterExpr(), value).done((item) => {
      this._isValueEquals(this._valueGetter(item), value) ? deferred.resolve(item) : deferred.reject();
    }).fail(() => {
      deferred.reject();
    });
    this._loadValueDeferred = deferred;
    return deferred.promise();
  },
  _rejectValueLoading() {
    var _this$_loadValueDefer;
    null === (_this$_loadValueDefer = this._loadValueDeferred) || void 0 === _this$_loadValueDefer || _this$_loadValueDefer.reject({
      shouldSkipCallback: true
    });
  },
  _getCurrentValue() {
    return this.option("value");
  },
  _unwrappedValue(value) {
    value = value ?? this._getCurrentValue();
    if (value && this._dataSource && "this" === this._valueGetterExpr()) {
      value = this._getItemKey(value);
    }
    return variable_wrapper_default.unwrap(value);
  },
  _getItemKey(value) {
    const key = this._dataSource.key();
    if (Array.isArray(key)) {
      const result = {};
      for (let i = 0, n = key.length; i < n; i++) {
        result[key[i]] = value[key[i]];
      }
      return result;
    }
    if (key && "object" === typeof value) {
      value = value[key];
    }
    return value;
  },
  _isValueEquals(value1, value2) {
    const dataSourceKey = this._dataSource && this._dataSource.key();
    let result = this._compareValues(value1, value2);
    if (!result && dataSourceKey && isDefined(value1) && isDefined(value2)) {
      if (Array.isArray(dataSourceKey)) {
        result = this._compareByCompositeKey(value1, value2, dataSourceKey);
      } else {
        result = this._compareByKey(value1, value2, dataSourceKey);
      }
    }
    return result;
  },
  _compareByCompositeKey(value1, value2, key) {
    const isObject2 = isObject;
    if (!isObject2(value1) || !isObject2(value2)) {
      return false;
    }
    for (let i = 0, n = key.length; i < n; i++) {
      if (value1[key[i]] !== value2[key[i]]) {
        return false;
      }
    }
    return true;
  },
  _compareByKey(value1, value2, key) {
    const unwrapObservable = variable_wrapper_default.unwrap;
    const valueKey1 = ensureDefined(unwrapObservable(value1[key]), value1);
    const valueKey2 = ensureDefined(unwrapObservable(value2[key]), value2);
    return this._compareValues(valueKey1, valueKey2);
  },
  _compareValues: (value1, value2) => toComparable(value1, true) === toComparable(value2, true),
  _initDynamicTemplates: noop,
  _setCollectionWidgetItemTemplate() {
    this._initDynamicTemplates();
    this._setCollectionWidgetOption("itemTemplate", this.option("itemTemplate"));
  },
  _getCollectionKeyExpr() {
    const valueExpr = this.option("valueExpr");
    const isValueExprField = isString(valueExpr) && "this" !== valueExpr || isFunction(valueExpr);
    return isValueExprField ? valueExpr : null;
  },
  _dataExpressionOptionChanged(args) {
    switch (args.name) {
      case "items":
        this._itemsToDataSource();
        this._setCollectionWidgetOption("items");
        break;
      case "dataSource":
        this._initDataSource();
        break;
      case "itemTemplate":
        this._setCollectionWidgetItemTemplate();
        break;
      case "valueExpr":
        this._compileValueGetter();
        break;
      case "displayExpr":
        this._compileDisplayGetter();
        this._initDynamicTemplates();
        this._setCollectionWidgetOption("displayExpr");
    }
  }
});
var m_data_expression_default = DataExpressionMixin;

// node_modules/devextreme/esm/ui/editor/ui.data_expression.js
var ui_data_expression_default = m_data_expression_default;

// node_modules/devextreme/esm/__internal/ui/drop_down_editor/m_drop_down_button.js
var DROP_DOWN_EDITOR_BUTTON_VISIBLE = "dx-dropdowneditor-button-visible";
var BUTTON_MESSAGE = "dxDropDownEditor-selectLabel";
var DropDownButton = class extends TextEditorButton {
  constructor(name, editor, options) {
    super(name, editor, options);
    this.currentTemplate = null;
  }
  _attachEvents(instance) {
    const {
      editor
    } = this;
    instance.option("onClick", (e) => {
      var _editor$_shouldCallOp;
      if (null !== (_editor$_shouldCallOp = editor._shouldCallOpenHandler) && void 0 !== _editor$_shouldCallOp && _editor$_shouldCallOp.call(editor)) {
        editor._openHandler(e);
        return;
      }
      !editor.option("openOnFieldClick") && editor._openHandler(e);
    });
    events_engine_default.on(instance.$element(), "mousedown", (e) => {
      if (editor.$element().is(".dx-state-focused")) {
        e.preventDefault();
      }
    });
  }
  _create() {
    const {
      editor
    } = this;
    const $element = renderer_default("<div>");
    const options = this._getOptions();
    this._addToContainer($element);
    const instance = editor._createComponent($element, button_default, extend({}, options, {
      elementAttr: {
        "aria-label": message_default.format(BUTTON_MESSAGE)
      }
    }));
    this._legacyRender(editor.$element(), $element, options.visible);
    return {
      $element,
      instance
    };
  }
  _getOptions() {
    const {
      editor
    } = this;
    const visible = this._isVisible();
    const isReadOnly = editor.option("readOnly");
    const options = {
      focusStateEnabled: false,
      hoverStateEnabled: false,
      activeStateEnabled: false,
      useInkRipple: false,
      disabled: isReadOnly,
      visible
    };
    this._addTemplate(options);
    return options;
  }
  _isVisible() {
    const {
      editor
    } = this;
    return super._isVisible() && editor.option("showDropDownButton");
  }
  _legacyRender($editor, $element, isVisible) {
    $editor.toggleClass(DROP_DOWN_EDITOR_BUTTON_VISIBLE, isVisible);
    if ($element) {
      $element.removeClass("dx-button").removeClass("dx-button-mode-contained").addClass("dx-dropdowneditor-button");
    }
  }
  _isSameTemplate() {
    return this.editor.option("dropDownButtonTemplate") === this.currentTemplate;
  }
  _addTemplate(options) {
    if (!this._isSameTemplate()) {
      options.template = this.editor._getTemplateByOption("dropDownButtonTemplate");
      this.currentTemplate = this.editor.option("dropDownButtonTemplate");
    }
  }
  update() {
    const shouldUpdate = super.update();
    if (shouldUpdate) {
      const {
        editor,
        instance
      } = this;
      const $editor = editor.$element();
      const options = this._getOptions();
      null === instance || void 0 === instance || instance.option(options);
      this._legacyRender($editor, null === instance || void 0 === instance ? void 0 : instance.$element(), options.visible);
    }
  }
};

// node_modules/devextreme/esm/__internal/ui/drop_down_editor/m_utils.js
var getElementWidth = function($element) {
  if (hasWindow()) {
    return getOuterWidth($element);
  }
};
var getSizeValue = function(size) {
  if (null === size) {
    size = void 0;
  }
  if ("function" === typeof size) {
    size = size();
  }
  return size;
};

// node_modules/devextreme/esm/__internal/ui/drop_down_editor/m_drop_down_editor.js
var DROP_DOWN_EDITOR_INPUT_WRAPPER = "dx-dropdowneditor-input-wrapper";
var DROP_DOWN_EDITOR_OVERLAY = "dx-dropdowneditor-overlay";
var DROP_DOWN_EDITOR_OVERLAY_FLIPPED = "dx-dropdowneditor-overlay-flipped";
var DROP_DOWN_EDITOR_ACTIVE = "dx-dropdowneditor-active";
var DROP_DOWN_EDITOR_FIELD_CLICKABLE = "dx-dropdowneditor-field-clickable";
var DROP_DOWN_EDITOR_FIELD_TEMPLATE_WRAPPER = "dx-dropdowneditor-field-template-wrapper";
var isIOs = "ios" === devices_default.current().platform;
var DropDownEditor = text_box_default.inherit({
  _supportedKeys() {
    return extend({}, this.callBase(), {
      tab(e) {
        if (!this.option("opened")) {
          return;
        }
        if (!this._popup.getFocusableElements().length) {
          this.close();
          return;
        }
        const $focusableElement = e.shiftKey ? this._getLastPopupElement() : this._getFirstPopupElement();
        if ($focusableElement) {
          events_engine_default.trigger($focusableElement, "focus");
          $focusableElement.select();
        }
        e.preventDefault();
      },
      escape(e) {
        if (this.option("opened")) {
          e.preventDefault();
        }
        this.close();
        return true;
      },
      upArrow(e) {
        if (!isCommandKeyPressed(e)) {
          e.preventDefault();
          e.stopPropagation();
          if (e.altKey) {
            this.close();
            return false;
          }
        }
        return true;
      },
      downArrow(e) {
        if (!isCommandKeyPressed(e)) {
          e.preventDefault();
          e.stopPropagation();
          if (e.altKey) {
            this._validatedOpening();
            return false;
          }
        }
        return true;
      },
      enter(e) {
        if (this.option("opened")) {
          e.preventDefault();
          this._valueChangeEventHandler(e);
        }
        return true;
      }
    });
  },
  _getDefaultButtons() {
    return this.callBase().concat([{
      name: "dropDown",
      Ctor: DropDownButton
    }]);
  },
  _getDefaultOptions() {
    return extend(this.callBase(), {
      value: null,
      onOpened: null,
      onClosed: null,
      opened: false,
      acceptCustomValue: true,
      applyValueMode: "instantly",
      deferRendering: true,
      activeStateEnabled: true,
      dropDownButtonTemplate: "dropDownButton",
      fieldTemplate: null,
      openOnFieldClick: false,
      showDropDownButton: true,
      buttons: void 0,
      dropDownOptions: {
        showTitle: false
      },
      popupPosition: this._getDefaultPopupPosition(),
      onPopupInitialized: null,
      applyButtonText: message_default.format("OK"),
      cancelButtonText: message_default.format("Cancel"),
      buttonsLocation: "default",
      useHiddenSubmitElement: false,
      validationMessagePosition: "auto"
    });
  },
  _useTemplates: () => true,
  _getDefaultPopupPosition(isRtlEnabled) {
    const position = getDefaultAlignment(isRtlEnabled);
    return {
      offset: {
        h: 0,
        v: -1
      },
      my: `${position} top`,
      at: `${position} bottom`,
      collision: "flip flip"
    };
  },
  _defaultOptionsRules() {
    return this.callBase().concat([{
      device(device) {
        const isGeneric = "generic" === device.platform;
        return isGeneric;
      },
      options: {
        popupPosition: {
          offset: {
            v: 0
          }
        }
      }
    }]);
  },
  _inputWrapper() {
    return this.$element().find(`.${DROP_DOWN_EDITOR_INPUT_WRAPPER}`).first();
  },
  _init() {
    this.callBase();
    this._initVisibilityActions();
    this._initPopupInitializedAction();
    this._updatePopupPosition(this.option("rtlEnabled"));
    this._options.cache("dropDownOptions", this.option("dropDownOptions"));
  },
  _updatePopupPosition(isRtlEnabled) {
    const {
      my,
      at
    } = this._getDefaultPopupPosition(isRtlEnabled);
    const currentPosition = this.option("popupPosition");
    this.option("popupPosition", extend({}, currentPosition, {
      my,
      at
    }));
  },
  _initVisibilityActions() {
    this._openAction = this._createActionByOption("onOpened", {
      excludeValidators: ["disabled", "readOnly"]
    });
    this._closeAction = this._createActionByOption("onClosed", {
      excludeValidators: ["disabled", "readOnly"]
    });
  },
  _initPopupInitializedAction() {
    this._popupInitializedAction = this._createActionByOption("onPopupInitialized", {
      excludeValidators: ["disabled", "readOnly"]
    });
  },
  _initMarkup() {
    this._renderSubmitElement();
    this.callBase();
    this.$element().addClass("dx-dropdowneditor");
    this.setAria("role", this._getAriaRole());
  },
  _render() {
    this.callBase();
    this._renderOpenHandler();
    this._attachFocusOutHandler();
    this._renderOpenedState();
  },
  _renderContentImpl() {
    if (!this.option("deferRendering")) {
      this._createPopup();
    }
  },
  _renderInput() {
    this.callBase();
    this._renderTemplateWrapper();
    this._wrapInput();
    this._setDefaultAria();
  },
  _wrapInput() {
    this._$container = this.$element().wrapInner(renderer_default("<div>").addClass(DROP_DOWN_EDITOR_INPUT_WRAPPER)).children().eq(0);
  },
  _getAriaHasPopup: () => "true",
  _getAriaAutocomplete: () => "none",
  _getAriaRole: () => "combobox",
  _setDefaultAria() {
    this.setAria({
      haspopup: this._getAriaHasPopup(),
      autocomplete: this._getAriaAutocomplete(),
      role: this._getAriaRole()
    });
  },
  _readOnlyPropValue() {
    return !this._isEditable() || this.callBase();
  },
  _cleanFocusState() {
    this.callBase();
    if (this.option("fieldTemplate")) {
      this._detachFocusEvents();
    }
  },
  _getFieldTemplate() {
    return this.option("fieldTemplate") && this._getTemplateByOption("fieldTemplate");
  },
  _renderMask() {
    if (this.option("fieldTemplate")) {
      return;
    }
    this.callBase();
  },
  _renderField() {
    const fieldTemplate = this._getFieldTemplate();
    fieldTemplate && this._renderTemplatedField(fieldTemplate, this._fieldRenderData());
  },
  _renderPlaceholder() {
    const hasFieldTemplate = !!this._getFieldTemplate();
    if (!hasFieldTemplate) {
      this.callBase();
    }
  },
  _renderValue() {
    if (this.option("useHiddenSubmitElement")) {
      this._setSubmitValue();
    }
    const promise = this.callBase();
    promise.always(this._renderField.bind(this));
  },
  _getButtonsContainer() {
    const fieldTemplate = this._getFieldTemplate();
    return fieldTemplate ? this._$container : this._$textEditorContainer;
  },
  _renderTemplateWrapper() {
    const fieldTemplate = this._getFieldTemplate();
    if (!fieldTemplate) {
      return;
    }
    if (!this._$templateWrapper) {
      this._$templateWrapper = renderer_default("<div>").addClass(DROP_DOWN_EDITOR_FIELD_TEMPLATE_WRAPPER).prependTo(this.$element());
    }
  },
  _renderTemplatedField(fieldTemplate, data) {
    const isFocused = focused(this._input());
    this._detachKeyboardEvents();
    this._detachFocusEvents();
    this._$textEditorContainer.remove();
    this._$templateWrapper.empty();
    const $templateWrapper = this._$templateWrapper;
    fieldTemplate.render({
      model: data,
      container: getPublicElement($templateWrapper),
      onRendered: () => {
        const isRenderedInRoot = !!this.$element().find($templateWrapper).length;
        if (!isRenderedInRoot) {
          return;
        }
        const $input = this._input();
        if (!$input.length) {
          throw ui_errors_default.Error("E1010");
        }
        this._integrateInput();
        isFocused && events_engine_default.trigger($input, "focus");
      }
    });
  },
  _integrateInput() {
    var _this$option;
    const {
      isValid
    } = this.option();
    this._renderFocusState();
    this._refreshValueChangeEvent();
    this._refreshEvents();
    this._refreshEmptinessEvent();
    this._setDefaultAria();
    this._setFieldAria();
    this._toggleValidationClasses(!isValid);
    null === (_this$option = this.option("_onMarkupRendered")) || void 0 === _this$option || _this$option();
  },
  _refreshEmptinessEvent() {
    events_engine_default.off(this._input(), "input blur", this._toggleEmptinessEventHandler);
    this._renderEmptinessEvent();
  },
  _fieldRenderData() {
    return this.option("value");
  },
  _initTemplates() {
    this._templateManager.addDefaultTemplates({
      dropDownButton: new FunctionTemplate((options) => {
        const $icon = renderer_default("<div>").addClass("dx-dropdowneditor-icon");
        renderer_default(options.container).append($icon);
      })
    });
    this.callBase();
  },
  _renderOpenHandler() {
    const $inputWrapper = this._inputWrapper();
    const eventName = addNamespace(CLICK_EVENT_NAME, this.NAME);
    const openOnFieldClick = this.option("openOnFieldClick");
    events_engine_default.off($inputWrapper, eventName);
    events_engine_default.on($inputWrapper, eventName, this._getInputClickHandler(openOnFieldClick));
    this.$element().toggleClass(DROP_DOWN_EDITOR_FIELD_CLICKABLE, openOnFieldClick);
    if (openOnFieldClick) {
      this._openOnFieldClickAction = this._createAction(this._openHandler.bind(this));
    }
  },
  _attachFocusOutHandler() {
    if (isIOs) {
      this._detachFocusOutEvents();
      events_engine_default.on(this._inputWrapper(), addNamespace("focusout", this.NAME), (event) => {
        const newTarget = event.relatedTarget;
        if (newTarget && this.option("opened")) {
          const isNewTargetOutside = this._isTargetOutOfComponent(newTarget);
          if (isNewTargetOutside) {
            this.close();
          }
        }
      });
    }
  },
  _isTargetOutOfComponent(newTarget) {
    const popupWrapper = this.content ? renderer_default(this.content()).closest(`.${DROP_DOWN_EDITOR_OVERLAY}`) : this._$popup;
    const isTargetOutsidePopup = 0 === renderer_default(newTarget).closest(`.${DROP_DOWN_EDITOR_OVERLAY}`, popupWrapper).length;
    return isTargetOutsidePopup;
  },
  _detachFocusOutEvents() {
    isIOs && events_engine_default.off(this._inputWrapper(), addNamespace("focusout", this.NAME));
  },
  _getInputClickHandler(openOnFieldClick) {
    return openOnFieldClick ? (e) => {
      this._executeOpenAction(e);
    } : () => {
      this._focusInput();
    };
  },
  _openHandler() {
    this._toggleOpenState();
  },
  _executeOpenAction(e) {
    this._openOnFieldClickAction({
      event: e
    });
  },
  _keyboardEventBindingTarget() {
    return this._input();
  },
  _focusInput() {
    if (this.option("disabled")) {
      return false;
    }
    if (this.option("focusStateEnabled") && !focused(this._input())) {
      this._resetCaretPosition();
      events_engine_default.trigger(this._input(), "focus");
    }
    return true;
  },
  _resetCaretPosition() {
    let ignoreEditable = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : false;
    const inputElement = this._input().get(0);
    if (inputElement) {
      const {
        value
      } = inputElement;
      const caretPosition = isDefined(value) && (ignoreEditable || this._isEditable()) ? value.length : 0;
      this._caret({
        start: caretPosition,
        end: caretPosition
      }, true);
    }
  },
  _isEditable() {
    return this.option("acceptCustomValue");
  },
  _toggleOpenState(isVisible) {
    if (!this._focusInput()) {
      return;
    }
    if (!this.option("readOnly")) {
      isVisible = arguments.length ? isVisible : !this.option("opened");
      this.option("opened", isVisible);
    }
  },
  _getControlsAria() {
    return this._popup && this._popupContentId;
  },
  _renderOpenedState() {
    const opened = this.option("opened");
    if (opened) {
      this._createPopup();
    }
    this.$element().toggleClass(DROP_DOWN_EDITOR_ACTIVE, opened);
    this._setPopupOption("visible", opened);
    const arias = {
      expanded: opened,
      controls: this._getControlsAria()
    };
    this.setAria(arias);
    this.setAria("owns", opened ? this._popupContentId : void 0, this.$element());
  },
  _createPopup() {
    if (this._$popup) {
      return;
    }
    this._$popup = renderer_default("<div>").addClass(DROP_DOWN_EDITOR_OVERLAY).appendTo(this.$element());
    this._renderPopup();
    this._renderPopupContent();
    this._setPopupAriaLabel();
  },
  _setPopupAriaLabel() {
    const $overlayContent = this._popup.$overlayContent();
    this.setAria("label", "Dropdown", $overlayContent);
  },
  _renderPopupContent: noop,
  _renderPopup() {
    const popupConfig = extend(this._popupConfig(), this._options.cache("dropDownOptions"));
    delete popupConfig.closeOnOutsideClick;
    this._popup = this._createComponent(this._$popup, ui_popup_default, popupConfig);
    this._popup.on({
      showing: this._popupShowingHandler.bind(this),
      shown: this._popupShownHandler.bind(this),
      hiding: this._popupHidingHandler.bind(this),
      hidden: this._popupHiddenHandler.bind(this),
      contentReady: this._contentReadyHandler.bind(this)
    });
    this._attachPopupKeyHandler();
    this._contentReadyHandler();
    this._setPopupContentId(this._popup.$content());
    this._bindInnerWidgetOptions(this._popup, "dropDownOptions");
  },
  _attachPopupKeyHandler() {
    events_engine_default.on(this._popup.$overlayContent(), addNamespace("keydown", this.NAME), (e) => this._popupKeyHandler(e));
  },
  _popupKeyHandler(e) {
    switch (normalizeKeyName(e)) {
      case "tab":
        this._popupTabHandler(e);
        break;
      case "escape":
        this._popupEscHandler(e);
    }
  },
  _popupTabHandler(e) {
    const $target = renderer_default(e.target);
    const moveBackward = e.shiftKey && $target.is(this._getFirstPopupElement());
    const moveForward = !e.shiftKey && $target.is(this._getLastPopupElement());
    if (moveForward || moveBackward) {
      events_engine_default.trigger(this.field(), "focus");
      e.preventDefault();
    }
  },
  _popupEscHandler() {
    events_engine_default.trigger(this._input(), "focus");
    this.close();
  },
  _setPopupContentId($popupContent) {
    this._popupContentId = `dx-${new guid_default()}`;
    this.setAria("id", this._popupContentId, $popupContent);
  },
  _contentReadyHandler: noop,
  _popupConfig() {
    return {
      onInitialized: this._getPopupInitializedHandler(),
      position: extend(this.option("popupPosition"), {
        of: this.$element()
      }),
      showTitle: this.option("dropDownOptions.showTitle"),
      _ignoreFunctionValueDeprecation: true,
      width: () => getElementWidth(this.$element()),
      height: "auto",
      shading: false,
      hideOnParentScroll: true,
      hideOnOutsideClick: (e) => this._closeOutsideDropDownHandler(e),
      animation: {
        show: {
          type: "fade",
          duration: 0,
          from: 0,
          to: 1
        },
        hide: {
          type: "fade",
          duration: 400,
          from: 1,
          to: 0
        }
      },
      deferRendering: false,
      focusStateEnabled: false,
      showCloseButton: false,
      dragEnabled: false,
      toolbarItems: this._getPopupToolbarItems(),
      onPositioned: this._popupPositionedHandler.bind(this),
      fullScreen: false,
      contentTemplate: null,
      _hideOnParentScrollTarget: this.$element(),
      _wrapperClassExternal: DROP_DOWN_EDITOR_OVERLAY,
      _ignorePreventScrollEventsDeprecation: true
    };
  },
  _popupInitializedHandler: noop,
  _getPopupInitializedHandler() {
    const onPopupInitialized = this.option("onPopupInitialized");
    return (e) => {
      this._popupInitializedHandler(e);
      if (onPopupInitialized) {
        this._popupInitializedAction({
          popup: e.component
        });
      }
    };
  },
  _dimensionChanged() {
    if (hasWindow() && !this.$element().is(":visible")) {
      this.close();
      return;
    }
    this._updatePopupWidth();
  },
  _updatePopupWidth() {
    const popupWidth = getSizeValue(this.option("dropDownOptions.width"));
    if (void 0 === popupWidth) {
      this._setPopupOption("width", () => getElementWidth(this.$element()));
    }
  },
  _popupPositionedHandler(e) {
    var _e$position;
    const {
      labelMode,
      stylingMode
    } = this.option();
    if (!this._popup) {
      return;
    }
    const $popupOverlayContent = this._popup.$overlayContent();
    const isOverlayFlipped = null === (_e$position = e.position) || void 0 === _e$position || null === (_e$position = _e$position.v) || void 0 === _e$position ? void 0 : _e$position.flip;
    const shouldIndentForLabel = "hidden" !== labelMode && "outside" !== labelMode && "outlined" === stylingMode;
    if (e.position) {
      $popupOverlayContent.toggleClass(DROP_DOWN_EDITOR_OVERLAY_FLIPPED, isOverlayFlipped);
    }
    if (isOverlayFlipped && shouldIndentForLabel && this._label.isVisible()) {
      const $label = this._label.$element();
      move($popupOverlayContent, {
        top: locate($popupOverlayContent).top - parseInt($label.css("fontSize"))
      });
    }
  },
  _popupShowingHandler: noop,
  _popupHidingHandler() {
    this.option("opened", false);
  },
  _popupShownHandler() {
    var _this$_validationMess;
    this._openAction();
    null === (_this$_validationMess = this._validationMessage) || void 0 === _this$_validationMess || _this$_validationMess.option("positionSide", this._getValidationMessagePositionSide());
  },
  _popupHiddenHandler() {
    var _this$_validationMess2;
    this._closeAction();
    null === (_this$_validationMess2 = this._validationMessage) || void 0 === _this$_validationMess2 || _this$_validationMess2.option("positionSide", this._getValidationMessagePositionSide());
  },
  _getValidationMessagePositionSide() {
    const validationMessagePosition = this.option("validationMessagePosition");
    if ("auto" !== validationMessagePosition) {
      return validationMessagePosition;
    }
    let positionSide = "bottom";
    if (this._popup && this._popup.option("visible")) {
      const {
        top: myTop
      } = position_default.setup(this.$element());
      const {
        top: popupTop
      } = position_default.setup(this._popup.$content());
      positionSide = myTop + this.option("popupPosition").offset.v > popupTop ? "bottom" : "top";
    }
    return positionSide;
  },
  _closeOutsideDropDownHandler(_ref) {
    let {
      target
    } = _ref;
    const $target = renderer_default(target);
    const dropDownButton = this.getButton("dropDown");
    const $dropDownButton = dropDownButton && dropDownButton.$element();
    const isInputClicked = !!$target.closest(this.$element()).length;
    const isDropDownButtonClicked = !!$target.closest($dropDownButton).length;
    const isOutsideClick = !isInputClicked && !isDropDownButtonClicked;
    return isOutsideClick;
  },
  _clean() {
    delete this._openOnFieldClickAction;
    delete this._$templateWrapper;
    if (this._$popup) {
      this._$popup.remove();
      delete this._$popup;
      delete this._popup;
    }
    this.callBase();
  },
  _setPopupOption(optionName, value) {
    this._setWidgetOption("_popup", arguments);
  },
  _validatedOpening() {
    if (!this.option("readOnly")) {
      this._toggleOpenState(true);
    }
  },
  _getPopupToolbarItems() {
    return "useButtons" === this.option("applyValueMode") ? this._popupToolbarItemsConfig() : [];
  },
  _getFirstPopupElement() {
    return renderer_default(this._popup.getFocusableElements()).first();
  },
  _getLastPopupElement() {
    return renderer_default(this._popup.getFocusableElements()).last();
  },
  _popupToolbarItemsConfig() {
    const buttonsConfig = [{
      shortcut: "done",
      options: {
        onClick: this._applyButtonHandler.bind(this),
        text: this.option("applyButtonText")
      }
    }, {
      shortcut: "cancel",
      options: {
        onClick: this._cancelButtonHandler.bind(this),
        text: this.option("cancelButtonText")
      }
    }];
    return this._applyButtonsLocation(buttonsConfig);
  },
  _applyButtonsLocation(buttonsConfig) {
    const buttonsLocation = this.option("buttonsLocation");
    const resultConfig = buttonsConfig;
    if ("default" !== buttonsLocation) {
      const position = splitPair(buttonsLocation);
      each(resultConfig, (_, element) => {
        extend(element, {
          toolbar: position[0],
          location: position[1]
        });
      });
    }
    return resultConfig;
  },
  _applyButtonHandler() {
    this.close();
    this.option("focusStateEnabled") && this.focus();
  },
  _cancelButtonHandler() {
    this.close();
    this.option("focusStateEnabled") && this.focus();
  },
  _popupOptionChanged(args) {
    const options = ui_widget_default.getOptionsFromContainer(args);
    this._setPopupOption(options);
    const optionsKeys = Object.keys(options);
    if (optionsKeys.includes("width") || optionsKeys.includes("height")) {
      this._dimensionChanged();
    }
  },
  _renderSubmitElement() {
    if (this.option("useHiddenSubmitElement")) {
      this._$submitElement = renderer_default("<input>").attr("type", "hidden").appendTo(this.$element());
    }
  },
  _setSubmitValue() {
    this._getSubmitElement().val(this.option("value"));
  },
  _getSubmitElement() {
    if (this.option("useHiddenSubmitElement")) {
      return this._$submitElement;
    }
    return this.callBase();
  },
  _dispose() {
    this._detachFocusOutEvents();
    this.callBase();
  },
  _optionChanged(args) {
    var _this$_popup;
    switch (args.name) {
      case "width":
      case "height":
        this.callBase(args);
        null === (_this$_popup = this._popup) || void 0 === _this$_popup || _this$_popup.repaint();
        break;
      case "opened":
        this._renderOpenedState();
        break;
      case "onOpened":
      case "onClosed":
        this._initVisibilityActions();
        break;
      case "onPopupInitialized":
        this._initPopupInitializedAction();
        break;
      case "fieldTemplate":
      case "acceptCustomValue":
      case "openOnFieldClick":
        this._invalidate();
        break;
      case "dropDownButtonTemplate":
      case "showDropDownButton":
        this._updateButtons(["dropDown"]);
        break;
      case "dropDownOptions":
        this._popupOptionChanged(args);
        this._options.cache("dropDownOptions", this.option("dropDownOptions"));
        break;
      case "popupPosition":
        break;
      case "deferRendering":
        if (hasWindow()) {
          this._createPopup();
        }
        break;
      case "applyValueMode":
      case "applyButtonText":
      case "cancelButtonText":
      case "buttonsLocation":
        this._setPopupOption("toolbarItems", this._getPopupToolbarItems());
        break;
      case "useHiddenSubmitElement":
        if (this._$submitElement) {
          this._$submitElement.remove();
          this._$submitElement = void 0;
        }
        this._renderSubmitElement();
        break;
      case "rtlEnabled":
        this._updatePopupPosition(args.value);
        this.callBase(args);
        break;
      default:
        this.callBase(args);
    }
  },
  open() {
    this.option("opened", true);
  },
  close() {
    this.option("opened", false);
  },
  field() {
    return getPublicElement(this._input());
  },
  content() {
    return this._popup ? this._popup.content() : null;
  }
});
component_registrator_default("dxDropDownEditor", DropDownEditor);
var m_drop_down_editor_default = DropDownEditor;

// node_modules/devextreme/esm/__internal/ui/drop_down_editor/m_drop_down_list.js
var window = getWindow();
var SEARCH_MODES = ["startswith", "contains", "endwith", "notcontains"];
var useCompositionEvents = "android" !== devices_default.real().platform;
var DropDownList = m_drop_down_editor_default.inherit({
  _supportedKeys() {
    const parent = this.callBase();
    return extend({}, parent, {
      tab(e) {
        if (this._allowSelectItemByTab()) {
          this._saveValueChangeEvent(e);
          const $focusedItem = renderer_default(this._list.option("focusedElement"));
          $focusedItem.length && this._setSelectedElement($focusedItem);
        }
        parent.tab.apply(this, arguments);
      },
      space: noop,
      home: noop,
      end: noop
    });
  },
  _allowSelectItemByTab() {
    return this.option("opened") && "instantly" === this.option("applyValueMode");
  },
  _setSelectedElement($element) {
    const value = this._valueGetter(this._list._getItemData($element));
    this._setValue(value);
  },
  _setValue(value) {
    this.option("value", value);
  },
  _getDefaultOptions() {
    return extend(this.callBase(), extend(ui_data_expression_default._dataExpressionDefaultOptions(), {
      displayValue: void 0,
      searchEnabled: false,
      searchMode: "contains",
      searchTimeout: 500,
      minSearchLength: 0,
      searchExpr: null,
      valueChangeEvent: "input change keyup",
      selectedItem: null,
      noDataText: message_default.format("dxCollectionWidget-noDataText"),
      encodeNoDataText: false,
      onSelectionChanged: null,
      onItemClick: noop,
      showDataBeforeSearch: false,
      grouped: false,
      groupTemplate: "group",
      popupPosition: {
        my: "left top",
        at: "left bottom",
        offset: {
          h: 0,
          v: 0
        },
        collision: "flip"
      },
      wrapItemText: false,
      useItemTextAsTitle: false
    }));
  },
  _defaultOptionsRules() {
    return this.callBase().concat([{
      device: {
        platform: "ios"
      },
      options: {
        popupPosition: {
          offset: {
            v: -1
          }
        }
      }
    }, {
      device: {
        platform: "generic"
      },
      options: {
        buttonsLocation: "bottom center"
      }
    }]);
  },
  _setOptionsByReference() {
    this.callBase();
    extend(this._optionsByReference, {
      value: true,
      selectedItem: true,
      displayValue: true
    });
  },
  _init() {
    this.callBase();
    this._initDataExpressions();
    this._initActions();
    this._setListDataSource();
    this._validateSearchMode();
    this._clearSelectedItem();
    this._initItems();
  },
  _setListFocusedElementOptionChange() {
    this._list._updateParentActiveDescendant = this._updateActiveDescendant.bind(this);
  },
  _initItems() {
    const {
      items
    } = this.option();
    if (items && !items.length && this._dataSource) {
      this.option().items = this._dataSource.items();
    }
  },
  _initActions() {
    this._initContentReadyAction();
    this._initSelectionChangedAction();
    this._initItemClickAction();
  },
  _initContentReadyAction() {
    this._contentReadyAction = this._createActionByOption("onContentReady", {
      excludeValidators: ["disabled", "readOnly"]
    });
  },
  _initSelectionChangedAction() {
    this._selectionChangedAction = this._createActionByOption("onSelectionChanged", {
      excludeValidators: ["disabled", "readOnly"]
    });
  },
  _initItemClickAction() {
    this._itemClickAction = this._createActionByOption("onItemClick");
  },
  _initTemplates() {
    this.callBase();
    this._templateManager.addDefaultTemplates({
      item: new ChildDefaultTemplate("item")
    });
  },
  _isEditable() {
    return this.callBase() || this.option("searchEnabled");
  },
  _saveFocusOnWidget() {
    if (this._list && this._list.initialOption("focusStateEnabled")) {
      this._focusInput();
    }
  },
  _fitIntoRange(value, start, end) {
    if (value > end) {
      return start;
    }
    if (value < start) {
      return end;
    }
    return value;
  },
  _items() {
    const items = this._getPlainItems(!this._list && this._dataSource.items());
    const availableItems = new query_default(items).filter("disabled", "<>", true).toArray();
    return availableItems;
  },
  _calcNextItem(step) {
    const items = this._items();
    const nextIndex = this._fitIntoRange(this._getSelectedIndex() + step, 0, items.length - 1);
    return items[nextIndex];
  },
  _getSelectedIndex() {
    const items = this._items();
    const selectedItem = this.option("selectedItem");
    let result = -1;
    each(items, (index, item) => {
      if (this._isValueEquals(item, selectedItem)) {
        result = index;
        return false;
      }
    });
    return result;
  },
  _createPopup() {
    this.callBase();
    this._updateCustomBoundaryContainer();
    this._popup.$wrapper().addClass(this._popupWrapperClass());
    const $popupContent = this._popup.$content();
    events_engine_default.off($popupContent, "mouseup");
    events_engine_default.on($popupContent, "mouseup", this._saveFocusOnWidget.bind(this));
  },
  _updateCustomBoundaryContainer() {
    const customContainer = this.option("dropDownOptions.container");
    const $container = customContainer && renderer_default(customContainer);
    if ($container && $container.length && !isWindow($container.get(0))) {
      const $containerWithParents = [].slice.call($container.parents());
      $containerWithParents.unshift($container.get(0));
      each($containerWithParents, (i, parent) => {
        if (parent === renderer_default("body").get(0)) {
          return false;
        }
        if ("hidden" === window.getComputedStyle(parent).overflowY) {
          this._$customBoundaryContainer = renderer_default(parent);
          return false;
        }
      });
    }
  },
  _popupWrapperClass: () => "dx-dropdownlist-popup-wrapper",
  _renderInputValue() {
    const value = this._getCurrentValue();
    this._rejectValueLoading();
    return this._loadInputValue(value, this._setSelectedItem.bind(this)).always(this.callBase.bind(this, value));
  },
  _loadInputValue(value, callback) {
    return this._loadItem(value).always(callback);
  },
  _getItemFromPlain(value, cache) {
    let plainItems;
    let selectedItem;
    if (cache && "object" !== typeof value) {
      if (!cache.itemByValue) {
        cache.itemByValue = {};
        plainItems = this._getPlainItems();
        plainItems.forEach(function(item) {
          cache.itemByValue[this._valueGetter(item)] = item;
        }, this);
      }
      selectedItem = cache.itemByValue[value];
    }
    if (!selectedItem) {
      plainItems = this._getPlainItems();
      selectedItem = grep(plainItems, (item) => this._isValueEquals(this._valueGetter(item), value))[0];
    }
    return selectedItem;
  },
  _loadItem(value, cache) {
    const selectedItem = this._getItemFromPlain(value, cache);
    return void 0 !== selectedItem ? Deferred().resolve(selectedItem).promise() : this._loadValue(value);
  },
  _getPlainItems(items) {
    let plainItems = [];
    items = items || this.option("items") || this._dataSource.items() || [];
    for (let i = 0; i < items.length; i++) {
      if (items[i] && items[i].items) {
        plainItems = plainItems.concat(items[i].items);
      } else {
        plainItems.push(items[i]);
      }
    }
    return plainItems;
  },
  _updateActiveDescendant($target) {
    var _this$_list;
    const opened = this.option("opened");
    const listFocusedItemId = null === (_this$_list = this._list) || void 0 === _this$_list ? void 0 : _this$_list.getFocusedItemId();
    const isElementOnDom = renderer_default(`#${listFocusedItemId}`).length > 0;
    const activedescendant = opened && isElementOnDom && listFocusedItemId;
    this.setAria({
      activedescendant: activedescendant || null
    }, $target);
  },
  _setSelectedItem(item) {
    const displayValue = this._displayValue(item);
    this.option("selectedItem", ensureDefined(item, null));
    this.option("displayValue", displayValue);
  },
  _displayValue(item) {
    return this._displayGetter(item);
  },
  _refreshSelected() {
    const cache = {};
    this._listItemElements().each((_, itemElement) => {
      const $itemElement = renderer_default(itemElement);
      const itemValue = this._valueGetter($itemElement.data("dxListItemData"));
      const isItemSelected = this._isSelectedValue(itemValue, cache);
      if (isItemSelected) {
        this._list.selectItem($itemElement);
      } else {
        this._list.unselectItem($itemElement);
      }
    });
  },
  _popupShownHandler() {
    this.callBase();
    this._setFocusPolicy();
  },
  _setFocusPolicy() {
    if (!this.option("focusStateEnabled") || !this._list) {
      return;
    }
    this._list.option("focusedElement", null);
  },
  _isSelectedValue(value) {
    return this._isValueEquals(value, this.option("value"));
  },
  _validateSearchMode() {
    const searchMode = this.option("searchMode");
    const normalizedSearchMode = searchMode.toLowerCase();
    if (!SEARCH_MODES.includes(normalizedSearchMode)) {
      throw ui_errors_default.Error("E1019", searchMode);
    }
  },
  _clearSelectedItem() {
    this.option("selectedItem", null);
  },
  _processDataSourceChanging() {
    this._initDataController();
    this._setListOption("_dataController", this._dataController);
    this._setListDataSource();
    this._renderInputValue().fail(() => {
      if (this._isCustomValueAllowed()) {
        return;
      }
      this._clearSelectedItem();
    });
  },
  _isCustomValueAllowed() {
    return this.option("displayCustomValue");
  },
  clear() {
    this.callBase();
    this._clearFilter();
    this._clearSelectedItem();
  },
  _listItemElements() {
    return this._$list ? this._$list.find(".dx-list-item") : renderer_default();
  },
  _popupConfig() {
    return extend(this.callBase(), {
      templatesRenderAsynchronously: false,
      autoResizeEnabled: false,
      maxHeight: this._getMaxHeight.bind(this)
    });
  },
  _renderPopupContent() {
    this.callBase();
    this._renderList();
  },
  _getKeyboardListeners() {
    const canListHaveFocus = this._canListHaveFocus();
    return this.callBase().concat([!canListHaveFocus && this._list]);
  },
  _renderList() {
    this._listId = `dx-${new guid_default()._value}`;
    const $list = renderer_default("<div>").attr("id", this._listId).appendTo(this._popup.$content());
    this._$list = $list;
    this._list = this._createComponent($list, list_light_default, this._listConfig());
    this._refreshList();
    this._renderPreventBlurOnListClick();
    this._setListFocusedElementOptionChange();
  },
  _renderPreventBlurOnListClick() {
    const eventName = addNamespace("mousedown", "dxDropDownList");
    events_engine_default.off(this._$list, eventName);
    events_engine_default.on(this._$list, eventName, (e) => e.preventDefault());
  },
  _getControlsAria() {
    return this._list && this._listId;
  },
  _renderOpenedState() {
    this.callBase();
    this._list && this._updateActiveDescendant();
    this.setAria("owns", this._popup && this._popupContentId);
  },
  _getAriaHasPopup: () => "listbox",
  _refreshList() {
    if (this._list && this._shouldRefreshDataSource()) {
      this._setListDataSource();
    }
  },
  _shouldRefreshDataSource() {
    const dataSourceProvided = !!this._list.option("dataSource");
    return dataSourceProvided !== this._needPassDataSourceToList();
  },
  _isDesktopDevice: () => "desktop" === devices_default.real().deviceType,
  _listConfig() {
    const options = {
      selectionMode: "single",
      _templates: this.option("_templates"),
      templateProvider: this.option("templateProvider"),
      noDataText: this.option("noDataText"),
      encodeNoDataText: this.option("encodeNoDataText"),
      grouped: this.option("grouped"),
      wrapItemText: this.option("wrapItemText"),
      useItemTextAsTitle: this.option("useItemTextAsTitle"),
      onContentReady: this._listContentReadyHandler.bind(this),
      itemTemplate: this.option("itemTemplate"),
      indicateLoading: false,
      keyExpr: this._getCollectionKeyExpr(),
      displayExpr: this._displayGetterExpr(),
      groupTemplate: this.option("groupTemplate"),
      onItemClick: this._listItemClickAction.bind(this),
      dataSource: this._getDataSource(),
      _dataController: this._dataController,
      hoverStateEnabled: this._isDesktopDevice() ? this.option("hoverStateEnabled") : false,
      focusStateEnabled: this._isDesktopDevice() ? this.option("focusStateEnabled") : false
    };
    if (!this._canListHaveFocus()) {
      options.tabIndex = null;
    }
    return options;
  },
  _canListHaveFocus: () => false,
  _getDataSource() {
    return this._needPassDataSourceToList() ? this._dataSource : null;
  },
  _dataSourceOptions: () => ({
    paginate: false
  }),
  _getGroupedOption() {
    return this.option("grouped");
  },
  _dataSourceFromUrlLoadMode: () => "raw",
  _listContentReadyHandler() {
    this._list = this._list || this._$list.dxList("instance");
    if (!this.option("deferRendering")) {
      this._refreshSelected();
    }
    this._updatePopupWidth();
    this._updateListDimensions();
    this._contentReadyAction();
  },
  _setListOption(optionName, value) {
    this._setWidgetOption("_list", arguments);
  },
  _listItemClickAction(e) {
    this._listItemClickHandler(e);
    this._itemClickAction(e);
  },
  _listItemClickHandler: noop,
  _setListDataSource() {
    if (!this._list) {
      return;
    }
    this._setListOption("dataSource", this._getDataSource());
    if (!this._needPassDataSourceToList()) {
      this._setListOption("items", []);
    }
  },
  _needPassDataSourceToList() {
    return this.option("showDataBeforeSearch") || this._isMinSearchLengthExceeded();
  },
  _isMinSearchLengthExceeded() {
    return this._searchValue().toString().length >= this.option("minSearchLength");
  },
  _needClearFilter() {
    return this._canKeepDataSource() ? false : this._needPassDataSourceToList();
  },
  _canKeepDataSource() {
    const isMinSearchLengthExceeded = this._isMinSearchLengthExceeded();
    return this._dataController.isLoaded() && this.option("showDataBeforeSearch") && this.option("minSearchLength") && !isMinSearchLengthExceeded && !this._isLastMinSearchLengthExceeded;
  },
  _searchValue() {
    return this._input().val() || "";
  },
  _getSearchEvent() {
    return addNamespace("input", `${this.NAME}Search`);
  },
  _getCompositionStartEvent() {
    return addNamespace("compositionstart", `${this.NAME}CompositionStart`);
  },
  _getCompositionEndEvent() {
    return addNamespace("compositionend", `${this.NAME}CompositionEnd`);
  },
  _getSetFocusPolicyEvent() {
    return addNamespace("input", `${this.NAME}FocusPolicy`);
  },
  _renderEvents() {
    this.callBase();
    events_engine_default.on(this._input(), this._getSetFocusPolicyEvent(), () => {
      this._setFocusPolicy();
    });
    if (this._shouldRenderSearchEvent()) {
      events_engine_default.on(this._input(), this._getSearchEvent(), (e) => {
        this._searchHandler(e);
      });
      if (useCompositionEvents) {
        events_engine_default.on(this._input(), this._getCompositionStartEvent(), () => {
          this._isTextCompositionInProgress(true);
        });
        events_engine_default.on(this._input(), this._getCompositionEndEvent(), (e) => {
          this._isTextCompositionInProgress(void 0);
          this._searchHandler(e, this._searchValue());
        });
      }
    }
  },
  _shouldRenderSearchEvent() {
    return this.option("searchEnabled");
  },
  _refreshEvents() {
    events_engine_default.off(this._input(), this._getSearchEvent());
    events_engine_default.off(this._input(), this._getSetFocusPolicyEvent());
    if (useCompositionEvents) {
      events_engine_default.off(this._input(), this._getCompositionStartEvent());
      events_engine_default.off(this._input(), this._getCompositionEndEvent());
    }
    this.callBase();
  },
  _isTextCompositionInProgress(value) {
    if (arguments.length) {
      this._isTextComposition = value;
    } else {
      return this._isTextComposition;
    }
  },
  _searchHandler(e, searchValue) {
    if (this._isTextCompositionInProgress()) {
      return;
    }
    if (!this._isMinSearchLengthExceeded()) {
      this._searchCanceled();
      return;
    }
    const searchTimeout = this.option("searchTimeout");
    if (searchTimeout) {
      this._clearSearchTimer();
      this._searchTimer = setTimeout(() => {
        this._searchDataSource(searchValue);
      }, searchTimeout);
    } else {
      this._searchDataSource(searchValue);
    }
  },
  _searchCanceled() {
    this._clearSearchTimer();
    if (this._needClearFilter()) {
      this._filterDataSource(null);
    }
    this._refreshList();
  },
  _searchDataSource() {
    let searchValue = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this._searchValue();
    this._filterDataSource(searchValue);
  },
  _filterDataSource(searchValue) {
    this._clearSearchTimer();
    const dataController = this._dataController;
    dataController.searchExpr(this.option("searchExpr") || this._displayGetterExpr());
    dataController.searchOperation(this.option("searchMode"));
    dataController.searchValue(searchValue);
    dataController.load().done(this._dataSourceFiltered.bind(this, searchValue));
  },
  _clearFilter() {
    const dataController = this._dataController;
    dataController.searchValue() && dataController.searchValue(null);
  },
  _dataSourceFiltered() {
    this._isLastMinSearchLengthExceeded = this._isMinSearchLengthExceeded();
    this._refreshList();
    this._refreshPopupVisibility();
  },
  _shouldOpenPopup() {
    return this._hasItemsToShow();
  },
  _refreshPopupVisibility() {
    if (this.option("readOnly") || !this._searchValue()) {
      return;
    }
    const shouldOpenPopup = this._shouldOpenPopup();
    if (shouldOpenPopup && !this._isFocused()) {
      return;
    }
    this.option("opened", shouldOpenPopup);
    if (shouldOpenPopup) {
      this._updatePopupWidth();
      this._updateListDimensions();
    }
  },
  _dataSourceChangedHandler(newItems) {
    if (0 === this._dataController.pageIndex()) {
      this.option().items = newItems;
    } else {
      this.option().items = this.option().items.concat(newItems);
    }
  },
  _hasItemsToShow() {
    const dataController = this._dataController;
    const resultItems = dataController.items() || [];
    const resultAmount = resultItems.length;
    const isMinSearchLengthExceeded = this._needPassDataSourceToList();
    return !!(isMinSearchLengthExceeded && resultAmount);
  },
  _clearSearchTimer() {
    clearTimeout(this._searchTimer);
    delete this._searchTimer;
  },
  _popupShowingHandler() {
    this._updatePopupWidth();
    this._updateListDimensions();
  },
  _dimensionChanged() {
    this.callBase();
    this._updateListDimensions();
  },
  _needPopupRepaint() {
    const dataController = this._dataController;
    const currentPageIndex = dataController.pageIndex();
    const needRepaint = isDefined(this._pageIndex) && currentPageIndex <= this._pageIndex || dataController.isLastPage() && !this._list._scrollViewIsFull();
    this._pageIndex = currentPageIndex;
    return needRepaint;
  },
  _updateListDimensions() {
    if (!this._popup) {
      return;
    }
    if (this._needPopupRepaint()) {
      this._popup.repaint();
    }
    this._list && this._list.updateDimensions();
  },
  _getMaxHeight() {
    const $element = this.$element();
    const $customBoundaryContainer = this._$customBoundaryContainer;
    const offsetTop = $element.offset().top - ($customBoundaryContainer ? $customBoundaryContainer.offset().top : 0);
    const windowHeight = getOuterHeight(window);
    const containerHeight = $customBoundaryContainer ? Math.min(getOuterHeight($customBoundaryContainer), windowHeight) : windowHeight;
    const maxHeight = Math.max(offsetTop, containerHeight - offsetTop - getOuterHeight($element));
    return Math.min(0.5 * containerHeight, maxHeight);
  },
  _clean() {
    if (this._list) {
      delete this._list;
    }
    delete this._isLastMinSearchLengthExceeded;
    this.callBase();
  },
  _dispose() {
    this._clearSearchTimer();
    this.callBase();
  },
  _setCollectionWidgetOption() {
    this._setListOption.apply(this, arguments);
  },
  _setSubmitValue() {
    const value = this.option("value");
    const submitValue = this._shouldUseDisplayValue(value) ? this._displayGetter(value) : value;
    this._getSubmitElement().val(submitValue);
  },
  _shouldUseDisplayValue(value) {
    return "this" === this.option("valueExpr") && isObject(value);
  },
  _optionChanged(args) {
    this._dataExpressionOptionChanged(args);
    switch (args.name) {
      case "hoverStateEnabled":
      case "focusStateEnabled":
        this._isDesktopDevice() && this._setListOption(args.name, args.value);
        this.callBase(args);
        break;
      case "items":
        if (!this.option("dataSource")) {
          this._processDataSourceChanging();
        }
        break;
      case "dataSource":
        this._processDataSourceChanging();
        break;
      case "valueExpr":
        this._renderValue();
        this._setListOption("keyExpr", this._getCollectionKeyExpr());
        break;
      case "displayExpr":
        this._renderValue();
        this._setListOption("displayExpr", this._displayGetterExpr());
        break;
      case "searchMode":
        this._validateSearchMode();
        break;
      case "minSearchLength":
        this._refreshList();
        break;
      case "searchEnabled":
      case "showDataBeforeSearch":
      case "searchExpr":
        this._invalidate();
        break;
      case "onContentReady":
        this._initContentReadyAction();
        break;
      case "onSelectionChanged":
        this._initSelectionChangedAction();
        break;
      case "onItemClick":
        this._initItemClickAction();
        break;
      case "grouped":
      case "groupTemplate":
      case "wrapItemText":
      case "noDataText":
      case "encodeNoDataText":
      case "useItemTextAsTitle":
        this._setListOption(args.name);
        break;
      case "displayValue":
        this.option("text", args.value);
        break;
      case "itemTemplate":
      case "searchTimeout":
        break;
      case "selectedItem":
        if (args.previousValue !== args.value) {
          this._selectionChangedAction({
            selectedItem: args.value
          });
        }
        break;
      default:
        this.callBase(args);
    }
  }
}).include(ui_data_expression_default, m_grouped_data_converter_mixin_default);
component_registrator_default("dxDropDownList", DropDownList);
var m_drop_down_list_default = DropDownList;

// node_modules/devextreme/esm/ui/drop_down_editor/ui.drop_down_list.js
var ui_drop_down_list_default = m_drop_down_list_default;

// node_modules/devextreme/esm/__internal/ui/m_select_box.js
var SelectBox = ui_drop_down_list_default.inherit({
  _supportedKeys() {
    const that = this;
    const parent = this.callBase();
    const clearSelectBox = function(e) {
      const isEditable = this._isEditable();
      if (!isEditable) {
        if (this.option("showClearButton")) {
          e.preventDefault();
          this.clear();
        }
      } else if (this._valueSubstituted()) {
        this._preventFiltering = true;
      }
      this._savedTextRemoveEvent = e;
      this._preventSubstitution = true;
    };
    const searchIfNeeded = function() {
      if (that.option("searchEnabled") && that._valueSubstituted()) {
        that._searchHandler();
      }
    };
    return extend({}, parent, {
      tab() {
        if (this.option("opened") && !this._popup.getFocusableElements().length) {
          this._resetCaretPosition(true);
        }
        parent.tab && parent.tab.apply(this, arguments);
        this._cancelSearchIfNeed();
      },
      upArrow(e) {
        if (parent.upArrow.apply(this, arguments)) {
          if (!this.option("opened")) {
            this._setNextValue(e);
          }
          return true;
        }
        return;
      },
      downArrow(e) {
        if (parent.downArrow.apply(this, arguments)) {
          if (!this.option("opened")) {
            this._setNextValue(e);
          }
          return true;
        }
        return;
      },
      leftArrow() {
        var _parent$leftArrow;
        searchIfNeeded();
        null === (_parent$leftArrow = parent.leftArrow) || void 0 === _parent$leftArrow || _parent$leftArrow.apply(this, arguments);
      },
      rightArrow() {
        searchIfNeeded();
        parent.rightArrow && parent.rightArrow.apply(this, arguments);
      },
      home() {
        searchIfNeeded();
        parent.home && parent.home.apply(this, arguments);
      },
      end() {
        searchIfNeeded();
        parent.end && parent.end.apply(this, arguments);
      },
      escape() {
        const result = parent.escape && parent.escape.apply(this, arguments);
        this._cancelEditing();
        return result ?? true;
      },
      enter(e) {
        const isOpened = this.option("opened");
        const inputText = this._input().val().trim();
        const isCustomText = inputText && this._list && !this._list.option("focusedElement");
        if (!inputText && isDefined(this.option("value")) && this.option("allowClearing")) {
          this._saveValueChangeEvent(e);
          this.option({
            selectedItem: null,
            value: null
          });
          this.close();
        } else {
          if (this.option("acceptCustomValue")) {
            e.preventDefault();
            if (isCustomText) {
              if (isOpened) {
                this._toggleOpenState();
              }
              this._valueChangeEventHandler(e);
            }
            return isOpened;
          }
          if (parent.enter && parent.enter.apply(this, arguments)) {
            return isOpened;
          }
        }
      },
      space(e) {
        const isOpened = this.option("opened");
        const isSearchEnabled = this.option("searchEnabled");
        const acceptCustomValue = this.option("acceptCustomValue");
        if (!isOpened || isSearchEnabled || acceptCustomValue) {
          return;
        }
        e.preventDefault();
        this._valueChangeEventHandler(e);
        return true;
      },
      backspace: clearSelectBox,
      del: clearSelectBox
    });
  },
  _getDefaultOptions() {
    return extend(this.callBase(), {
      placeholder: message_default.format("Select"),
      fieldTemplate: null,
      customItemCreateEvent: "change",
      valueChangeEvent: "change",
      acceptCustomValue: false,
      onCustomItemCreating(e) {
        if (!isDefined(e.customItem)) {
          e.customItem = e.text;
        }
      },
      showSelectionControls: false,
      allowClearing: true,
      tooltipEnabled: false,
      openOnFieldClick: true,
      showDropDownButton: true,
      displayCustomValue: false,
      useHiddenSubmitElement: true
    });
  },
  _init() {
    this.callBase();
    this._initCustomItemCreatingAction();
  },
  _initMarkup() {
    this.$element().addClass("dx-selectbox");
    this._renderTooltip();
    this.callBase();
    this._$container.addClass("dx-selectbox-container");
  },
  _createPopup() {
    this.callBase();
    this._popup.$element().addClass("dx-selectbox-popup");
    this._popup.$overlayContent().attr("tabindex", -1);
  },
  _popupWrapperClass() {
    return `${this.callBase()} dx-selectbox-popup-wrapper`;
  },
  _setDeprecatedOptions() {
    this.callBase();
    extend(this._deprecatedOptions, {
      valueChangeEvent: {
        since: "22.2",
        alias: "customItemCreateEvent"
      }
    });
  },
  _cancelEditing() {
    if (!this.option("searchEnabled") && this._list) {
      this._focusListElement(null);
      this._updateField(this.option("selectedItem"));
    }
  },
  _renderOpenedState() {
    this.callBase();
    if (this.option("opened")) {
      this._scrollToSelectedItem();
      this._focusSelectedElement();
    }
  },
  _focusSelectedElement() {
    const searchValue = this._searchValue();
    if (!searchValue) {
      this._focusListElement(null);
      return;
    }
    const {
      items,
      selectedItem
    } = this.option();
    const $listItems = this._list._itemElements();
    const index = (null === items || void 0 === items ? void 0 : items.indexOf(selectedItem)) ?? -1;
    const focusedElement = -1 !== index && !this._isCustomItemSelected() ? $listItems.eq(index) : null;
    this._focusListElement(focusedElement);
  },
  _renderFocusedElement() {
    if (!this._list) {
      return;
    }
    const searchValue = this._searchValue();
    if (!searchValue || this.option("acceptCustomValue")) {
      this._focusListElement(null);
      return;
    }
    const $listItems = this._list._itemElements();
    const focusedElement = $listItems.not(".dx-state-disabled").eq(0);
    this._focusListElement(focusedElement);
  },
  _focusListElement(element) {
    this._preventInputValueRender = true;
    this._list.option("focusedElement", getPublicElement(element));
    delete this._preventInputValueRender;
  },
  _scrollToSelectedItem() {
    this._list && this._list.scrollToItem(this._list.option("selectedItem"));
  },
  _listContentReadyHandler() {
    this.callBase();
    const isPaginate = this._dataController.paginate();
    if (isPaginate && this._needPopupRepaint()) {
      return;
    }
    this._scrollToSelectedItem();
  },
  _renderValue() {
    this._renderInputValue();
    this._setSubmitValue();
    return Deferred().resolve();
  },
  _renderInputValue() {
    return this.callBase().always(() => {
      this._renderInputValueAsync();
    });
  },
  _renderInputValueAsync() {
    this._renderTooltip();
    this._renderInputValueImpl().always(() => {
      this._refreshSelected();
    });
  },
  _renderInputValueImpl() {
    this._renderField();
    return Deferred().resolve();
  },
  _setNextItem(step) {
    const item = this._calcNextItem(step);
    const value = this._valueGetter(item);
    this._setValue(value);
  },
  _setNextValue(e) {
    const dataSourceIsLoaded = this._dataController.isLoaded() ? Deferred().resolve() : this._dataController.load();
    dataSourceIsLoaded.done(() => {
      const selectedIndex = this._getSelectedIndex();
      const hasPages = this._dataController.pageSize();
      const isLastPage = this._dataController.isLastPage();
      const isLastItem = selectedIndex === this._items().length - 1;
      this._saveValueChangeEvent(e);
      const step = "downArrow" === normalizeKeyName(e) ? 1 : -1;
      if (hasPages && !isLastPage && isLastItem && step > 0) {
        if (!this._popup) {
          this._createPopup();
        }
        if (!this._dataController.isLoading()) {
          this._list._loadNextPage().done(this._setNextItem.bind(this, step));
        }
      } else {
        this._setNextItem(step);
      }
    });
  },
  _setSelectedItem(item) {
    const isUnknownItem = !this._isCustomValueAllowed() && void 0 === item;
    this.callBase(isUnknownItem ? null : item);
    if (!isUnknownItem && (!this._isEditable() || this._isCustomItemSelected())) {
      this._setListOption("selectedItem", this.option("selectedItem"));
    }
  },
  _isCustomValueAllowed() {
    return this.option("acceptCustomValue") || this.callBase();
  },
  _displayValue(item) {
    item = !isDefined(item) && this._isCustomValueAllowed() ? this.option("value") : item;
    return this.callBase(item);
  },
  _listConfig() {
    const result = extend(this.callBase(), {
      pageLoadMode: "scrollBottom",
      onSelectionChanged: this._getSelectionChangeHandler(),
      selectedItem: this.option("selectedItem"),
      onFocusedItemChanged: this._listFocusedItemChangeHandler.bind(this)
    });
    if (this.option("showSelectionControls")) {
      extend(result, {
        showSelectionControls: true,
        selectByClick: true
      });
    }
    return result;
  },
  _listFocusedItemChangeHandler(e) {
    if (this._preventInputValueRender) {
      return;
    }
    const list = e.component;
    const focusedElement = renderer_default(list.option("focusedElement"));
    const focusedItem = list._getItemData(focusedElement);
    this._updateField(focusedItem);
  },
  _updateField(item) {
    const fieldTemplate = this._getTemplateByOption("fieldTemplate");
    if (!(fieldTemplate && this.option("fieldTemplate"))) {
      const text = this._displayGetter(item);
      this.option("text", text);
      this._renderDisplayText(text);
      return;
    }
    this._renderField();
  },
  _getSelectionChangeHandler() {
    return this.option("showSelectionControls") ? this._selectionChangeHandler.bind(this) : noop;
  },
  _selectionChangeHandler(e) {
    each(e.addedItems || [], (_, addedItem) => {
      this._setValue(this._valueGetter(addedItem));
    });
  },
  _getActualSearchValue() {
    return this._dataController.searchValue();
  },
  _isInlineAutocompleteEnabled() {
    return this.option("searchEnabled") && !this.option("acceptCustomValue") && "startswith" === this.option("searchMode");
  },
  _getAriaAutocomplete() {
    const {
      disabled,
      readOnly,
      searchEnabled
    } = this.option();
    const isInputEditable = !(readOnly || disabled);
    const hasAutocomplete = searchEnabled && isInputEditable;
    if (!hasAutocomplete) {
      return "none";
    }
    const isInlineAutocompleteEnabled = this._isInlineAutocompleteEnabled();
    const autocompleteAria = isInlineAutocompleteEnabled ? "both" : "list";
    return autocompleteAria;
  },
  _toggleOpenState(isVisible) {
    if (this.option("disabled")) {
      return;
    }
    isVisible = arguments.length ? isVisible : !this.option("opened");
    if (!isVisible && !this._shouldClearFilter()) {
      this._restoreInputText(true);
    }
    if (this._wasSearch() && isVisible) {
      this._wasSearch(false);
      const showDataImmediately = this.option("showDataBeforeSearch") || this._isMinSearchLengthExceeded();
      if (showDataImmediately && this._dataController.getDataSource()) {
        if (this._searchTimer) {
          return;
        }
        const searchValue = this._getActualSearchValue();
        searchValue && this._wasSearch(true);
        this._filterDataSource(searchValue || null);
      } else {
        this._setListOption("items", []);
      }
    }
    if (isVisible) {
      this._scrollToSelectedItem();
    }
    this.callBase(isVisible);
  },
  _renderTooltip() {
    if (this.option("tooltipEnabled")) {
      this.$element().attr("title", this.option("displayValue"));
    }
  },
  _renderDimensions() {
    this.callBase();
    this._updatePopupWidth();
    this._updateListDimensions();
  },
  _isValueEqualInputText() {
    const initialSelectedItem = this.option("selectedItem");
    if (null === initialSelectedItem) {
      return false;
    }
    const value = this._displayGetter(initialSelectedItem);
    const displayValue = value ? String(value) : "";
    const inputText = this._searchValue();
    return displayValue === inputText;
  },
  _popupHidingHandler() {
    if (this._isValueEqualInputText()) {
      this._cancelEditing();
    }
    this.callBase();
  },
  _popupHiddenHandler() {
    this.callBase();
    if (this._shouldCancelSearch()) {
      this._wasSearch(false);
      this._searchCanceled();
      this._shouldCancelSearch(false);
    }
  },
  _restoreInputText(saveEditingValue) {
    if (this.option("readOnly")) {
      return;
    }
    this._loadItemDeferred && this._loadItemDeferred.always(() => {
      const {
        acceptCustomValue,
        text,
        selectedItem: initialSelectedItem
      } = this.option();
      if (acceptCustomValue) {
        if (!saveEditingValue && !this._isValueChanging) {
          this._updateField(initialSelectedItem ?? this._createCustomItem(text));
          this._clearFilter();
        }
        return;
      }
      if (this.option("searchEnabled")) {
        if (!this._searchValue() && this.option("allowClearing")) {
          this._clearTextValue();
          return;
        }
      }
      if (this._isValueEqualInputText()) {
        return;
      }
      this._renderInputValue().always((selectedItem) => {
        const newSelectedItem = ensureDefined(selectedItem, initialSelectedItem);
        this._setSelectedItem(newSelectedItem);
        this._updateField(newSelectedItem);
        this._clearFilter();
      });
    });
  },
  _valueChangeEventIncludesBlur() {
    const valueChangeEvent = this.option(this._getValueChangeEventOptionName());
    return valueChangeEvent.includes("blur");
  },
  _isPreventedFocusOutEvent(e) {
    return this._preventNestedFocusEvent(e) || this._valueChangeEventIncludesBlur();
  },
  _focusOutHandler(e) {
    if (!this._isPreventedFocusOutEvent(e)) {
      const isOverlayTarget = this._isOverlayNestedTarget(e.relatedTarget);
      if (!isOverlayTarget) {
        this._restoreInputText();
        this._clearSearchTimer();
      }
      this._cancelSearchIfNeed(e);
    }
    e.target = this._input().get(0);
    this.callBase(e);
  },
  _cancelSearchIfNeed(e) {
    const {
      searchEnabled
    } = this.option();
    const isOverlayTarget = this._isOverlayNestedTarget(null === e || void 0 === e ? void 0 : e.relatedTarget);
    const shouldCancelSearch = this._wasSearch() && searchEnabled && !isOverlayTarget;
    if (shouldCancelSearch) {
      var _this$_popup;
      const isPopupVisible = null === (_this$_popup = this._popup) || void 0 === _this$_popup ? void 0 : _this$_popup._hideAnimationProcessing;
      this._clearSearchTimer();
      if (isPopupVisible) {
        this._shouldCancelSearch(true);
      } else {
        this._wasSearch(false);
        this._searchCanceled();
      }
    }
  },
  _shouldCancelSearch(value) {
    if (!arguments.length) {
      return this._shouldCancelSearchValue;
    }
    this._shouldCancelSearchValue = value;
  },
  _isOverlayNestedTarget: (target) => !!renderer_default(target).closest(".dx-selectbox-popup-wrapper").length,
  _clearTextValue() {
    const selectedItem = this.option("selectedItem");
    const selectedItemText = this._displayGetter(selectedItem);
    const shouldRestoreValue = selectedItem && "" !== selectedItemText;
    if (shouldRestoreValue) {
      if (this._savedTextRemoveEvent) {
        this._saveValueChangeEvent(this._savedTextRemoveEvent);
      }
      this.option("value", null);
    }
    delete this._savedTextRemoveEvent;
  },
  _shouldOpenPopup() {
    return this._needPassDataSourceToList() && this._wasSearch();
  },
  _isFocused() {
    const activeElement = dom_adapter_default.getActiveElement(this.element());
    return this.callBase() && renderer_default(activeElement).closest(this._input()).length > 0;
  },
  _getValueChangeEventOptionName: () => "customItemCreateEvent",
  _renderValueChangeEvent() {
    if (this._isEditable()) {
      this.callBase();
    }
  },
  _fieldRenderData() {
    const $listFocused = this._list && this.option("opened") && renderer_default(this._list.option("focusedElement"));
    if ($listFocused && $listFocused.length) {
      return this._list._getItemData($listFocused);
    }
    return this.option("selectedItem");
  },
  _isSelectedValue(value) {
    return this._isValueEquals(value, this.option("value"));
  },
  _shouldCloseOnItemClick() {
    return !(this.option("showSelectionControls") && "single" !== this.option("selectionMode"));
  },
  _listItemClickHandler(e) {
    const previousValue = this._getCurrentValue();
    this._focusListElement(renderer_default(e.itemElement));
    this._saveValueChangeEvent(e.event);
    this._completeSelection(this._valueGetter(e.itemData));
    if (this._shouldCloseOnItemClick()) {
      this.option("opened", false);
    }
    if (this.option("searchEnabled") && previousValue === this._valueGetter(e.itemData)) {
      this._updateField(e.itemData);
    }
    if (this._shouldClearFilter()) {
      this._cancelSearchIfNeed();
    }
  },
  _shouldClearFilter() {
    return this._wasSearch();
  },
  _completeSelection(value) {
    this._setValue(value);
  },
  _loadItem(value, cache) {
    const that = this;
    const deferred = Deferred();
    this.callBase(value, cache).done((item) => {
      deferred.resolve(item);
    }).fail((args) => {
      if (null !== args && void 0 !== args && args.shouldSkipCallback) {
        return;
      }
      const selectedItem = that.option("selectedItem");
      if (that.option("acceptCustomValue") && value === that._valueGetter(selectedItem)) {
        deferred.resolve(selectedItem);
      } else {
        deferred.reject();
      }
    });
    return deferred.promise();
  },
  _loadInputValue(value, callback) {
    this._loadItemDeferred = this._loadItem(value).always(callback);
    return this._loadItemDeferred;
  },
  _isCustomItemSelected() {
    const selectedItem = this.option("selectedItem");
    const searchValue = this._searchValue();
    const selectedItemText = this._displayGetter(selectedItem);
    return !selectedItemText || searchValue !== selectedItemText.toString();
  },
  _valueChangeEventHandler(e) {
    if (this.option("acceptCustomValue") && this._isCustomItemSelected() && !this._isValueChanging) {
      this._isValueChanging = true;
      this._customItemAddedHandler(e);
    }
  },
  _initCustomItemCreatingAction() {
    this._customItemCreatingAction = this._createActionByOption("onCustomItemCreating");
  },
  _createCustomItem(text) {
    const params = {
      text
    };
    const actionResult = this._customItemCreatingAction(params);
    const item = ensureDefined(actionResult, params.customItem);
    if (isDefined(actionResult)) {
      errors_default.log("W0015", "onCustomItemCreating", "customItem");
    }
    return item;
  },
  _customItemAddedHandler(e) {
    const searchValue = this._searchValue();
    const item = this._createCustomItem(searchValue);
    this._saveValueChangeEvent(e);
    if (void 0 === item) {
      this._renderValue();
      throw errors_default.Error("E0121");
    }
    if (isPromise(item)) {
      fromPromise(item).done(this._setCustomItem.bind(this)).fail(this._setCustomItem.bind(this, null));
    } else {
      this._setCustomItem(item);
    }
  },
  _setCustomItem(item) {
    if (this._disposed) {
      return;
    }
    item = item || null;
    this.option("selectedItem", item);
    this._cancelSearchIfNeed();
    this._setValue(this._valueGetter(item));
    this._renderDisplayText(this._displayGetter(item));
    this._isValueChanging = false;
  },
  _clearValueHandler(e) {
    this._preventFiltering = true;
    this.callBase(e);
    this._searchCanceled();
    return false;
  },
  _wasSearch(value) {
    if (!arguments.length) {
      return !!this._wasSearchValue;
    }
    this._wasSearchValue = value;
    return;
  },
  _searchHandler() {
    if (this._preventFiltering) {
      delete this._preventFiltering;
      return;
    }
    if (this._needPassDataSourceToList()) {
      this._wasSearch(true);
    }
    this.callBase(arguments);
  },
  _dataSourceFiltered(searchValue) {
    this.callBase();
    if (null !== searchValue) {
      this._renderInputSubstitution();
      this._renderFocusedElement();
    }
  },
  _valueSubstituted() {
    const input = this._input().get(0);
    const currentSearchLength = this._searchValue().length;
    const isAllSelected = 0 === input.selectionStart && input.selectionEnd === currentSearchLength;
    const inputHasSelection = input.selectionStart !== input.selectionEnd;
    const isLastSymbolSelected = currentSearchLength === input.selectionEnd;
    return this._wasSearch() && inputHasSelection && !isAllSelected && isLastSymbolSelected && this._shouldSubstitutionBeRendered();
  },
  _shouldSubstitutionBeRendered() {
    return !this._preventSubstitution && this._isInlineAutocompleteEnabled();
  },
  _renderInputSubstitution() {
    if (!this._shouldSubstitutionBeRendered()) {
      delete this._preventSubstitution;
      return;
    }
    const item = this._list && this._getPlainItems(this._list.option("items"))[0];
    if (!item) {
      return;
    }
    const $input = this._input();
    const valueLength = $input.val().length;
    if (0 === valueLength) {
      return;
    }
    const inputElement = $input.get(0);
    const displayValue = this._displayGetter(item).toString();
    inputElement.value = displayValue;
    this._caret({
      start: valueLength,
      end: displayValue.length
    });
  },
  _dispose() {
    this._renderInputValueAsync = noop;
    delete this._loadItemDeferred;
    this.callBase();
  },
  _optionChanged(args) {
    switch (args.name) {
      case "customItemCreateEvent":
        this._refreshValueChangeEvent();
        this._refreshFocusEvent();
        this._refreshEvents();
        break;
      case "onCustomItemCreating":
        this._initCustomItemCreatingAction();
        break;
      case "tooltipEnabled":
        this._renderTooltip();
        break;
      case "readOnly":
      case "disabled":
      case "searchMode":
        this.callBase(args);
        this._setDefaultAria();
        break;
      case "displayCustomValue":
      case "acceptCustomValue":
      case "showSelectionControls":
        this._invalidate();
        break;
      case "allowClearing":
        break;
      default:
        this.callBase(args);
    }
  }
});
component_registrator_default("dxSelectBox", SelectBox);
var m_select_box_default = SelectBox;

// node_modules/devextreme/esm/ui/select_box.js
var select_box_default = m_select_box_default;

export {
  ui_data_expression_default,
  DropDownButton,
  getElementWidth,
  getSizeValue,
  m_drop_down_editor_default,
  ui_drop_down_list_default,
  select_box_default
};
//# sourceMappingURL=chunk-JNYFZUAT.js.map
