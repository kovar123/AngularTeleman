import {
  DxButtonComponent,
  DxButtonModule
} from "./chunk-5SRCYWUK.js";
import "./chunk-5HHW3WTB.js";
import "./chunk-AF6BX6BR.js";
import "./chunk-M7JKWUQP.js";
import "./chunk-6PD6EB72.js";
import "./chunk-CADIH4ZJ.js";
import "./chunk-MM4NENTZ.js";
import "./chunk-76GCZVPW.js";
import "./chunk-ZXJK4LK6.js";
import "./chunk-IRP4I5CC.js";
import "./chunk-MU4Z4OEA.js";
import "./chunk-RC2BNL3X.js";
import "./chunk-W35F6NCE.js";
import "./chunk-4BRW6FUL.js";
import "./chunk-UTUFIS2B.js";
import "./chunk-ECTAQLWV.js";
import "./chunk-JMD3HP77.js";
import "./chunk-UG3XN6F5.js";
import "./chunk-K3IIKLCY.js";
import "./chunk-WISTXZPE.js";
import "./chunk-N6ESDQJH.js";
export {
  DxButtonComponent,
  DxButtonModule
};
//# sourceMappingURL=devextreme-angular_ui_button.js.map
