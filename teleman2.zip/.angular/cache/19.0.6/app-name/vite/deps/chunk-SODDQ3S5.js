import {
  m_scrollable_default
} from "./chunk-7PCGKOZK.js";

// node_modules/devextreme/esm/ui/scroll_view/ui.scrollable.js
var ui_scrollable_default = m_scrollable_default;

export {
  ui_scrollable_default
};
//# sourceMappingURL=chunk-SODDQ3S5.js.map
