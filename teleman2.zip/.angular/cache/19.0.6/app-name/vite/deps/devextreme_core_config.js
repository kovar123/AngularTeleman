import {
  config_default
} from "./chunk-UTUFIS2B.js";
import "./chunk-N6ESDQJH.js";
export {
  config_default as default
};
//# sourceMappingURL=devextreme_core_config.js.map
