import {
  text_box_default,
  ui_search_box_mixin_default
} from "./chunk-JXQ6JBGW.js";
import {
  BindableTemplate,
  query_default,
  store_helper_default,
  ui_collection_widget_edit_default
} from "./chunk-VOSGCXDL.js";
import {
  getImageContainer
} from "./chunk-5HHW3WTB.js";
import {
  devices_default,
  ui_errors_default
} from "./chunk-76GCZVPW.js";
import {
  renderer_default
} from "./chunk-MU4Z4OEA.js";
import {
  _extends,
  class_default,
  compileGetter,
  compileSetter,
  each,
  noop
} from "./chunk-4BRW6FUL.js";
import {
  extend,
  isDefined,
  isFunction,
  isObject,
  isPrimitive
} from "./chunk-UTUFIS2B.js";

// node_modules/devextreme/esm/__internal/ui/hierarchical_collection/m_data_converter.js
var DataConverter = class_default.inherit({
  ctor() {
    this._dataStructure = [];
    this._itemsCount = 0;
    this._visibleItemsCount = 0;
  },
  _indexByKey: {},
  _convertItemsToNodes(items, parentKey) {
    const that = this;
    each(items, (_, item) => {
      const parentId = isDefined(parentKey) ? parentKey : that._getParentId(item);
      const node = that._convertItemToNode(item, parentId);
      that._dataStructure.push(node);
      that._checkForDuplicateId(node.internalFields.key);
      that._indexByKey[node.internalFields.key] = that._dataStructure.length - 1;
      if (that._itemHasChildren(item)) {
        that._convertItemsToNodes(that._dataAccessors.getters.items(item), node.internalFields.key);
      }
    });
  },
  _checkForDuplicateId(key) {
    if (isDefined(this._indexByKey[key])) {
      throw ui_errors_default.Error("E1040", key);
    }
  },
  _getParentId(item) {
    return "plain" === this._dataType ? this._dataAccessors.getters.parentKey(item) : void 0;
  },
  _itemHasChildren(item) {
    if ("plain" === this._dataType) {
      return;
    }
    const items = this._dataAccessors.getters.items(item);
    return items && items.length;
  },
  _getUniqueKey(item) {
    const keyGetter = this._dataAccessors.getters.key;
    const itemKey = keyGetter(item);
    const isCorrectKey = keyGetter && (itemKey || 0 === itemKey) && isPrimitive(itemKey);
    return isCorrectKey ? itemKey : this.getItemsCount();
  },
  _convertItemToNode(item, parentKey) {
    this._itemsCount++;
    false !== item.visible && this._visibleItemsCount++;
    const node = {
      internalFields: {
        disabled: this._dataAccessors.getters.disabled(item, {
          defaultValue: false
        }),
        expanded: this._dataAccessors.getters.expanded(item, {
          defaultValue: false
        }),
        selected: this._dataAccessors.getters.selected(item, {
          defaultValue: false
        }),
        key: this._getUniqueKey(item),
        parentKey: isDefined(parentKey) ? parentKey : this._rootValue,
        item: this._makeObjectFromPrimitive(item),
        childrenKeys: []
      }
    };
    extend(node, item);
    delete node.items;
    return node;
  },
  setChildrenKeys() {
    const that = this;
    each(this._dataStructure, (_, node) => {
      if (node.internalFields.parentKey === that._rootValue) {
        return;
      }
      const parent = that.getParentNode(node);
      parent && parent.internalFields.childrenKeys.push(node.internalFields.key);
    });
  },
  _makeObjectFromPrimitive(item) {
    if (isPrimitive(item)) {
      const key = item;
      item = {};
      this._dataAccessors.setters.key(item, key);
    }
    return item;
  },
  _convertToPublicNode(node, parent) {
    if (!node) {
      return null;
    }
    const publicNode = {
      text: this._dataAccessors.getters.display(node),
      key: node.internalFields.key,
      selected: node.internalFields.selected,
      expanded: node.internalFields.expanded,
      disabled: node.internalFields.disabled,
      parent: parent || null,
      itemData: node.internalFields.item,
      children: [],
      items: []
    };
    if (publicNode.parent) {
      publicNode.parent.children.push(publicNode);
      publicNode.parent.items.push(publicNode);
    }
    return publicNode;
  },
  convertToPublicNodes(data, parent) {
    if (!data.length) {
      return [];
    }
    const that = this;
    const publicNodes = [];
    each(data, (_, node) => {
      node = isPrimitive(node) ? that._getByKey(node) : node;
      const publicNode = that._convertToPublicNode(node, parent);
      publicNode.children = that.convertToPublicNodes(node.internalFields.childrenKeys, publicNode);
      publicNodes.push(publicNode);
      node.internalFields.publicNode = publicNode;
    });
    return publicNodes;
  },
  setDataAccessors(accessors) {
    this._dataAccessors = accessors;
  },
  _getByKey(key) {
    return this._dataStructure[this.getIndexByKey(key)] || null;
  },
  getParentNode(node) {
    return this._getByKey(node.internalFields.parentKey);
  },
  getByKey(data, key) {
    if (null === key || void 0 === key) {
      return null;
    }
    let result = null;
    const that = this;
    return function(data2, key2) {
      each(data2, (_, element) => {
        const currentElementKey = element.internalFields && element.internalFields.key || that._dataAccessors.getters.key(element);
        if (currentElementKey.toString() === key2.toString()) {
          result = element;
          return false;
        }
      });
      return result;
    }(data, key);
  },
  getItemsCount() {
    return this._itemsCount;
  },
  getVisibleItemsCount() {
    return this._visibleItemsCount;
  },
  updateIndexByKey() {
    const that = this;
    this._indexByKey = {};
    each(this._dataStructure, (index, node) => {
      that._checkForDuplicateId(node.internalFields.key);
      that._indexByKey[node.internalFields.key] = index;
    });
  },
  updateChildrenKeys() {
    this._indexByKey = {};
    this.removeChildrenKeys();
    this.updateIndexByKey();
    this.setChildrenKeys();
  },
  removeChildrenKeys() {
    this._indexByKey = {};
    each(this._dataStructure, (index, node) => {
      node.internalFields.childrenKeys = [];
    });
  },
  getIndexByKey(key) {
    return this._indexByKey[key];
  },
  createPlainStructure(items, rootValue, dataType) {
    this._itemsCount = 0;
    this._visibleItemsCount = 0;
    this._rootValue = rootValue;
    this._dataType = dataType;
    this._indexByKey = {};
    this._convertItemsToNodes(items);
    this.setChildrenKeys();
    return this._dataStructure;
  }
});
var m_data_converter_default = DataConverter;

// node_modules/devextreme/esm/__internal/ui/hierarchical_collection/m_data_adapter.js
var EXPANDED = "expanded";
var SELECTED = "selected";
var DISABLED = "disabled";
ui_search_box_mixin_default.setEditorClass(text_box_default);
var DataAdapter = class_default.inherit({
  ctor(options) {
    this.options = {};
    extend(this.options, this._defaultOptions(), options);
    this.options.dataConverter.setDataAccessors(this.options.dataAccessors);
    this._selectedNodesKeys = [];
    this._expandedNodesKeys = [];
    this._dataStructure = [];
    this._createInternalDataStructure();
    this.getTreeNodes();
  },
  setOption(name, value) {
    this.options[name] = value;
    if ("recursiveSelection" === name) {
      this._updateSelection();
    }
  },
  _defaultOptions: () => ({
    dataAccessors: void 0,
    items: [],
    multipleSelection: true,
    recursiveSelection: false,
    recursiveExpansion: false,
    rootValue: 0,
    searchValue: "",
    dataType: "tree",
    searchMode: "contains",
    dataConverter: new m_data_converter_default(),
    onNodeChanged: noop,
    sort: null
  }),
  _createInternalDataStructure() {
    this._initialDataStructure = this.options.dataConverter.createPlainStructure(this.options.items, this.options.rootValue, this.options.dataType);
    this._dataStructure = this.options.searchValue.length ? this.search(this.options.searchValue) : this._initialDataStructure;
    this.options.dataConverter._dataStructure = this._dataStructure;
    this._updateSelection();
    this._updateExpansion();
  },
  _updateSelection() {
    if (this.options.recursiveSelection) {
      this._setChildrenSelection();
      this._setParentSelection();
    }
    this._selectedNodesKeys = this._updateNodesKeysArray(SELECTED);
  },
  _updateExpansion(key) {
    if (this.options.recursiveExpansion) {
      key ? this._updateOneBranch(key) : this._setParentExpansion();
    }
    this._expandedNodesKeys = this._updateNodesKeysArray(EXPANDED);
  },
  _updateNodesKeysArray(property) {
    const that = this;
    let array = [];
    each(that._getDataBySelectionMode(), (_, node) => {
      if (!that._isNodeVisible(node)) {
        return;
      }
      if (node.internalFields[property]) {
        if (property === EXPANDED || that.options.multipleSelection) {
          array.push(node.internalFields.key);
        } else {
          array.length && that.toggleSelection(array[0], false, true);
          array = [node.internalFields.key];
        }
      }
    });
    return array;
  },
  _getDataBySelectionMode() {
    return this.options.multipleSelection ? this.getData() : this.getFullData();
  },
  _isNodeVisible: (node) => false !== node.internalFields.item.visible,
  _getByKey(data, key) {
    return data === this._dataStructure ? this.options.dataConverter._getByKey(key) : this.options.dataConverter.getByKey(data, key);
  },
  _setChildrenSelection() {
    const that = this;
    each(this._dataStructure, (_, node) => {
      if (!node.internalFields.childrenKeys.length) {
        return;
      }
      const isSelected = node.internalFields.selected;
      true === isSelected && that._toggleChildrenSelection(node, isSelected);
    });
  },
  _setParentSelection() {
    const that = this;
    each(this._dataStructure, (_, node) => {
      const parent = that.options.dataConverter.getParentNode(node);
      if (parent && node.internalFields.parentKey !== that.options.rootValue) {
        that._iterateParents(node, (parent2) => {
          const newParentState = that._calculateSelectedState(parent2);
          that._setFieldState(parent2, SELECTED, newParentState);
        });
      }
    });
  },
  _setParentExpansion() {
    const that = this;
    each(this._dataStructure, (_, node) => {
      if (!node.internalFields.expanded) {
        return;
      }
      that._updateOneBranch(node.internalFields.key);
    });
  },
  _updateOneBranch(key) {
    const that = this;
    const node = this.getNodeByKey(key);
    that._iterateParents(node, (parent) => {
      that._setFieldState(parent, EXPANDED, true);
    });
  },
  _iterateChildren(node, recursive, callback, processedKeys) {
    if (!isFunction(callback)) {
      return;
    }
    const that = this;
    const nodeKey = node.internalFields.key;
    processedKeys = processedKeys || [];
    if (-1 === processedKeys.indexOf(nodeKey)) {
      processedKeys.push(nodeKey);
      each(node.internalFields.childrenKeys, (_, key) => {
        const child = that.getNodeByKey(key);
        callback(child);
        if (child.internalFields.childrenKeys.length && recursive) {
          that._iterateChildren(child, recursive, callback, processedKeys);
        }
      });
    }
  },
  _iterateParents(node, callback, processedKeys) {
    if (node.internalFields.parentKey === this.options.rootValue || !isFunction(callback)) {
      return;
    }
    processedKeys = processedKeys || [];
    const {
      key
    } = node.internalFields;
    if (-1 === processedKeys.indexOf(key)) {
      processedKeys.push(key);
      const parent = this.options.dataConverter.getParentNode(node);
      if (parent) {
        callback(parent);
        if (parent.internalFields.parentKey !== this.options.rootValue) {
          this._iterateParents(parent, callback, processedKeys);
        }
      }
    }
  },
  _calculateSelectedState(node) {
    const itemsCount = node.internalFields.childrenKeys.length;
    let selectedItemsCount = 0;
    let invisibleItemsCount = 0;
    let result = false;
    for (let i = 0; i <= itemsCount - 1; i++) {
      const childNode = this.getNodeByKey(node.internalFields.childrenKeys[i]);
      const isChildInvisible = false === childNode.internalFields.item.visible;
      const childState = childNode.internalFields.selected;
      if (isChildInvisible) {
        invisibleItemsCount++;
        continue;
      }
      if (childState) {
        selectedItemsCount++;
      } else if (void 0 === childState) {
        selectedItemsCount += 0.5;
      }
    }
    if (selectedItemsCount) {
      result = selectedItemsCount === itemsCount - invisibleItemsCount ? true : void 0;
    }
    return result;
  },
  _toggleChildrenSelection(node, state) {
    const that = this;
    this._iterateChildren(node, true, (child) => {
      if (that._isNodeVisible(child)) {
        that._setFieldState(child, SELECTED, state);
      }
    });
  },
  _setFieldState(node, field, state) {
    if (node.internalFields[field] === state) {
      return;
    }
    node.internalFields[field] = state;
    if (node.internalFields.publicNode) {
      node.internalFields.publicNode[field] = state;
    }
    this.options.dataAccessors.setters[field](node.internalFields.item, state);
    this.options.onNodeChanged(node);
  },
  _markChildren(keys) {
    const that = this;
    each(keys, (_, key) => {
      const index = that.getIndexByKey(key);
      const node = that.getNodeByKey(key);
      that._dataStructure[index] = 0;
      node.internalFields.childrenKeys.length && that._markChildren(node.internalFields.childrenKeys);
    });
  },
  _removeNode(key) {
    const node = this.getNodeByKey(key);
    this._dataStructure[this.getIndexByKey(key)] = 0;
    this._markChildren(node.internalFields.childrenKeys);
    const that = this;
    let counter = 0;
    const items = extend([], this._dataStructure);
    each(items, (index, item) => {
      if (!item) {
        that._dataStructure.splice(index - counter, 1);
        counter++;
      }
    });
  },
  _addNode(item) {
    const {
      dataConverter
    } = this.options;
    const node = dataConverter._convertItemToNode(item, this.options.dataAccessors.getters.parentKey(item));
    this._dataStructure = this._dataStructure.concat(node);
    this._initialDataStructure = this._initialDataStructure.concat(node);
    dataConverter._dataStructure = dataConverter._dataStructure.concat(node);
  },
  _updateFields() {
    this.options.dataConverter.updateChildrenKeys();
    this._updateSelection();
    this._updateExpansion();
  },
  getSelectedNodesKeys() {
    return this._selectedNodesKeys;
  },
  getExpandedNodesKeys() {
    return this._expandedNodesKeys;
  },
  getData() {
    return this._dataStructure;
  },
  getFullData() {
    return this._initialDataStructure;
  },
  getNodeByItem(item) {
    let result = null;
    each(this._dataStructure, (_, node) => {
      if (node.internalFields.item === item) {
        result = node;
        return false;
      }
    });
    return result;
  },
  getNodesByItems(items) {
    const that = this;
    const nodes = [];
    each(items, (_, item) => {
      const node = that.getNodeByItem(item);
      node && nodes.push(node);
    });
    return nodes;
  },
  getNodeByKey(key, data) {
    return this._getByKey(data || this._getDataBySelectionMode(), key);
  },
  getTreeNodes() {
    return this.options.dataConverter.convertToPublicNodes(this.getRootNodes());
  },
  getItemsCount() {
    return this.options.dataConverter.getItemsCount();
  },
  getVisibleItemsCount() {
    return this.options.dataConverter.getVisibleItemsCount();
  },
  getPublicNode: (node) => node.internalFields.publicNode,
  getRootNodes() {
    return this.getChildrenNodes(this.options.rootValue);
  },
  getChildrenNodes(parentKey) {
    return query_default(this._dataStructure, {
      langParams: this.options.langParams
    }).filter(["internalFields.parentKey", parentKey]).toArray();
  },
  getIndexByKey(key) {
    return this.options.dataConverter.getIndexByKey(key);
  },
  addItem(item) {
    this._addNode(item);
    this._updateFields();
  },
  removeItem(key) {
    this._removeNode(key);
    this._updateFields();
  },
  toggleSelection(key, state, selectRecursive) {
    const isSingleModeUnselect = this._isSingleModeUnselect(state);
    const node = this._getByKey(selectRecursive || isSingleModeUnselect ? this._initialDataStructure : this._dataStructure, key);
    this._setFieldState(node, SELECTED, state);
    if (this.options.recursiveSelection && !selectRecursive) {
      state ? this._setChildrenSelection() : this._toggleChildrenSelection(node, state);
      this._setParentSelection();
    }
    this._selectedNodesKeys = this._updateNodesKeysArray(SELECTED);
  },
  _isSingleModeUnselect(selectionState) {
    return !this.options.multipleSelection && !selectionState;
  },
  toggleNodeDisabledState(key, state) {
    const node = this.getNodeByKey(key);
    this._setFieldState(node, DISABLED, state);
  },
  toggleSelectAll(state) {
    if (!isDefined(state)) {
      return;
    }
    const that = this;
    const lastSelectedKey = that._selectedNodesKeys[that._selectedNodesKeys.length - 1];
    const dataStructure = that._isSingleModeUnselect(state) ? this._initialDataStructure : this._dataStructure;
    each(dataStructure, (index, node) => {
      if (!that._isNodeVisible(node)) {
        return;
      }
      that._setFieldState(node, SELECTED, state);
    });
    that._selectedNodesKeys = that._updateNodesKeysArray(SELECTED);
    if (!state && that.options.selectionRequired) {
      that.toggleSelection(lastSelectedKey, true);
    }
  },
  isAllSelected() {
    if (this.getSelectedNodesKeys().length) {
      return this.getSelectedNodesKeys().length === this.getVisibleItemsCount() ? true : void 0;
    }
    return false;
  },
  toggleExpansion(key, state) {
    const node = this.getNodeByKey(key);
    this._setFieldState(node, EXPANDED, state);
    if (state) {
      this._updateExpansion(key);
    }
    this._expandedNodesKeys = this._updateNodesKeysArray(EXPANDED);
  },
  isFiltered(item) {
    return !this.options.searchValue.length || !!this._filterDataStructure(this.options.searchValue, [item]).length;
  },
  _createCriteria(selector, value, operation) {
    const searchFilter = [];
    if (!Array.isArray(selector)) {
      return [selector, operation, value];
    }
    each(selector, (i, item) => {
      searchFilter.push([item, operation, value], "or");
    });
    searchFilter.pop();
    return searchFilter;
  },
  _filterDataStructure(filterValue, dataStructure) {
    const selector = this.options.searchExpr || this.options.dataAccessors.getters.display;
    const operation = ui_search_box_mixin_default.getOperationBySearchMode(this.options.searchMode);
    const criteria = this._createCriteria(selector, filterValue, operation);
    dataStructure = dataStructure || this._initialDataStructure;
    return query_default(dataStructure, {
      langParams: this.options.langParams
    }).filter(criteria).toArray();
  },
  search(searchValue) {
    const that = this;
    let matches = this._filterDataStructure(searchValue);
    const {
      dataConverter
    } = this.options;
    !function lookForParents(matches2, index) {
      const {
        length
      } = matches2;
      while (index < length) {
        const node = matches2[index];
        if (node.internalFields.parentKey === that.options.rootValue) {
          index++;
          continue;
        }
        const parent = dataConverter.getParentNode(node);
        if (!parent) {
          ui_errors_default.log("W1007", node.internalFields.parentKey, node.internalFields.key);
          index++;
          continue;
        }
        if (!parent.internalFields.expanded) {
          that._setFieldState(parent, EXPANDED, true);
        }
        if (matches2.includes(parent)) {
          index++;
          continue;
        }
        matches2.splice(index, 0, parent);
        lookForParents(matches2, index);
      }
    }(matches, 0);
    if (this.options.sort) {
      matches = store_helper_default.queryByOptions(query_default(matches), {
        sort: this.options.sort,
        langParams: this.options.langParams
      }).toArray();
    }
    dataConverter._indexByKey = {};
    each(matches, (index, node) => {
      node.internalFields.childrenKeys = [];
      dataConverter._indexByKey[node.internalFields.key] = index;
    });
    dataConverter._dataStructure = matches;
    dataConverter.setChildrenKeys();
    return dataConverter._dataStructure;
  }
});
var m_data_adapter_default = DataAdapter;

// node_modules/devextreme/esm/__internal/ui/hierarchical_collection/m_hierarchical_collection_widget.js
var HierarchicalCollectionWidget = ui_collection_widget_edit_default.inherit({
  _getDefaultOptions() {
    return extend(this.callBase(), {
      keyExpr: "id",
      displayExpr: "text",
      selectedExpr: "selected",
      disabledExpr: "disabled",
      itemsExpr: "items",
      hoverStateEnabled: true,
      parentIdExpr: "parentId",
      expandedExpr: "expanded"
    });
  },
  _defaultOptionsRules() {
    return this.callBase().concat([{
      device: () => "desktop" === devices_default.real().deviceType && !devices_default.isSimulator(),
      options: {
        focusStateEnabled: true
      }
    }]);
  },
  _init() {
    this.callBase();
    this._initAccessors();
    this._initDataAdapter();
    this._initDynamicTemplates();
  },
  _initDataSource() {
    this.callBase();
    this._dataSource && this._dataSource.paginate(false);
  },
  _initDataAdapter() {
    const accessors = this._createDataAdapterAccessors();
    this._dataAdapter = new m_data_adapter_default(extend({
      dataAccessors: {
        getters: accessors.getters,
        setters: accessors.setters
      },
      items: this.option("items")
    }, this._getDataAdapterOptions()));
  },
  _getDataAdapterOptions: noop,
  _getItemExtraPropNames: noop,
  _initDynamicTemplates() {
    const fields = ["text", "html", "items", "icon"].concat(this._getItemExtraPropNames());
    this._templateManager.addDefaultTemplates({
      item: new BindableTemplate(this._addContent.bind(this), fields, this.option("integrationOptions.watchMethod"), {
        text: this._displayGetter,
        items: this._itemsGetter
      })
    });
  },
  _addContent($container, itemData) {
    $container.html(itemData.html).append(this._getIconContainer(itemData)).append(this._getTextContainer(itemData));
  },
  _getLinkContainer(iconContainer, textContainer, _ref) {
    let {
      linkAttr,
      url
    } = _ref;
    const linkAttributes = isObject(linkAttr) ? linkAttr : {};
    return renderer_default("<a>").addClass("dx-item-url").attr(_extends({}, linkAttributes, {
      href: url
    })).append(iconContainer).append(textContainer);
  },
  _getIconContainer(itemData) {
    if (!itemData.icon) {
      return;
    }
    const $imageContainer = getImageContainer(itemData.icon);
    if ($imageContainer.is("img")) {
      const componentName = this.NAME.startsWith("dxPrivateComponent") ? "" : `${this.NAME} `;
      $imageContainer.attr("alt", `${componentName}item icon`);
    }
    return $imageContainer;
  },
  _getTextContainer: (itemData) => renderer_default("<span>").text(itemData.text),
  _initAccessors() {
    const that = this;
    each(this._getAccessors(), (_, accessor) => {
      that._compileAccessor(accessor);
    });
    this._compileDisplayGetter();
  },
  _getAccessors: () => ["key", "selected", "items", "disabled", "parentId", "expanded"],
  _getChildNodes(node) {
    const that = this;
    const arr = [];
    each(node.internalFields.childrenKeys, (_, key) => {
      const childNode = that._dataAdapter.getNodeByKey(key);
      arr.push(childNode);
    });
    return arr;
  },
  _hasChildren: (node) => node && node.internalFields.childrenKeys.length,
  _compileAccessor(optionName) {
    const getter = `_${optionName}Getter`;
    const setter = `_${optionName}Setter`;
    const optionExpr = this.option(`${optionName}Expr`);
    if (!optionExpr) {
      this[getter] = noop;
      this[setter] = noop;
      return;
    }
    if (isFunction(optionExpr)) {
      this[setter] = function(obj, value) {
        obj[optionExpr()] = value;
      };
      this[getter] = function(obj) {
        return obj[optionExpr()];
      };
      return;
    }
    this[getter] = compileGetter(optionExpr);
    this[setter] = compileSetter(optionExpr);
  },
  _createDataAdapterAccessors() {
    const that = this;
    const accessors = {
      getters: {},
      setters: {}
    };
    each(this._getAccessors(), (_, accessor) => {
      const getterName = `_${accessor}Getter`;
      const setterName = `_${accessor}Setter`;
      const newAccessor = "parentId" === accessor ? "parentKey" : accessor;
      accessors.getters[newAccessor] = that[getterName];
      accessors.setters[newAccessor] = that[setterName];
    });
    accessors.getters.display = !this._displayGetter ? (itemData) => itemData.text : this._displayGetter;
    return accessors;
  },
  _initMarkup() {
    this.callBase();
    this._addWidgetClass();
  },
  _addWidgetClass() {
    this._focusTarget().addClass(this._widgetClass());
  },
  _widgetClass: noop,
  _renderItemFrame(index, itemData) {
    const $itemFrame = this.callBase.apply(this, arguments);
    $itemFrame.toggleClass("dx-state-disabled", !!this._disabledGetter(itemData));
    return $itemFrame;
  },
  _optionChanged(args) {
    switch (args.name) {
      case "displayExpr":
      case "keyExpr":
        this._initAccessors();
        this._initDynamicTemplates();
        this.repaint();
        break;
      case "itemsExpr":
      case "selectedExpr":
      case "disabledExpr":
      case "expandedExpr":
      case "parentIdExpr":
        this._initAccessors();
        this._initDataAdapter();
        this.repaint();
        break;
      case "items":
        this._initDataAdapter();
        this.callBase(args);
        break;
      default:
        this.callBase(args);
    }
  }
});
var m_hierarchical_collection_widget_default = HierarchicalCollectionWidget;

// node_modules/devextreme/esm/ui/hierarchical_collection/ui.hierarchical_collection_widget.js
var ui_hierarchical_collection_widget_default = m_hierarchical_collection_widget_default;

export {
  ui_hierarchical_collection_widget_default
};
//# sourceMappingURL=chunk-CBLXKXVB.js.map
