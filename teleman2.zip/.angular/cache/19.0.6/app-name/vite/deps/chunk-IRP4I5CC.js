import {
  events_engine_default
} from "./chunk-RC2BNL3X.js";

// node_modules/devextreme/esm/events/index.js
var on = events_engine_default.on;
var one = events_engine_default.one;
var off = events_engine_default.off;
var trigger = events_engine_default.trigger;
var triggerHandler = events_engine_default.triggerHandler;
var Event = events_engine_default.Event;

export {
  on,
  one,
  off,
  trigger,
  triggerHandler,
  Event
};
//# sourceMappingURL=chunk-IRP4I5CC.js.map
