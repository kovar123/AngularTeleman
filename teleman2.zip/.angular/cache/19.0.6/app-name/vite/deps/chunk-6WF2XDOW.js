import {
  scroll_view_default
} from "./chunk-NBBAPHVR.js";
import {
  BindableTemplate,
  findChanges,
  indexByKey,
  insert,
  keysEqual,
  m_collection_widget_edit_default,
  m_item_default,
  resize_observer_default,
  update
} from "./chunk-VOSGCXDL.js";
import {
  deviceDependentOptions
} from "./chunk-7PCGKOZK.js";
import {
  button_default,
  getImageContainer,
  render
} from "./chunk-5HHW3WTB.js";
import {
  message_default
} from "./chunk-M7JKWUQP.js";
import {
  current,
  isFluent,
  isMaterial,
  isMaterialBased,
  waitWebFont
} from "./chunk-6PD6EB72.js";
import {
  DRAG_END_EVENT,
  DRAG_EVENT,
  DRAG_START_EVENT,
  OverlayPositionController,
  create,
  fx_default,
  getBoundingRect,
  isLastZIndexInStack,
  locate,
  move,
  remove,
  ui_overlay_default
} from "./chunk-QXE45QVL.js";
import {
  compare
} from "./chunk-ZEY4S4J4.js";
import {
  emitter_gesture_default,
  fitIntoRange,
  inRange
} from "./chunk-CADIH4ZJ.js";
import {
  CLICK_EVENT_NAME,
  EmptyTemplate,
  _objectWithoutPropertiesLoose,
  addNamespace,
  browser_default,
  component_registrator_default,
  dom_component_default,
  emitter_registrator_default,
  eventData,
  getPublicElement,
  nativeScrolling,
  triggerResizeEvent
} from "./chunk-MM4NENTZ.js";
import {
  devices_default,
  originalViewPort
} from "./chunk-76GCZVPW.js";
import {
  addOffsetToMaxHeight,
  addOffsetToMinHeight,
  camelize,
  getHeight,
  getInnerHeight,
  getInnerWidth,
  getOffset,
  getOuterHeight,
  getOuterWidth,
  getVerticalOffsets,
  getVisibleHeight,
  getWidth,
  renderer_default,
  setHeight2 as setHeight,
  titleize
} from "./chunk-MU4Z4OEA.js";
import {
  events_engine_default
} from "./chunk-RC2BNL3X.js";
import {
  Deferred,
  _extends,
  compileGetter,
  dom_adapter_default,
  each,
  ensureDefined,
  getWindow,
  guid_default,
  hasWindow,
  noop,
  pairToObject,
  when
} from "./chunk-4BRW6FUL.js";
import {
  extend,
  isDefined,
  isFunction,
  isObject,
  isPlainObject,
  isWindow
} from "./chunk-UTUFIS2B.js";

// node_modules/devextreme/esm/__internal/ui/m_resizable.js
var RESIZABLE = "dxResizable";
var DRAGSTART_START_EVENT_NAME = addNamespace(DRAG_START_EVENT, RESIZABLE);
var DRAGSTART_EVENT_NAME = addNamespace(DRAG_EVENT, RESIZABLE);
var DRAGSTART_END_EVENT_NAME = addNamespace(DRAG_END_EVENT, RESIZABLE);
var SIDE_BORDER_WIDTH_STYLES = {
  left: "borderLeftWidth",
  top: "borderTopWidth",
  right: "borderRightWidth",
  bottom: "borderBottomWidth"
};
var Resizable = dom_component_default.inherit({
  _getDefaultOptions() {
    return extend(this.callBase(), {
      handles: "all",
      step: "1",
      stepPrecision: "simple",
      area: void 0,
      minWidth: 30,
      maxWidth: 1 / 0,
      minHeight: 30,
      maxHeight: 1 / 0,
      onResizeStart: null,
      onResize: null,
      onResizeEnd: null,
      roundStepValue: true,
      keepAspectRatio: true
    });
  },
  _init() {
    this.callBase();
    this.$element().addClass("dx-resizable");
  },
  _initMarkup() {
    this.callBase();
    this._renderHandles();
  },
  _render() {
    this.callBase();
    this._renderActions();
  },
  _renderActions() {
    this._resizeStartAction = this._createActionByOption("onResizeStart");
    this._resizeEndAction = this._createActionByOption("onResizeEnd");
    this._resizeAction = this._createActionByOption("onResize");
  },
  _renderHandles() {
    this._handles = [];
    const handles = this.option("handles");
    if ("none" === handles || !handles) {
      return;
    }
    const directions = "all" === handles ? ["top", "bottom", "left", "right"] : handles.split(" ");
    const activeHandlesMap = {};
    each(directions, (index, handleName) => {
      activeHandlesMap[handleName] = true;
      this._renderHandle(handleName);
    });
    activeHandlesMap.bottom && activeHandlesMap.right && this._renderHandle("corner-bottom-right");
    activeHandlesMap.bottom && activeHandlesMap.left && this._renderHandle("corner-bottom-left");
    activeHandlesMap.top && activeHandlesMap.right && this._renderHandle("corner-top-right");
    activeHandlesMap.top && activeHandlesMap.left && this._renderHandle("corner-top-left");
    this._attachEventHandlers();
  },
  _renderHandle(handleName) {
    const $handle = renderer_default("<div>").addClass("dx-resizable-handle").addClass(`dx-resizable-handle-${handleName}`).appendTo(this.$element());
    this._handles.push($handle);
  },
  _attachEventHandlers() {
    if (this.option("disabled")) {
      return;
    }
    const handlers = {};
    handlers[DRAGSTART_START_EVENT_NAME] = this._dragStartHandler.bind(this);
    handlers[DRAGSTART_EVENT_NAME] = this._dragHandler.bind(this);
    handlers[DRAGSTART_END_EVENT_NAME] = this._dragEndHandler.bind(this);
    this._handles.forEach((handleElement) => {
      events_engine_default.on(handleElement, handlers, {
        direction: "both",
        immediate: true
      });
    });
  },
  _detachEventHandlers() {
    this._handles.forEach((handleElement) => {
      events_engine_default.off(handleElement);
    });
  },
  _toggleEventHandlers(shouldAttachEvents) {
    shouldAttachEvents ? this._attachEventHandlers() : this._detachEventHandlers();
  },
  _getElementSize() {
    const $element = this.$element();
    return "border-box" === $element.css("boxSizing") ? {
      width: getOuterWidth($element),
      height: getOuterHeight($element)
    } : {
      width: getWidth($element),
      height: getHeight($element)
    };
  },
  _dragStartHandler(e) {
    const $element = this.$element();
    if ($element.is(".dx-state-disabled, .dx-state-disabled *")) {
      e.cancel = true;
      return;
    }
    this._toggleResizingClass(true);
    this._movingSides = this._getMovingSides(e);
    this._elementLocation = locate($element);
    this._elementSize = this._getElementSize();
    this._renderDragOffsets(e);
    this._resizeStartAction({
      event: e,
      width: this._elementSize.width,
      height: this._elementSize.height,
      handles: this._movingSides
    });
    e.targetElements = null;
  },
  _toggleResizingClass(value) {
    this.$element().toggleClass("dx-resizable-resizing", value);
  },
  _renderDragOffsets(e) {
    const area = this._getArea();
    if (!area) {
      return;
    }
    const $handle = renderer_default(e.target).closest(".dx-resizable-handle");
    const handleWidth = getOuterWidth($handle);
    const handleHeight = getOuterHeight($handle);
    const handleOffset = $handle.offset();
    const areaOffset = area.offset;
    const scrollOffset = this._getAreaScrollOffset();
    e.maxLeftOffset = this._leftMaxOffset = handleOffset.left - areaOffset.left - scrollOffset.scrollX;
    e.maxRightOffset = this._rightMaxOffset = areaOffset.left + area.width - handleOffset.left - handleWidth + scrollOffset.scrollX;
    e.maxTopOffset = this._topMaxOffset = handleOffset.top - areaOffset.top - scrollOffset.scrollY;
    e.maxBottomOffset = this._bottomMaxOffset = areaOffset.top + area.height - handleOffset.top - handleHeight + scrollOffset.scrollY;
  },
  _getBorderWidth($element, direction) {
    if (isWindow($element.get(0))) {
      return 0;
    }
    const borderWidth = $element.css(SIDE_BORDER_WIDTH_STYLES[direction]);
    return parseInt(borderWidth) || 0;
  },
  _proportionate(direction, value) {
    const size = this._elementSize;
    const factor = "x" === direction ? size.width / size.height : size.height / size.width;
    return value * factor;
  },
  _getProportionalDelta(_ref) {
    let {
      x,
      y
    } = _ref;
    const proportionalY = this._proportionate("y", x);
    if (proportionalY >= y) {
      return {
        x,
        y: proportionalY
      };
    }
    const proportionalX = this._proportionate("x", y);
    if (proportionalX >= x) {
      return {
        x: proportionalX,
        y
      };
    }
    return {
      x: 0,
      y: 0
    };
  },
  _getDirectionName(axis) {
    const sides = this._movingSides;
    if ("x" === axis) {
      return sides.left ? "left" : "right";
    }
    return sides.top ? "top" : "bottom";
  },
  _fitIntoArea(axis, value) {
    const directionName = this._getDirectionName(axis);
    return Math.min(value, this[`_${directionName}MaxOffset`] ?? 1 / 0);
  },
  _fitDeltaProportionally(delta) {
    let fittedDelta = _extends({}, delta);
    const size = this._elementSize;
    const {
      minWidth,
      minHeight,
      maxWidth,
      maxHeight
    } = this.option();
    const getWidth2 = () => size.width + fittedDelta.x;
    const getHeight2 = () => size.height + fittedDelta.y;
    const isInArea = (axis) => fittedDelta[axis] === this._fitIntoArea(axis, fittedDelta[axis]);
    const isFittedX = () => inRange(getWidth2(), minWidth, maxWidth) && isInArea("x");
    const isFittedY = () => inRange(getHeight2(), minHeight, maxHeight) && isInArea("y");
    if (!isFittedX()) {
      const x = this._fitIntoArea("x", fitIntoRange(getWidth2(), minWidth, maxWidth) - size.width);
      fittedDelta = {
        x,
        y: this._proportionate("y", x)
      };
    }
    if (!isFittedY()) {
      const y = this._fitIntoArea("y", fitIntoRange(getHeight2(), minHeight, maxHeight) - size.height);
      fittedDelta = {
        x: this._proportionate("x", y),
        y
      };
    }
    return isFittedX() && isFittedY() ? fittedDelta : {
      x: 0,
      y: 0
    };
  },
  _fitDelta(_ref2) {
    let {
      x,
      y
    } = _ref2;
    const size = this._elementSize;
    const {
      minWidth,
      minHeight,
      maxWidth,
      maxHeight
    } = this.option();
    return {
      x: fitIntoRange(size.width + x, minWidth, maxWidth) - size.width,
      y: fitIntoRange(size.height + y, minHeight, maxHeight) - size.height
    };
  },
  _getDeltaByOffset(offset) {
    const sides = this._movingSides;
    const shouldKeepAspectRatio = this._isCornerHandler(sides) && this.option("keepAspectRatio");
    let delta = {
      x: offset.x * (sides.left ? -1 : 1),
      y: offset.y * (sides.top ? -1 : 1)
    };
    if (shouldKeepAspectRatio) {
      const proportionalDelta = this._getProportionalDelta(delta);
      const fittedProportionalDelta = this._fitDeltaProportionally(proportionalDelta);
      delta = fittedProportionalDelta;
    } else {
      const fittedDelta = this._fitDelta(delta);
      const roundedFittedDelta = this._roundByStep(fittedDelta);
      delta = roundedFittedDelta;
    }
    return delta;
  },
  _updatePosition(delta, _ref3) {
    let {
      width,
      height
    } = _ref3;
    const location = this._elementLocation;
    const sides = this._movingSides;
    const $element = this.$element();
    const elementRect = this._getElementSize();
    const offsetTop = delta.y * (sides.top ? -1 : 1) - ((elementRect.height || height) - height);
    const offsetLeft = delta.x * (sides.left ? -1 : 1) - ((elementRect.width || width) - width);
    move($element, {
      top: location.top + (sides.top ? offsetTop : 0),
      left: location.left + (sides.left ? offsetLeft : 0)
    });
  },
  _dragHandler(e) {
    const offset = this._getOffset(e);
    const delta = this._getDeltaByOffset(offset);
    const dimensions = this._updateDimensions(delta);
    this._updatePosition(delta, dimensions);
    this._triggerResizeAction(e, dimensions);
  },
  _updateDimensions(delta) {
    const isAbsoluteSize = (size2) => "px" === size2.substring(size2.length - 2);
    const isStepPrecisionStrict = "strict" === this.option("stepPrecision");
    const size = this._elementSize;
    const width = size.width + delta.x;
    const height = size.height + delta.y;
    const elementStyle = this.$element().get(0).style;
    const shouldRenderWidth = delta.x || isStepPrecisionStrict || isAbsoluteSize(elementStyle.width);
    const shouldRenderHeight = delta.y || isStepPrecisionStrict || isAbsoluteSize(elementStyle.height);
    if (shouldRenderWidth) {
      this.option({
        width
      });
    }
    if (shouldRenderHeight) {
      this.option({
        height
      });
    }
    return {
      width: shouldRenderWidth ? width : size.width,
      height: shouldRenderHeight ? height : size.height
    };
  },
  _triggerResizeAction(e, _ref4) {
    let {
      width,
      height
    } = _ref4;
    this._resizeAction({
      event: e,
      width: this.option("width") || width,
      height: this.option("height") || height,
      handles: this._movingSides
    });
    triggerResizeEvent(this.$element());
  },
  _isCornerHandler: (sides) => 0 === Object.values(sides).reduce((xor, value) => xor ^ value, 0),
  _getOffset(e) {
    const {
      offset
    } = e;
    const sides = this._movingSides;
    if (!sides.left && !sides.right) {
      offset.x = 0;
    }
    if (!sides.top && !sides.bottom) {
      offset.y = 0;
    }
    return offset;
  },
  _roundByStep(delta) {
    return "strict" === this.option("stepPrecision") ? this._roundStrict(delta) : this._roundNotStrict(delta);
  },
  _getSteps() {
    return pairToObject(this.option("step"), !this.option("roundStepValue"));
  },
  _roundNotStrict(delta) {
    const steps = this._getSteps();
    return {
      x: delta.x - delta.x % steps.h,
      y: delta.y - delta.y % steps.v
    };
  },
  _roundStrict(delta) {
    const sides = this._movingSides;
    const offset = {
      x: delta.x * (sides.left ? -1 : 1),
      y: delta.y * (sides.top ? -1 : 1)
    };
    const steps = this._getSteps();
    const location = this._elementLocation;
    const size = this._elementSize;
    const xPos = sides.left ? location.left : location.left + size.width;
    const yPos = sides.top ? location.top : location.top + size.height;
    const newXShift = (xPos + offset.x) % steps.h;
    const newYShift = (yPos + offset.y) % steps.v;
    const sign = Math.sign || ((x) => {
      x = +x;
      if (0 === x || isNaN(x)) {
        return x;
      }
      return x > 0 ? 1 : -1;
    });
    const separatorOffset = (steps2, offset2) => (1 + 0.2 * sign(offset2)) % 1 * steps2;
    const isSmallOffset = (offset2, steps2) => Math.abs(offset2) < 0.2 * steps2;
    let newOffsetX = offset.x - newXShift;
    let newOffsetY = offset.y - newYShift;
    if (newXShift > separatorOffset(steps.h, offset.x)) {
      newOffsetX += steps.h;
    }
    if (newYShift > separatorOffset(steps.v, offset.y)) {
      newOffsetY += steps.v;
    }
    const roundedOffset_x = (sides.left || sides.right) && !isSmallOffset(offset.x, steps.h) ? newOffsetX : 0, roundedOffset_y = (sides.top || sides.bottom) && !isSmallOffset(offset.y, steps.v) ? newOffsetY : 0;
    return {
      x: roundedOffset_x * (sides.left ? -1 : 1),
      y: roundedOffset_y * (sides.top ? -1 : 1)
    };
  },
  _getMovingSides(e) {
    const $target = renderer_default(e.target);
    const hasCornerTopLeftClass = $target.hasClass("dx-resizable-handle-corner-top-left");
    const hasCornerTopRightClass = $target.hasClass("dx-resizable-handle-corner-top-right");
    const hasCornerBottomLeftClass = $target.hasClass("dx-resizable-handle-corner-bottom-left");
    const hasCornerBottomRightClass = $target.hasClass("dx-resizable-handle-corner-bottom-right");
    return {
      top: $target.hasClass("dx-resizable-handle-top") || hasCornerTopLeftClass || hasCornerTopRightClass,
      left: $target.hasClass("dx-resizable-handle-left") || hasCornerTopLeftClass || hasCornerBottomLeftClass,
      bottom: $target.hasClass("dx-resizable-handle-bottom") || hasCornerBottomLeftClass || hasCornerBottomRightClass,
      right: $target.hasClass("dx-resizable-handle-right") || hasCornerTopRightClass || hasCornerBottomRightClass
    };
  },
  _getArea() {
    let area = this.option("area");
    if (isFunction(area)) {
      area = area.call(this);
    }
    if (isPlainObject(area)) {
      return this._getAreaFromObject(area);
    }
    return this._getAreaFromElement(area);
  },
  _getAreaScrollOffset() {
    const area = this.option("area");
    const isElement = !isFunction(area) && !isPlainObject(area);
    const scrollOffset = {
      scrollY: 0,
      scrollX: 0
    };
    if (isElement) {
      const areaElement = renderer_default(area)[0];
      if (isWindow(areaElement)) {
        scrollOffset.scrollX = areaElement.pageXOffset;
        scrollOffset.scrollY = areaElement.pageYOffset;
      }
    }
    return scrollOffset;
  },
  _getAreaFromObject(area) {
    const result = {
      width: area.right - area.left,
      height: area.bottom - area.top,
      offset: {
        left: area.left,
        top: area.top
      }
    };
    this._correctAreaGeometry(result);
    return result;
  },
  _getAreaFromElement(area) {
    const $area = renderer_default(area);
    let result;
    if ($area.length) {
      result = {
        width: getInnerWidth($area),
        height: getInnerHeight($area),
        offset: extend({
          top: 0,
          left: 0
        }, isWindow($area[0]) ? {} : $area.offset())
      };
      this._correctAreaGeometry(result, $area);
    }
    return result;
  },
  _correctAreaGeometry(result, $area) {
    const areaBorderLeft = $area ? this._getBorderWidth($area, "left") : 0;
    const areaBorderTop = $area ? this._getBorderWidth($area, "top") : 0;
    result.offset.left += areaBorderLeft + this._getBorderWidth(this.$element(), "left");
    result.offset.top += areaBorderTop + this._getBorderWidth(this.$element(), "top");
    result.width -= getOuterWidth(this.$element()) - getInnerWidth(this.$element());
    result.height -= getOuterHeight(this.$element()) - getInnerHeight(this.$element());
  },
  _dragEndHandler(e) {
    const $element = this.$element();
    this._resizeEndAction({
      event: e,
      width: getOuterWidth($element),
      height: getOuterHeight($element),
      handles: this._movingSides
    });
    this._toggleResizingClass(false);
  },
  _renderWidth(width) {
    this.option("width", fitIntoRange(width, this.option("minWidth"), this.option("maxWidth")));
  },
  _renderHeight(height) {
    this.option("height", fitIntoRange(height, this.option("minHeight"), this.option("maxHeight")));
  },
  _optionChanged(args) {
    switch (args.name) {
      case "disabled":
        this._toggleEventHandlers(!args.value);
        this.callBase(args);
        break;
      case "handles":
        this._invalidate();
        break;
      case "minWidth":
      case "maxWidth":
        hasWindow() && this._renderWidth(getOuterWidth(this.$element()));
        break;
      case "minHeight":
      case "maxHeight":
        hasWindow() && this._renderHeight(getOuterHeight(this.$element()));
        break;
      case "onResize":
      case "onResizeStart":
      case "onResizeEnd":
        this._renderActions();
        break;
      case "area":
      case "stepPrecision":
      case "step":
      case "roundStepValue":
      case "keepAspectRatio":
        break;
      default:
        this.callBase(args);
    }
  },
  _clean() {
    this.$element().find(".dx-resizable-handle").remove();
  },
  _useTemplates: () => false
});
component_registrator_default(RESIZABLE, Resizable);
var m_resizable_default = Resizable;

// node_modules/devextreme/esm/ui/resizable.js
var resizable_default = m_resizable_default;

// node_modules/devextreme/esm/__internal/ui/collection/m_collection_widget.live_update.js
var PRIVATE_KEY_FIELD = "__dx_key__";
var m_collection_widget_live_update_default = m_collection_widget_edit_default.inherit({
  _getDefaultOptions() {
    return extend(this.callBase(), {
      repaintChangesOnly: false
    });
  },
  ctor() {
    var _this$_dataController;
    this.callBase.apply(this, arguments);
    this._customizeStoreLoadOptions = (e) => {
      const dataController = this._dataController;
      if (dataController.getDataSource() && !this._dataController.isLoaded()) {
        this._correctionIndex = 0;
      }
      if (this._correctionIndex && e.storeLoadOptions) {
        e.storeLoadOptions.skip += this._correctionIndex;
      }
    };
    null === (_this$_dataController = this._dataController) || void 0 === _this$_dataController || _this$_dataController.on("customizeStoreLoadOptions", this._customizeStoreLoadOptions);
  },
  reload() {
    this._correctionIndex = 0;
  },
  _init() {
    this.callBase();
    this._refreshItemsCache();
    this._correctionIndex = 0;
  },
  _findItemElementByKey(key) {
    let result = renderer_default();
    const keyExpr = this.key();
    this.itemElements().each((_, item) => {
      const $item = renderer_default(item);
      const itemData = this._getItemData($item);
      if (keyExpr ? keysEqual(keyExpr, this.keyOf(itemData), key) : this._isItemEquals(itemData, key)) {
        result = $item;
        return false;
      }
    });
    return result;
  },
  _dataSourceChangedHandler(newItems, e) {
    if (null !== e && void 0 !== e && e.changes) {
      this._modifyByChanges(e.changes);
    } else {
      this.callBase(newItems, e);
      this._refreshItemsCache();
    }
  },
  _isItemEquals(item1, item2) {
    if (item1 && item1.__dx_key__) {
      item1 = item1.data;
    }
    try {
      return JSON.stringify(item1) === JSON.stringify(item2);
    } catch (e) {
      return item1 === item2;
    }
  },
  _isItemStrictEquals(item1, item2) {
    return this._isItemEquals(item1, item2);
  },
  _shouldAddNewGroup(changes, items) {
    let result = false;
    if (this.option("grouped")) {
      if (!changes.length) {
        result = true;
      }
      each(changes, (i, change) => {
        if ("insert" === change.type) {
          result = true;
          each(items, (_, item) => {
            if (void 0 !== change.data.key && change.data.key === item.key) {
              result = false;
              return false;
            }
          });
        }
      });
    }
    return result;
  },
  _partialRefresh() {
    if (this.option("repaintChangesOnly")) {
      const keyOf = (data) => {
        if (data && void 0 !== data.__dx_key__) {
          return data.__dx_key__;
        }
        return this.keyOf(data);
      };
      const result = findChanges(this._itemsCache, this._editStrategy.itemsGetter(), keyOf, this._isItemStrictEquals.bind(this));
      if (result && this._itemsCache.length && !this._shouldAddNewGroup(result, this._itemsCache)) {
        this._modifyByChanges(result, true);
        this._renderEmptyMessage();
        return true;
      }
      this._refreshItemsCache();
    }
    return false;
  },
  _refreshItemsCache() {
    if (this.option("repaintChangesOnly")) {
      const items = this._editStrategy.itemsGetter();
      try {
        this._itemsCache = extend(true, [], items);
        if (!this.key()) {
          this._itemsCache = this._itemsCache.map((itemCache, index) => ({
            [PRIVATE_KEY_FIELD]: items[index],
            data: itemCache
          }));
        }
      } catch (e) {
        this._itemsCache = extend([], items);
      }
    }
  },
  _dispose() {
    this._dataController.off("customizeStoreLoadOptions", this._customizeStoreLoadOptions);
    this.callBase();
  },
  _updateByChange(keyInfo, items, change, isPartialRefresh) {
    if (isPartialRefresh) {
      this._renderItem(change.index, change.data, null, this._findItemElementByKey(change.key));
    } else {
      const changedItem = items[indexByKey(keyInfo, items, change.key)];
      if (changedItem) {
        update(keyInfo, items, change.key, change.data).done(() => {
          this._renderItem(items.indexOf(changedItem), changedItem, null, this._findItemElementByKey(change.key));
        });
      }
    }
  },
  _insertByChange(keyInfo, items, change, isPartialRefresh) {
    when(isPartialRefresh || insert(keyInfo, items, change.data, change.index)).done(() => {
      this._beforeItemElementInserted(change);
      this._renderItem(change.index ?? items.length, change.data);
      this._afterItemElementInserted();
      this._correctionIndex++;
    });
  },
  _updateSelectionAfterRemoveByChange(removeIndex) {
    const selectedIndex = this.option("selectedIndex");
    if (selectedIndex > removeIndex) {
      this.option("selectedIndex", selectedIndex - 1);
    } else if (selectedIndex === removeIndex && 1 === this.option("selectedItems").length) {
      this.option("selectedItems", []);
    } else {
      this._normalizeSelectedItems();
    }
  },
  _beforeItemElementInserted(change) {
    const selectedIndex = this.option("selectedIndex");
    if (change.index <= selectedIndex) {
      this.option("selectedIndex", selectedIndex + 1);
    }
  },
  _afterItemElementInserted: noop,
  _removeByChange(keyInfo, items, change, isPartialRefresh) {
    const index = isPartialRefresh ? change.index : indexByKey(keyInfo, items, change.key);
    const removedItem = isPartialRefresh ? change.oldItem : items[index];
    if (removedItem) {
      const $removedItemElement = this._findItemElementByKey(change.key);
      const deletedActionArgs = this._extendActionArgs($removedItemElement);
      this._waitDeletingPrepare($removedItemElement).done(() => {
        if (isPartialRefresh) {
          this._updateIndicesAfterIndex(index - 1);
          this._afterItemElementDeleted($removedItemElement, deletedActionArgs);
          this._updateSelectionAfterRemoveByChange(index);
        } else {
          this._deleteItemElementByIndex(index);
          this._afterItemElementDeleted($removedItemElement, deletedActionArgs);
        }
      });
      this._correctionIndex--;
    }
  },
  _modifyByChanges(changes, isPartialRefresh) {
    const items = this._editStrategy.itemsGetter();
    const keyInfo = {
      key: this.key.bind(this),
      keyOf: this.keyOf.bind(this)
    };
    const dataController = this._dataController;
    const paginate = dataController.paginate();
    const group = dataController.group();
    if (paginate || group) {
      changes = changes.filter((item) => "insert" !== item.type || void 0 !== item.index);
    }
    changes.forEach((change) => this[`_${change.type}ByChange`](keyInfo, items, change, isPartialRefresh));
    this._renderedItemsCount = items.length;
    this._refreshItemsCache();
    this._fireContentReadyAction();
  },
  _appendItemToContainer($container, $itemFrame, index) {
    const nextSiblingElement = $container.children(this._itemSelector()).get(index);
    dom_adapter_default.insertElement($container.get(0), $itemFrame.get(0), nextSiblingElement);
  },
  _optionChanged(args) {
    switch (args.name) {
      case "items": {
        const isItemsUpdated = this._partialRefresh(args.value);
        if (!isItemsUpdated) {
          this.callBase(args);
        }
        break;
      }
      case "dataSource":
        if (!this.option("repaintChangesOnly") || !args.value) {
          this.option("items", []);
        }
        this.callBase(args);
        break;
      case "repaintChangesOnly":
        break;
      default:
        this.callBase(args);
    }
  }
});

// node_modules/devextreme/esm/ui/collection/ui.collection_widget.live_update.js
var ui_collection_widget_live_update_default = m_collection_widget_live_update_default;

// node_modules/devextreme/esm/__internal/ui/toolbar/m_constants.js
var TOOLBAR_CLASS = "dx-toolbar";

// node_modules/devextreme/esm/__internal/ui/collection/m_collection_widget.async.js
var AsyncCollectionWidget = m_collection_widget_edit_default.inherit({
  _initMarkup() {
    this._deferredItems = [];
    this.callBase();
  },
  _renderItemContent(args) {
    const renderContentDeferred = Deferred();
    const itemDeferred = Deferred();
    this._deferredItems[args.index] = itemDeferred;
    const $itemContent = this.callBase.call(this, args);
    itemDeferred.done(() => {
      renderContentDeferred.resolve($itemContent);
    });
    return renderContentDeferred.promise();
  },
  _onItemTemplateRendered(itemTemplate, renderArgs) {
    return () => {
      this._deferredItems[renderArgs.index].resolve();
    };
  },
  _postProcessRenderItems: noop,
  _renderItemsAsync() {
    const d = Deferred();
    when.apply(this, this._deferredItems).done(() => {
      this._postProcessRenderItems();
      d.resolve();
    });
    return d.promise();
  },
  _clean() {
    this.callBase();
    this._deferredItems = [];
  }
});
var m_collection_widget_async_default = AsyncCollectionWidget;

// node_modules/devextreme/esm/ui/collection/ui.collection_widget.async.js
var ui_collection_widget_async_default = m_collection_widget_async_default;

// node_modules/devextreme/esm/__internal/ui/collection/async.js
var TypedCollectionWidget = ui_collection_widget_async_default;
var async_default = TypedCollectionWidget;

// node_modules/devextreme/esm/__internal/ui/toolbar/m_toolbar.base.js
var TOOLBAR_ITEM_DATA_KEY = "dxToolbarItemDataKey";
var ToolbarBase = class extends async_default {
  _getSynchronizableOptionsForCreateComponent() {
    return super._getSynchronizableOptionsForCreateComponent().filter((item) => "disabled" !== item);
  }
  _initTemplates() {
    super._initTemplates();
    const template = new BindableTemplate(($container, data, rawModel) => {
      if (isPlainObject(data)) {
        const {
          text,
          html,
          widget
        } = data;
        if (text) {
          $container.text(text).wrapInner("<div>");
        }
        if (html) {
          $container.html(html);
        }
        if ("dxDropDownButton" === widget) {
          data.options = data.options ?? {};
          if (!isDefined(data.options.stylingMode)) {
            data.options.stylingMode = this.option("useFlatButtons") ? "text" : "contained";
          }
        }
        if ("dxButton" === widget) {
          if (this.option("useFlatButtons")) {
            data.options = data.options ?? {};
            data.options.stylingMode = data.options.stylingMode ?? "text";
          }
          if (this.option("useDefaultButtons")) {
            data.options = data.options ?? {};
            data.options.type = data.options.type ?? "default";
          }
        }
      } else {
        $container.text(String(data));
      }
      this._getTemplate("dx-polymorph-widget").render({
        container: $container,
        model: rawModel,
        parent: this
      });
    }, ["text", "html", "widget", "options"], this.option("integrationOptions.watchMethod"));
    this._templateManager.addDefaultTemplates({
      item: template,
      menuItem: template
    });
  }
  _getDefaultOptions() {
    return _extends({}, super._getDefaultOptions(), {
      renderAs: "topToolbar",
      grouped: false,
      useFlatButtons: false,
      useDefaultButtons: false
    });
  }
  _defaultOptionsRules() {
    return super._defaultOptionsRules().concat([{
      device: () => isMaterialBased(),
      options: {
        useFlatButtons: true
      }
    }]);
  }
  _itemContainer() {
    return this._$toolbarItemsContainer.find([".dx-toolbar-before", ".dx-toolbar-center", ".dx-toolbar-after"].join(","));
  }
  _itemClass() {
    return "dx-toolbar-item";
  }
  _itemDataKey() {
    return TOOLBAR_ITEM_DATA_KEY;
  }
  _dimensionChanged(dimension) {
    if (this._disposed) {
      return;
    }
    this._arrangeItems();
    this._applyCompactMode();
  }
  _initMarkup() {
    this._renderToolbar();
    this._renderSections();
    super._initMarkup();
  }
  _render() {
    super._render();
    this._renderItemsAsync();
    this._updateDimensionsInMaterial();
  }
  _postProcessRenderItems() {
    this._arrangeItems();
  }
  _renderToolbar() {
    this.$element().addClass(TOOLBAR_CLASS);
    this._$toolbarItemsContainer = renderer_default("<div>").addClass("dx-toolbar-items-container").appendTo(this.$element());
    this.setAria("role", "toolbar");
  }
  _renderSections() {
    const $container = this._$toolbarItemsContainer;
    each(["before", "center", "after"], (_, section) => {
      const sectionClass = `dx-toolbar-${section}`;
      const $section = $container.find(`.${sectionClass}`);
      if (!$section.length) {
        this[`_$${section}Section`] = renderer_default("<div>").addClass(sectionClass).attr("role", "presentation").appendTo($container);
      }
    });
  }
  _arrangeItems(width) {
    var _this$_$beforeSection, _this$_$afterSection;
    const elementWidth = width ?? getWidth(this.$element());
    this._$centerSection.css({
      margin: "0 auto",
      float: "none"
    });
    const beforeRect = getBoundingRect(null === (_this$_$beforeSection = this._$beforeSection) || void 0 === _this$_$beforeSection ? void 0 : _this$_$beforeSection.get(0));
    const afterRect = getBoundingRect(null === (_this$_$afterSection = this._$afterSection) || void 0 === _this$_$afterSection ? void 0 : _this$_$afterSection.get(0));
    this._alignCenterSection(beforeRect, afterRect, elementWidth);
    const $label = this._$toolbarItemsContainer.find(".dx-toolbar-label").eq(0);
    const $section = $label.parent();
    if (!$label.length) {
      return;
    }
    const labelOffset = beforeRect.width ? beforeRect.width : $label.position().left;
    const widthBeforeSection = $section.hasClass("dx-toolbar-before") ? 0 : labelOffset;
    const widthAfterSection = $section.hasClass("dx-toolbar-after") ? 0 : afterRect.width;
    let elemsAtSectionWidth = 0;
    $section.children().not(".dx-toolbar-label").each((index, element) => {
      elemsAtSectionWidth += getOuterWidth(element);
    });
    const freeSpace = elementWidth - elemsAtSectionWidth;
    const sectionMaxWidth = Math.max(freeSpace - widthBeforeSection - widthAfterSection, 0);
    if ($section.hasClass("dx-toolbar-before")) {
      this._alignSection(this._$beforeSection, sectionMaxWidth);
    } else {
      const labelPaddings = getOuterWidth($label) - getWidth($label);
      $label.css("maxWidth", sectionMaxWidth - labelPaddings);
    }
  }
  _alignCenterSection(beforeRect, afterRect, elementWidth) {
    var _this$_$centerSection;
    this._alignSection(this._$centerSection, elementWidth - beforeRect.width - afterRect.width);
    const isRTL = this.option("rtlEnabled");
    const leftRect = isRTL ? afterRect : beforeRect;
    const rightRect = isRTL ? beforeRect : afterRect;
    const centerRect = getBoundingRect(null === (_this$_$centerSection = this._$centerSection) || void 0 === _this$_$centerSection ? void 0 : _this$_$centerSection.get(0));
    if (leftRect.right > centerRect.left || centerRect.right > rightRect.left) {
      this._$centerSection.css({
        marginLeft: leftRect.width,
        marginRight: rightRect.width,
        float: leftRect.width > rightRect.width ? "none" : "right"
      });
    }
  }
  _alignSection($section, maxWidth) {
    const $labels = $section.find(".dx-toolbar-label");
    let labels = $labels.toArray();
    maxWidth -= this._getCurrentLabelsPaddings(labels);
    const currentWidth = this._getCurrentLabelsWidth(labels);
    const difference = Math.abs(currentWidth - maxWidth);
    if (maxWidth < currentWidth) {
      labels = labels.reverse();
      this._alignSectionLabels(labels, difference, false);
    } else {
      this._alignSectionLabels(labels, difference, true);
    }
  }
  _alignSectionLabels(labels, difference, expanding) {
    const getRealLabelWidth = function(label) {
      return getBoundingRect(label).width;
    };
    for (let i = 0; i < labels.length; i++) {
      const $label = renderer_default(labels[i]);
      const currentLabelWidth = Math.ceil(getRealLabelWidth(labels[i]));
      let labelMaxWidth;
      if (expanding) {
        $label.css("maxWidth", "inherit");
      }
      const possibleLabelWidth = Math.ceil(expanding ? getRealLabelWidth(labels[i]) : currentLabelWidth);
      if (possibleLabelWidth < difference) {
        labelMaxWidth = expanding ? possibleLabelWidth : 0;
        difference -= possibleLabelWidth;
      } else {
        labelMaxWidth = expanding ? currentLabelWidth + difference : currentLabelWidth - difference;
        $label.css("maxWidth", labelMaxWidth);
        break;
      }
      $label.css("maxWidth", labelMaxWidth);
    }
  }
  _applyCompactMode() {
    const $element = renderer_default(this.element());
    $element.removeClass("dx-toolbar-compact");
    if (this.option("compactMode") && this._getSummaryItemsSize("width", this._itemElements(), true) > getWidth($element)) {
      $element.addClass("dx-toolbar-compact");
    }
  }
  _getCurrentLabelsWidth(labels) {
    let width = 0;
    labels.forEach((label) => {
      width += getOuterWidth(label);
    });
    return width;
  }
  _getCurrentLabelsPaddings(labels) {
    let padding = 0;
    labels.forEach((label) => {
      padding += getOuterWidth(label) - getWidth(label);
    });
    return padding;
  }
  _renderItem(index, item, itemContainer, $after) {
    const location = item.location ?? "center";
    const container = itemContainer ?? this[`_$${location}Section`];
    const itemHasText = !!(item.text ?? item.html);
    const itemElement = super._renderItem(index, item, container, $after);
    itemElement.toggleClass("dx-toolbar-button", !itemHasText).toggleClass("dx-toolbar-label", itemHasText).addClass(item.cssClass);
    return itemElement;
  }
  _renderGroupedItems() {
    each(this.option("items"), (groupIndex, group) => {
      const groupItems = group.items;
      const $container = renderer_default("<div>").addClass("dx-toolbar-group");
      const location = group.location ?? "center";
      if (!groupItems || !groupItems.length) {
        return;
      }
      each(groupItems, (itemIndex, item) => {
        this._renderItem(itemIndex, item, $container, null);
      });
      this._$toolbarItemsContainer.find(`.dx-toolbar-${location}`).append($container);
    });
  }
  _renderItems(items) {
    const grouped = this.option("grouped") && items.length && items[0].items;
    grouped ? this._renderGroupedItems() : super._renderItems(items);
  }
  _getToolbarItems() {
    return this.option("items") ?? [];
  }
  _renderContentImpl() {
    const items = this._getToolbarItems();
    this.$element().toggleClass("dx-toolbar-mini", 0 === items.length);
    if (this._renderedItemsCount) {
      this._renderItems(items.slice(this._renderedItemsCount));
    } else {
      this._renderItems(items);
    }
    this._applyCompactMode();
  }
  _renderEmptyMessage() {
  }
  _clean() {
    this._$toolbarItemsContainer.children().empty();
    this.$element().empty();
    delete this._$beforeSection;
    delete this._$centerSection;
    delete this._$afterSection;
  }
  _visibilityChanged(visible) {
    if (visible) {
      this._arrangeItems();
    }
  }
  _isVisible() {
    return getWidth(this.$element()) > 0 && getHeight(this.$element()) > 0;
  }
  _getIndexByItem(item) {
    return this._getToolbarItems().indexOf(item);
  }
  _itemOptionChanged(item, property, value, prevValue) {
    super._itemOptionChanged(item, property, value, prevValue);
    this._arrangeItems();
  }
  _optionChanged(args) {
    const {
      name
    } = args;
    switch (name) {
      case "width":
        super._optionChanged(args);
        this._dimensionChanged();
        break;
      case "renderAs":
      case "useFlatButtons":
      case "useDefaultButtons":
        this._invalidate();
        break;
      case "compactMode":
        this._applyCompactMode();
        break;
      case "grouped":
        break;
      default:
        super._optionChanged(args);
    }
  }
  _dispose() {
    super._dispose();
    clearTimeout(this._waitParentAnimationTimeout);
  }
  _updateDimensionsInMaterial() {
    if (isMaterial()) {
      const _waitParentAnimationFinished = () => new Promise((resolve) => {
        const check = () => {
          let readyToResolve = true;
          this.$element().parents().each((_, parent) => {
            if (fx_default.isAnimating(renderer_default(parent))) {
              readyToResolve = false;
              return false;
            }
          });
          if (readyToResolve) {
            resolve();
          }
          return readyToResolve;
        };
        const runCheck = () => {
          clearTimeout(this._waitParentAnimationTimeout);
          this._waitParentAnimationTimeout = setTimeout(() => check() || runCheck(), 15);
        };
        runCheck();
      });
      const _checkWebFontForLabelsLoaded = () => {
        const $labels = this.$element().find(".dx-toolbar-label");
        const promises = [];
        $labels.each((_, label) => {
          const text = renderer_default(label).text();
          const fontWeight = renderer_default(label).css("fontWeight");
          promises.push(waitWebFont(text, fontWeight));
        });
        return Promise.all(promises);
      };
      Promise.all([_waitParentAnimationFinished(), _checkWebFontForLabelsLoaded()]).then(() => {
        this._dimensionChanged();
      });
    }
  }
};
component_registrator_default("dxToolbarBase", ToolbarBase);
var m_toolbar_base_default = ToolbarBase;

// node_modules/devextreme/esm/__internal/ui/popup/m_popup_drag.js
var PopupDrag = class {
  constructor(config) {
    this.init(config);
  }
  init(_ref) {
    let {
      dragEnabled,
      handle,
      draggableElement,
      positionController
    } = _ref;
    this._positionController = positionController;
    this._draggableElement = draggableElement;
    this._handle = handle;
    this._dragEnabled = dragEnabled;
    this.unsubscribe();
    if (!dragEnabled) {
      return;
    }
    this.subscribe();
  }
  moveDown(e) {
    this._moveTo(5, 0, e);
  }
  moveUp(e) {
    this._moveTo(-5, 0, e);
  }
  moveLeft(e) {
    this._moveTo(0, -5, e);
  }
  moveRight(e) {
    this._moveTo(0, 5, e);
  }
  subscribe() {
    const eventNames = this._getEventNames();
    events_engine_default.on(this._handle, eventNames.startEventName, (e) => {
      this._dragStartHandler(e);
    });
    events_engine_default.on(this._handle, eventNames.updateEventName, (e) => {
      this._dragUpdateHandler(e);
    });
    events_engine_default.on(this._handle, eventNames.endEventName, (e) => {
      this._dragEndHandler(e);
    });
  }
  unsubscribe() {
    const eventNames = this._getEventNames();
    events_engine_default.off(this._handle, eventNames.startEventName);
    events_engine_default.off(this._handle, eventNames.updateEventName);
    events_engine_default.off(this._handle, eventNames.endEventName);
  }
  _getEventNames() {
    const startEventName = addNamespace(DRAG_START_EVENT, "overlayDrag");
    const updateEventName = addNamespace(DRAG_EVENT, "overlayDrag");
    const endEventName = addNamespace(DRAG_END_EVENT, "overlayDrag");
    return {
      startEventName,
      updateEventName,
      endEventName
    };
  }
  _dragStartHandler(e) {
    const allowedOffsets = this._getAllowedOffsets();
    this._prevOffset = {
      x: 0,
      y: 0
    };
    e.targetElements = [];
    e.maxTopOffset = allowedOffsets.top;
    e.maxBottomOffset = allowedOffsets.bottom;
    e.maxLeftOffset = allowedOffsets.left;
    e.maxRightOffset = allowedOffsets.right;
  }
  _dragUpdateHandler(e) {
    const targetOffset = {
      top: e.offset.y - this._prevOffset.y,
      left: e.offset.x - this._prevOffset.x
    };
    this._moveByOffset(targetOffset);
    this._prevOffset = e.offset;
  }
  _dragEndHandler(event) {
    this._positionController.dragHandled();
    this._positionController.detectVisualPositionChange(event);
  }
  _moveTo(top, left, e) {
    if (!this._dragEnabled) {
      return;
    }
    e.preventDefault();
    e.stopPropagation();
    const offset = this._fitOffsetIntoAllowedRange(top, left);
    this._moveByOffset(offset);
    this._dragEndHandler(e);
  }
  _fitOffsetIntoAllowedRange(top, left) {
    const allowedOffsets = this._getAllowedOffsets();
    return {
      top: fitIntoRange(top, -allowedOffsets.top, allowedOffsets.bottom),
      left: fitIntoRange(left, -allowedOffsets.left, allowedOffsets.right)
    };
  }
  _getContainerDimensions() {
    const document = dom_adapter_default.getDocument();
    const container = this._positionController.$dragResizeContainer.get(0);
    let containerWidth = getOuterWidth(container);
    let containerHeight = getOuterHeight(container);
    if (isWindow(container)) {
      containerHeight = Math.max(document.body.clientHeight, containerHeight);
      containerWidth = Math.max(document.body.clientWidth, containerWidth);
    }
    return {
      width: containerWidth,
      height: containerHeight
    };
  }
  _getContainerPosition() {
    const container = this._positionController.$dragResizeContainer.get(0);
    return isWindow(container) ? {
      top: 0,
      left: 0
    } : getOffset(container);
  }
  _getElementPosition() {
    return getOffset(this._draggableElement);
  }
  _getInnerDelta() {
    const containerDimensions = this._getContainerDimensions();
    const elementDimensions = this._getElementDimensions();
    return {
      x: containerDimensions.width - elementDimensions.width,
      y: containerDimensions.height - elementDimensions.height
    };
  }
  _getOuterDelta() {
    const {
      width,
      height
    } = this._getElementDimensions();
    const {
      outsideDragFactor
    } = this._positionController;
    return {
      x: width * outsideDragFactor,
      y: height * outsideDragFactor
    };
  }
  _getFullDelta() {
    const fullDelta = this._getInnerDelta();
    const outerDelta = this._getOuterDelta();
    return {
      x: fullDelta.x + outerDelta.x,
      y: fullDelta.y + outerDelta.y
    };
  }
  _getElementDimensions() {
    return {
      width: this._draggableElement.offsetWidth,
      height: this._draggableElement.offsetHeight
    };
  }
  _getAllowedOffsets() {
    const fullDelta = this._getFullDelta();
    const isDragAllowed = fullDelta.y >= 0 && fullDelta.x >= 0;
    if (!isDragAllowed) {
      return {
        top: 0,
        bottom: 0,
        left: 0,
        right: 0
      };
    }
    const elementPosition = this._getElementPosition();
    const containerPosition = this._getContainerPosition();
    const outerDelta = this._getOuterDelta();
    return {
      top: elementPosition.top - containerPosition.top + outerDelta.y,
      bottom: -elementPosition.top + containerPosition.top + fullDelta.y,
      left: elementPosition.left - containerPosition.left + outerDelta.x,
      right: -elementPosition.left + containerPosition.left + fullDelta.x
    };
  }
  _moveByOffset(offset) {
    const currentPosition = locate(this._draggableElement);
    const newPosition = {
      left: currentPosition.left + offset.left,
      top: currentPosition.top + offset.top
    };
    move(this._draggableElement, newPosition);
  }
};
var m_popup_drag_default = PopupDrag;

// node_modules/devextreme/esm/__internal/ui/popup/m_popup_overflow_manager.js
var overflowManagerMock = {
  setOverflow: noop,
  restoreOverflow: noop
};
var createBodyOverflowManager = () => {
  if (!hasWindow()) {
    return overflowManagerMock;
  }
  const window3 = getWindow();
  const {
    documentElement
  } = dom_adapter_default.getDocument();
  const body = dom_adapter_default.getBody();
  const isIosDevice = "ios" === devices_default.real().platform;
  const prevSettings = {
    overflow: null,
    overflowX: null,
    overflowY: null,
    paddingRight: null,
    position: null,
    top: null,
    left: null
  };
  return {
    setOverflow: isIosDevice ? () => {
      if (isDefined(prevSettings.position) || "fixed" === body.style.position) {
        return;
      }
      const {
        scrollY,
        scrollX
      } = window3;
      prevSettings.position = body.style.position;
      prevSettings.top = body.style.top;
      prevSettings.left = body.style.left;
      body.style.setProperty("position", "fixed");
      body.style.setProperty("top", -scrollY + "px");
      body.style.setProperty("left", -scrollX + "px");
    } : () => {
      (() => {
        const scrollBarWidth = window3.innerWidth - documentElement.clientWidth;
        if (prevSettings.paddingRight || scrollBarWidth <= 0) {
          return;
        }
        const paddingRight = window3.getComputedStyle(body).getPropertyValue("padding-right");
        const computedBodyPaddingRight = parseInt(paddingRight, 10);
        prevSettings.paddingRight = computedBodyPaddingRight;
        body.style.setProperty("padding-right", `${computedBodyPaddingRight + scrollBarWidth}px`);
      })();
      if (prevSettings.overflow || "hidden" === body.style.overflow) {
        return;
      }
      prevSettings.overflow = body.style.overflow;
      prevSettings.overflowX = body.style.overflowX;
      prevSettings.overflowY = body.style.overflowY;
      body.style.setProperty("overflow", "hidden");
    },
    restoreOverflow: isIosDevice ? () => {
      if (!isDefined(prevSettings.position)) {
        return;
      }
      const scrollY = -parseInt(body.style.top, 10);
      const scrollX = -parseInt(body.style.left, 10);
      ["position", "top", "left"].forEach((property) => {
        if (prevSettings[property]) {
          body.style.setProperty(property, prevSettings[property]);
        } else {
          body.style.removeProperty(property);
        }
      });
      window3.scrollTo(scrollX, scrollY);
      prevSettings.position = null;
    } : () => {
      (() => {
        if (!isDefined(prevSettings.paddingRight)) {
          return;
        }
        if (prevSettings.paddingRight) {
          body.style.setProperty("padding-right", `${prevSettings.paddingRight}px`);
        } else {
          body.style.removeProperty("padding-right");
        }
        prevSettings.paddingRight = null;
      })();
      ["overflow", "overflowX", "overflowY"].forEach((property) => {
        if (!isDefined(prevSettings[property])) {
          return;
        }
        const propertyInKebabCase = property.replace(/(X)|(Y)/, (symbol) => `-${symbol.toLowerCase()}`);
        if (prevSettings[property]) {
          body.style.setProperty(propertyInKebabCase, prevSettings[property]);
        } else {
          body.style.removeProperty(propertyInKebabCase);
        }
        prevSettings[property] = null;
      });
    }
  };
};

// node_modules/devextreme/esm/__internal/ui/popup/m_popup_position_controller.js
var _excluded = ["fullScreen", "forceApplyBindings", "dragOutsideBoundary", "dragAndResizeArea", "outsideDragFactor"];
var window = getWindow();
var PopupPositionController = class extends OverlayPositionController {
  constructor(_ref) {
    let {
      fullScreen,
      forceApplyBindings,
      dragOutsideBoundary,
      dragAndResizeArea,
      outsideDragFactor
    } = _ref, args = _objectWithoutPropertiesLoose(_ref, _excluded);
    super(args);
    this._props = _extends({}, this._props, {
      fullScreen,
      forceApplyBindings,
      dragOutsideBoundary,
      dragAndResizeArea,
      outsideDragFactor
    });
    this._$dragResizeContainer = void 0;
    this._updateDragResizeContainer();
  }
  set fullScreen(fullScreen) {
    this._props.fullScreen = fullScreen;
    if (fullScreen) {
      this._fullScreenEnabled();
    } else {
      this._fullScreenDisabled();
    }
  }
  get $dragResizeContainer() {
    return this._$dragResizeContainer;
  }
  get outsideDragFactor() {
    if (this._props.dragOutsideBoundary) {
      return 1;
    }
    return this._props.outsideDragFactor;
  }
  set dragAndResizeArea(dragAndResizeArea) {
    this._props.dragAndResizeArea = dragAndResizeArea;
    this._updateDragResizeContainer();
  }
  set dragOutsideBoundary(dragOutsideBoundary) {
    this._props.dragOutsideBoundary = dragOutsideBoundary;
    this._updateDragResizeContainer();
  }
  set outsideDragFactor(outsideDragFactor) {
    this._props.outsideDragFactor = outsideDragFactor;
  }
  updateContainer(containerProp) {
    super.updateContainer(containerProp);
    this._updateDragResizeContainer();
  }
  dragHandled() {
    this.restorePositionOnNextRender(false);
  }
  resizeHandled() {
    this.restorePositionOnNextRender(false);
  }
  positionContent() {
    if (this._props.fullScreen) {
      move(this._$content, {
        top: 0,
        left: 0
      });
      this.detectVisualPositionChange();
    } else {
      var _this$_props$forceApp, _this$_props;
      null === (_this$_props$forceApp = (_this$_props = this._props).forceApplyBindings) || void 0 === _this$_props$forceApp || _this$_props$forceApp.call(_this$_props);
      super.positionContent();
    }
  }
  _updateDragResizeContainer() {
    this._$dragResizeContainer = this._getDragResizeContainer();
  }
  _getDragResizeContainer() {
    if (this._props.dragOutsideBoundary) {
      return renderer_default(window);
    }
    if (this._props.dragAndResizeArea) {
      return renderer_default(this._props.dragAndResizeArea);
    }
    const isContainerDefined = originalViewPort().get(0) || this._props.container;
    return isContainerDefined ? this._$markupContainer : renderer_default(window);
  }
  _getVisualContainer() {
    if (this._props.fullScreen) {
      return renderer_default(window);
    }
    return super._getVisualContainer();
  }
  _fullScreenEnabled() {
    this.restorePositionOnNextRender(false);
  }
  _fullScreenDisabled() {
    this.restorePositionOnNextRender(true);
  }
};

// node_modules/devextreme/esm/__internal/ui/popup/m_popup.js
var window2 = getWindow();
var ALLOWED_TOOLBAR_ITEM_ALIASES = ["cancel", "clear", "done"];
var IS_OLD_SAFARI = browser_default.safari && compare(browser_default.version, [11]) < 0;
var HEIGHT_STRATEGIES = {
  static: "",
  inherit: "dx-popup-inherit-height",
  flex: "dx-popup-flex-height"
};
var getButtonPlace = (name) => {
  const device = devices_default.current();
  const {
    platform
  } = device;
  let toolbar = "bottom";
  let location = "before";
  if ("ios" === platform) {
    switch (name) {
      case "cancel":
        toolbar = "top";
        break;
      case "clear":
        toolbar = "top";
        location = "after";
        break;
      case "done":
        location = "after";
    }
  } else if ("android" === platform) {
    switch (name) {
      case "cancel":
      case "done":
        location = "after";
    }
  }
  return {
    toolbar,
    location
  };
};
var Popup = ui_overlay_default.inherit({
  _supportedKeys() {
    return extend(this.callBase(), {
      upArrow: (e) => {
        var _this$_drag;
        null === (_this$_drag = this._drag) || void 0 === _this$_drag || _this$_drag.moveUp(e);
      },
      downArrow: (e) => {
        var _this$_drag2;
        null === (_this$_drag2 = this._drag) || void 0 === _this$_drag2 || _this$_drag2.moveDown(e);
      },
      leftArrow: (e) => {
        var _this$_drag3;
        null === (_this$_drag3 = this._drag) || void 0 === _this$_drag3 || _this$_drag3.moveLeft(e);
      },
      rightArrow: (e) => {
        var _this$_drag4;
        null === (_this$_drag4 = this._drag) || void 0 === _this$_drag4 || _this$_drag4.moveRight(e);
      }
    });
  },
  _getDefaultOptions() {
    return extend(this.callBase(), {
      fullScreen: false,
      title: "",
      showTitle: true,
      titleTemplate: "title",
      onTitleRendered: null,
      dragOutsideBoundary: false,
      dragEnabled: false,
      dragAndResizeArea: void 0,
      enableBodyScroll: true,
      outsideDragFactor: 0,
      onResizeStart: null,
      onResize: null,
      onResizeEnd: null,
      resizeEnabled: false,
      toolbarItems: [],
      showCloseButton: false,
      bottomTemplate: "bottom",
      useDefaultToolbarButtons: false,
      useFlatToolbarButtons: false,
      autoResizeEnabled: true
    });
  },
  _defaultOptionsRules() {
    return this.callBase().concat([{
      device: {
        platform: "ios"
      },
      options: {
        animation: this._iosAnimation
      }
    }, {
      device: {
        platform: "android"
      },
      options: {
        animation: this._androidAnimation
      }
    }, {
      device: {
        platform: "generic"
      },
      options: {
        showCloseButton: true
      }
    }, {
      device: (device) => "desktop" === devices_default.real().deviceType && "generic" === device.platform,
      options: {
        dragEnabled: true
      }
    }, {
      device: () => "desktop" === devices_default.real().deviceType && !devices_default.isSimulator(),
      options: {
        focusStateEnabled: true
      }
    }, {
      device: () => isMaterialBased(),
      options: {
        useFlatToolbarButtons: true
      }
    }, {
      device: () => isMaterial(),
      options: {
        useDefaultToolbarButtons: true,
        showCloseButton: false
      }
    }]);
  },
  _iosAnimation: {
    show: {
      type: "slide",
      duration: 400,
      from: {
        position: {
          my: "top",
          at: "bottom"
        }
      },
      to: {
        position: {
          my: "center",
          at: "center"
        }
      }
    },
    hide: {
      type: "slide",
      duration: 400,
      from: {
        opacity: 1,
        position: {
          my: "center",
          at: "center"
        }
      },
      to: {
        opacity: 1,
        position: {
          my: "top",
          at: "bottom"
        }
      }
    }
  },
  _androidAnimation() {
    return this.option("fullScreen") ? {
      show: {
        type: "slide",
        duration: 300,
        from: {
          top: "30%",
          opacity: 0
        },
        to: {
          top: 0,
          opacity: 1
        }
      },
      hide: {
        type: "slide",
        duration: 300,
        from: {
          top: 0,
          opacity: 1
        },
        to: {
          top: "30%",
          opacity: 0
        }
      }
    } : {
      show: {
        type: "fade",
        duration: 400,
        from: 0,
        to: 1
      },
      hide: {
        type: "fade",
        duration: 400,
        from: 1,
        to: 0
      }
    };
  },
  _init() {
    const popupWrapperClassExternal = this.option("_wrapperClassExternal");
    const popupWrapperClasses = popupWrapperClassExternal ? `dx-popup-wrapper ${popupWrapperClassExternal}` : "dx-popup-wrapper";
    this.callBase();
    this._createBodyOverflowManager();
    this._updateResizeCallbackSkipCondition();
    this.$element().addClass("dx-popup");
    this.$wrapper().addClass(popupWrapperClasses);
    this._$popupContent = this._$content.wrapInner(renderer_default("<div>").addClass("dx-popup-content")).children().eq(0);
    this._toggleContentScrollClass();
    this.$overlayContent().attr("role", "dialog");
  },
  _render() {
    const isFullscreen = this.option("fullScreen");
    this._toggleFullScreenClass(isFullscreen);
    this.callBase();
  },
  _createBodyOverflowManager() {
    this._bodyOverflowManager = createBodyOverflowManager();
  },
  _toggleFullScreenClass(value) {
    this.$overlayContent().toggleClass("dx-popup-fullscreen", value).toggleClass("dx-popup-normal", !value);
  },
  _initTemplates() {
    this.callBase();
    this._templateManager.addDefaultTemplates({
      title: new EmptyTemplate(),
      bottom: new EmptyTemplate()
    });
  },
  _getActionsList() {
    return this.callBase().concat(["onResizeStart", "onResize", "onResizeEnd"]);
  },
  _contentResizeHandler(entry) {
    if (!this._shouldSkipContentResize(entry)) {
      this._renderGeometry({
        shouldOnlyReposition: true
      });
    }
  },
  _doesShowAnimationChangeDimensions() {
    const animation = this.option("animation");
    return ["to", "from"].some((prop) => {
      var _animation$show;
      const config = null === animation || void 0 === animation || null === (_animation$show = animation.show) || void 0 === _animation$show ? void 0 : _animation$show[prop];
      return isObject(config) && ("width" in config || "height" in config);
    });
  },
  _updateResizeCallbackSkipCondition() {
    const doesShowAnimationChangeDimensions = this._doesShowAnimationChangeDimensions();
    this._shouldSkipContentResize = (entry) => doesShowAnimationChangeDimensions && this._showAnimationProcessing || this._areContentDimensionsRendered(entry);
  },
  _observeContentResize(shouldObserve) {
    if (!this.option("useResizeObserver")) {
      return;
    }
    const contentElement = this._$content.get(0);
    if (shouldObserve) {
      resize_observer_default.observe(contentElement, (entry) => {
        this._contentResizeHandler(entry);
      });
    } else {
      resize_observer_default.unobserve(contentElement);
    }
  },
  _areContentDimensionsRendered(entry) {
    var _entry$contentBoxSize, _this$_renderedDimens3, _this$_renderedDimens4;
    const contentBox = null === (_entry$contentBoxSize = entry.contentBoxSize) || void 0 === _entry$contentBoxSize ? void 0 : _entry$contentBoxSize[0];
    if (contentBox) {
      var _this$_renderedDimens, _this$_renderedDimens2;
      return parseInt(contentBox.inlineSize, 10) === (null === (_this$_renderedDimens = this._renderedDimensions) || void 0 === _this$_renderedDimens ? void 0 : _this$_renderedDimens.width) && parseInt(contentBox.blockSize, 10) === (null === (_this$_renderedDimens2 = this._renderedDimensions) || void 0 === _this$_renderedDimens2 ? void 0 : _this$_renderedDimens2.height);
    }
    const {
      contentRect
    } = entry;
    return parseInt(contentRect.width, 10) === (null === (_this$_renderedDimens3 = this._renderedDimensions) || void 0 === _this$_renderedDimens3 ? void 0 : _this$_renderedDimens3.width) && parseInt(contentRect.height, 10) === (null === (_this$_renderedDimens4 = this._renderedDimensions) || void 0 === _this$_renderedDimens4 ? void 0 : _this$_renderedDimens4.height);
  },
  _renderContent() {
    this.callBase();
    this._observeContentResize(true);
  },
  _renderContentImpl() {
    this._renderTitle();
    this.callBase();
    this._renderResize();
    this._renderBottom();
  },
  _renderTitle() {
    const items = this._getToolbarItems("top");
    const {
      title,
      showTitle
    } = this.option();
    if (showTitle && !!title) {
      items.unshift({
        location: devices_default.current().ios ? "center" : "before",
        text: title
      });
    }
    if (showTitle || items.length > 0) {
      this._$title && this._$title.remove();
      const $title = renderer_default("<div>").addClass("dx-popup-title").insertBefore(this.$content());
      this._$title = this._renderTemplateByType("titleTemplate", items, $title).addClass("dx-popup-title");
      this._renderDrag();
      this._executeTitleRenderAction(this._$title);
      this._$title.toggleClass("dx-has-close-button", this._hasCloseButton());
    } else if (this._$title) {
      this._$title.detach();
    }
    this._toggleAriaLabel();
  },
  _toggleAriaLabel() {
    var _this$_$title;
    const {
      title,
      showTitle
    } = this.option();
    const shouldSetAriaLabel = showTitle && !!title;
    const titleId = shouldSetAriaLabel ? new guid_default() : null;
    null === (_this$_$title = this._$title) || void 0 === _this$_$title || _this$_$title.find(".dx-toolbar-label").eq(0).attr("id", titleId);
    this.$overlayContent().attr("aria-labelledby", titleId);
  },
  _renderTemplateByType(optionName, data, $container, additionalToolbarOptions) {
    const {
      rtlEnabled,
      useDefaultToolbarButtons,
      useFlatToolbarButtons,
      disabled
    } = this.option();
    const template = this._getTemplateByOption(optionName);
    const toolbarTemplate = template instanceof EmptyTemplate;
    if (toolbarTemplate) {
      const integrationOptions = extend({}, this.option("integrationOptions"), {
        skipTemplates: ["content", "title"]
      });
      const toolbarOptions = extend(additionalToolbarOptions, {
        items: data,
        rtlEnabled,
        useDefaultButtons: useDefaultToolbarButtons,
        useFlatButtons: useFlatToolbarButtons,
        disabled,
        integrationOptions
      });
      this._getTemplate("dx-polymorph-widget").render({
        container: $container,
        model: {
          widget: this._getToolbarName(),
          options: toolbarOptions
        }
      });
      const $toolbar = $container.children("div");
      $container.replaceWith($toolbar);
      return $toolbar;
    }
    const $result = renderer_default(template.render({
      container: getPublicElement($container)
    }));
    if ($result.hasClass("dx-template-wrapper")) {
      $container.replaceWith($result);
      $container = $result;
    }
    return $container;
  },
  _getToolbarName: () => "dxToolbarBase",
  _renderVisibilityAnimate(visible) {
    return this.callBase(visible);
  },
  _hide() {
    this._observeContentResize(false);
    return this.callBase();
  },
  _executeTitleRenderAction($titleElement) {
    this._getTitleRenderAction()({
      titleElement: getPublicElement($titleElement)
    });
  },
  _getTitleRenderAction() {
    return this._titleRenderAction || this._createTitleRenderAction();
  },
  _createTitleRenderAction() {
    return this._titleRenderAction = this._createActionByOption("onTitleRendered", {
      element: this.element(),
      excludeValidators: ["disabled", "readOnly"]
    });
  },
  _getCloseButton() {
    return {
      toolbar: "top",
      location: "after",
      template: this._getCloseButtonRenderer()
    };
  },
  _getCloseButtonRenderer() {
    return (_, __, container) => {
      const $button = renderer_default("<div>").addClass("dx-closebutton");
      this._createComponent($button, button_default, {
        icon: "close",
        onClick: this._createToolbarItemAction(void 0),
        stylingMode: "text",
        integrationOptions: {}
      });
      renderer_default(container).append($button);
    };
  },
  _getToolbarItems(toolbar) {
    const toolbarItems = this.option("toolbarItems");
    const toolbarsItems = [];
    this._toolbarItemClasses = [];
    const currentPlatform = devices_default.current().platform;
    let index = 0;
    each(toolbarItems, (_, data) => {
      const isShortcut = isDefined(data.shortcut);
      const item = isShortcut ? getButtonPlace(data.shortcut) : data;
      if (isShortcut && "ios" === currentPlatform && index < 2) {
        item.toolbar = "top";
        index++;
      }
      item.toolbar = data.toolbar || item.toolbar || "top";
      if (item && item.toolbar === toolbar) {
        if (isShortcut) {
          extend(item, {
            location: data.location
          }, this._getToolbarItemByAlias(data));
        }
        const isLTROrder = "generic" === currentPlatform;
        if ("done" === data.shortcut && isLTROrder || "cancel" === data.shortcut && !isLTROrder) {
          toolbarsItems.unshift(item);
        } else {
          toolbarsItems.push(item);
        }
      }
    });
    if ("top" === toolbar && this._hasCloseButton()) {
      toolbarsItems.push(this._getCloseButton());
    }
    return toolbarsItems;
  },
  _hasCloseButton() {
    return this.option("showCloseButton") && this.option("showTitle");
  },
  _getLocalizationKey: (itemType) => "done" === itemType.toLowerCase() ? "OK" : camelize(itemType, true),
  _getToolbarButtonStylingMode(shortcut) {
    if (isFluent()) {
      return "done" === shortcut ? "contained" : "outlined";
    }
    return this.option("useFlatToolbarButtons") ? "text" : "contained";
  },
  _getToolbarButtonType(shortcut) {
    if (isFluent() && "done" === shortcut || this.option("useDefaultToolbarButtons")) {
      return "default";
    }
    return "normal";
  },
  _getToolbarItemByAlias(data) {
    const that = this;
    const itemType = data.shortcut;
    if (!ALLOWED_TOOLBAR_ITEM_ALIASES.includes(itemType)) {
      return false;
    }
    const itemConfig = extend({
      text: message_default.format(this._getLocalizationKey(itemType)),
      onClick: this._createToolbarItemAction(data.onClick),
      integrationOptions: {},
      type: this._getToolbarButtonType(itemType),
      stylingMode: this._getToolbarButtonStylingMode(itemType)
    }, data.options || {});
    const itemClass = `dx-popup-${itemType}`;
    this._toolbarItemClasses.push(itemClass);
    return {
      template(_, __, container) {
        const $toolbarItem = renderer_default("<div>").addClass(itemClass).appendTo(container);
        that._createComponent($toolbarItem, button_default, itemConfig);
      }
    };
  },
  _createToolbarItemAction(clickAction) {
    return this._createAction(clickAction, {
      afterExecute(e) {
        e.component.hide();
      }
    });
  },
  _renderBottom() {
    const items = this._getToolbarItems("bottom");
    if (items.length) {
      this._$bottom && this._$bottom.remove();
      const $bottom = renderer_default("<div>").addClass("dx-popup-bottom").insertAfter(this.$content());
      this._$bottom = this._renderTemplateByType("bottomTemplate", items, $bottom, {
        compactMode: true
      }).addClass("dx-popup-bottom");
      this._toggleClasses();
    } else {
      this._$bottom && this._$bottom.detach();
    }
  },
  _toggleDisabledState(value) {
    this.callBase(...arguments);
    this.$content().toggleClass("dx-state-disabled", Boolean(value));
  },
  _toggleClasses() {
    const aliases = ALLOWED_TOOLBAR_ITEM_ALIASES;
    each(aliases, (_, alias) => {
      const className = `dx-popup-${alias}`;
      if (this._toolbarItemClasses.includes(className)) {
        this.$wrapper().addClass(`${className}-visible`);
        this._$bottom.addClass(className);
      } else {
        this.$wrapper().removeClass(`${className}-visible`);
        this._$bottom.removeClass(className);
      }
    });
  },
  _toggleFocusClass(isFocused, $element) {
    this.callBase(isFocused, $element);
    if (isFocused && !isLastZIndexInStack(this._zIndex)) {
      const zIndex = create(this._zIndexInitValue());
      remove(this._zIndex);
      this._zIndex = zIndex;
      this._$wrapper.css("zIndex", zIndex);
      this._$content.css("zIndex", zIndex);
    }
  },
  _toggleContentScrollClass() {
    const isNativeScrollingEnabled = !this.option("preventScrollEvents");
    this.$content().toggleClass("dx-popup-content-scrollable", isNativeScrollingEnabled);
  },
  _getPositionControllerConfig() {
    const {
      fullScreen,
      forceApplyBindings,
      dragOutsideBoundary,
      dragAndResizeArea,
      outsideDragFactor
    } = this.option();
    return extend({}, this.callBase(), {
      fullScreen,
      forceApplyBindings,
      dragOutsideBoundary,
      dragAndResizeArea,
      outsideDragFactor
    });
  },
  _initPositionController() {
    this._positionController = new PopupPositionController(this._getPositionControllerConfig());
  },
  _getDragTarget() {
    return this.topToolbar();
  },
  _renderGeometry(options) {
    const {
      visible,
      useResizeObserver
    } = this.option();
    if (visible && hasWindow()) {
      const isAnimated = this._showAnimationProcessing;
      const shouldRepeatAnimation = isAnimated && !(null !== options && void 0 !== options && options.forceStopAnimation) && useResizeObserver;
      this._isAnimationPaused = shouldRepeatAnimation || void 0;
      this._stopAnimation();
      if (null !== options && void 0 !== options && options.shouldOnlyReposition) {
        this._renderPosition(false);
      } else {
        this._renderGeometryImpl(null === options || void 0 === options ? void 0 : options.isDimensionChange);
      }
      if (shouldRepeatAnimation) {
        this._animateShowing();
        this._isAnimationPaused = void 0;
      }
    }
  },
  _cacheDimensions() {
    if (!this.option("useResizeObserver")) {
      return;
    }
    this._renderedDimensions = {
      width: parseInt(getWidth(this._$content), 10),
      height: parseInt(getHeight(this._$content), 10)
    };
  },
  _renderGeometryImpl() {
    let isDimensionChange = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : false;
    if (!isDimensionChange) {
      this._resetContentHeight();
    }
    this.callBase();
    this._cacheDimensions();
    this._setContentHeight();
  },
  _resetContentHeight() {
    const height = this._getOptionValue("height");
    if ("auto" === height) {
      this.$content().css({
        height: "auto",
        maxHeight: "none"
      });
    }
  },
  _renderDrag() {
    const $dragTarget = this._getDragTarget();
    const dragEnabled = this.option("dragEnabled");
    if (!$dragTarget) {
      return;
    }
    const config = {
      dragEnabled,
      handle: $dragTarget.get(0),
      draggableElement: this._$content.get(0),
      positionController: this._positionController
    };
    if (this._drag) {
      this._drag.init(config);
    } else {
      this._drag = new m_popup_drag_default(config);
    }
    this.$overlayContent().toggleClass("dx-popup-draggable", dragEnabled);
  },
  _renderResize() {
    this._resizable = this._createComponent(this._$content, resizable_default, {
      handles: this.option("resizeEnabled") ? "all" : "none",
      onResizeEnd: (e) => {
        this._resizeEndHandler(e);
        this._observeContentResize(true);
      },
      onResize: (e) => {
        this._setContentHeight();
        this._actions.onResize(e);
      },
      onResizeStart: (e) => {
        this._observeContentResize(false);
        this._actions.onResizeStart(e);
      },
      minHeight: 100,
      minWidth: 100,
      area: this._positionController.$dragResizeContainer,
      keepAspectRatio: false
    });
  },
  _resizeEndHandler(e) {
    const width = this._resizable.option("width");
    const height = this._resizable.option("height");
    width && this._setOptionWithoutOptionChange("width", width);
    height && this._setOptionWithoutOptionChange("height", height);
    this._cacheDimensions();
    this._positionController.resizeHandled();
    this._positionController.detectVisualPositionChange(e.event);
    this._actions.onResizeEnd(e);
  },
  _setContentHeight() {
    (this.option("forceApplyBindings") || noop)();
    const overlayContent = this.$overlayContent().get(0);
    const currentHeightStrategyClass = this._chooseHeightStrategy(overlayContent);
    this.$content().css(this._getHeightCssStyles(currentHeightStrategyClass, overlayContent));
    this._setHeightClasses(this.$overlayContent(), currentHeightStrategyClass);
  },
  _heightStrategyChangeOffset: (currentHeightStrategyClass, popupVerticalPaddings) => currentHeightStrategyClass === HEIGHT_STRATEGIES.flex ? -popupVerticalPaddings : 0,
  _chooseHeightStrategy(overlayContent) {
    const isAutoWidth = "auto" === overlayContent.style.width || "" === overlayContent.style.width;
    let currentHeightStrategyClass = HEIGHT_STRATEGIES.static;
    if (this._isAutoHeight() && this.option("autoResizeEnabled")) {
      if (isAutoWidth || IS_OLD_SAFARI) {
        currentHeightStrategyClass = HEIGHT_STRATEGIES.inherit;
      } else {
        currentHeightStrategyClass = HEIGHT_STRATEGIES.flex;
      }
    }
    return currentHeightStrategyClass;
  },
  _getHeightCssStyles(currentHeightStrategyClass, overlayContent) {
    let cssStyles = {};
    const contentMaxHeight = this._getOptionValue("maxHeight", overlayContent);
    const contentMinHeight = this._getOptionValue("minHeight", overlayContent);
    const popupHeightParts = this._splitPopupHeight();
    const toolbarsAndVerticalOffsetsHeight = popupHeightParts.header + popupHeightParts.footer + popupHeightParts.contentVerticalOffsets + popupHeightParts.popupVerticalOffsets + this._heightStrategyChangeOffset(currentHeightStrategyClass, popupHeightParts.popupVerticalPaddings);
    if (currentHeightStrategyClass === HEIGHT_STRATEGIES.static) {
      if (!this._isAutoHeight() || contentMaxHeight || contentMinHeight) {
        const overlayHeight = this.option("fullScreen") ? Math.min(getBoundingRect(overlayContent).height, getWindow().innerHeight) : getBoundingRect(overlayContent).height;
        const contentHeight = overlayHeight - toolbarsAndVerticalOffsetsHeight;
        cssStyles = {
          height: Math.max(0, contentHeight),
          minHeight: "auto",
          maxHeight: "auto"
        };
      }
    } else {
      const container = renderer_default(this._positionController.$visualContainer).get(0);
      const maxHeightValue = addOffsetToMaxHeight(contentMaxHeight, -toolbarsAndVerticalOffsetsHeight, container);
      const minHeightValue = addOffsetToMinHeight(contentMinHeight, -toolbarsAndVerticalOffsetsHeight, container);
      cssStyles = {
        height: "auto",
        minHeight: minHeightValue,
        maxHeight: maxHeightValue
      };
    }
    return cssStyles;
  },
  _setHeightClasses($container, currentClass) {
    let excessClasses = "";
    for (const name in HEIGHT_STRATEGIES) {
      if (HEIGHT_STRATEGIES[name] !== currentClass) {
        excessClasses += ` ${HEIGHT_STRATEGIES[name]}`;
      }
    }
    $container.removeClass(excessClasses).addClass(currentClass);
  },
  _isAutoHeight() {
    return "auto" === this.$overlayContent().get(0).style.height;
  },
  _splitPopupHeight() {
    const topToolbar = this.topToolbar();
    const bottomToolbar = this.bottomToolbar();
    return {
      header: getVisibleHeight(topToolbar && topToolbar.get(0)),
      footer: getVisibleHeight(bottomToolbar && bottomToolbar.get(0)),
      contentVerticalOffsets: getVerticalOffsets(this.$overlayContent().get(0), true),
      popupVerticalOffsets: getVerticalOffsets(this.$content().get(0), true),
      popupVerticalPaddings: getVerticalOffsets(this.$content().get(0), false)
    };
  },
  _isAllWindowCovered() {
    return this.callBase() || this.option("fullScreen");
  },
  _renderDimensions() {
    if (this.option("fullScreen")) {
      this.$overlayContent().css({
        width: "100%",
        height: "100%",
        minWidth: "",
        maxWidth: "",
        minHeight: "",
        maxHeight: ""
      });
    } else {
      this.callBase();
    }
    if (hasWindow()) {
      this._renderFullscreenWidthClass();
    }
  },
  _dimensionChanged() {
    this._renderGeometry({
      isDimensionChange: true
    });
  },
  _clean() {
    this.callBase();
    this._observeContentResize(false);
  },
  _dispose() {
    this.callBase();
    this._toggleBodyScroll(true);
  },
  _renderFullscreenWidthClass() {
    this.$overlayContent().toggleClass("dx-popup-fullscreen-width", getOuterWidth(this.$overlayContent()) === getWidth(window2));
  },
  _toggleSafariScrolling() {
    if (!this.option("enableBodyScroll")) {
      return;
    }
    this.callBase();
  },
  _toggleBodyScroll(enabled) {
    if (!this._bodyOverflowManager) {
      return;
    }
    const {
      setOverflow,
      restoreOverflow
    } = this._bodyOverflowManager;
    if (enabled) {
      restoreOverflow();
    } else {
      setOverflow();
    }
  },
  refreshPosition() {
    this._renderPosition();
  },
  _optionChanged(args) {
    var _this$_resizable2;
    const {
      value,
      name
    } = args;
    switch (name) {
      case "disabled":
        this.callBase(args);
        this._renderTitle();
        this._renderBottom();
        break;
      case "animation":
        this._updateResizeCallbackSkipCondition();
        break;
      case "enableBodyScroll":
        if (this.option("visible")) {
          this._toggleBodyScroll(value);
        }
        break;
      case "showTitle":
      case "title":
      case "titleTemplate":
        this._renderTitle();
        this._renderGeometry();
        triggerResizeEvent(this.$overlayContent());
        break;
      case "bottomTemplate":
        this._renderBottom();
        this._renderGeometry();
        triggerResizeEvent(this.$overlayContent());
        break;
      case "container":
        this.callBase(args);
        if (this.option("resizeEnabled")) {
          var _this$_resizable;
          null === (_this$_resizable = this._resizable) || void 0 === _this$_resizable || _this$_resizable.option("area", this._positionController.$dragResizeContainer);
        }
        break;
      case "width":
      case "height":
        this.callBase(args);
        null === (_this$_resizable2 = this._resizable) || void 0 === _this$_resizable2 || _this$_resizable2.option(name, value);
        break;
      case "onTitleRendered":
        this._createTitleRenderAction(value);
        break;
      case "toolbarItems":
      case "useDefaultToolbarButtons":
      case "useFlatToolbarButtons": {
        const shouldRenderGeometry = !args.fullName.match(/^toolbarItems((\[\d+\])(\.(options|visible).*)?)?$/);
        this._renderTitle();
        this._renderBottom();
        if (shouldRenderGeometry) {
          this._renderGeometry();
          triggerResizeEvent(this.$overlayContent());
        }
        break;
      }
      case "dragEnabled":
        this._renderDrag();
        break;
      case "dragAndResizeArea":
        this._positionController.dragAndResizeArea = value;
        if (this.option("resizeEnabled")) {
          this._resizable.option("area", this._positionController.$dragResizeContainer);
        }
        this._positionController.positionContent();
        break;
      case "dragOutsideBoundary":
        this._positionController.dragOutsideBoundary = value;
        if (this.option("resizeEnabled")) {
          this._resizable.option("area", this._positionController.$dragResizeContainer);
        }
        break;
      case "outsideDragFactor":
        this._positionController.outsideDragFactor = value;
        break;
      case "resizeEnabled":
        this._renderResize();
        this._renderGeometry();
        break;
      case "autoResizeEnabled":
        this._renderGeometry();
        triggerResizeEvent(this.$overlayContent());
        break;
      case "fullScreen":
        this._positionController.fullScreen = value;
        this._toggleFullScreenClass(value);
        this._toggleSafariScrolling();
        this._renderGeometry();
        triggerResizeEvent(this.$overlayContent());
        break;
      case "showCloseButton":
        this._renderTitle();
        break;
      case "preventScrollEvents":
        this.callBase(args);
        this._toggleContentScrollClass();
        break;
      default:
        this.callBase(args);
    }
  },
  bottomToolbar() {
    return this._$bottom;
  },
  topToolbar() {
    return this._$title;
  },
  $content() {
    return this._$popupContent;
  },
  content() {
    return getPublicElement(this.$content());
  },
  $overlayContent() {
    return this._$content;
  },
  getFocusableElements() {
    return this.$wrapper().find("[tabindex]").filter((index, item) => item.getAttribute("tabindex") >= 0);
  }
});
component_registrator_default("dxPopup", Popup);
var m_popup_default = Popup;

// node_modules/devextreme/esm/ui/popup/ui.popup.js
var ui_popup_default = m_popup_default;

// node_modules/devextreme/esm/events/swipe.js
var SWIPE_START_EVENT = "dxswipestart";
var SWIPE_EVENT = "dxswipe";
var SWIPE_END_EVENT = "dxswipeend";
var HorizontalStrategy = {
  defaultItemSizeFunc: function() {
    return getWidth(this.getElement());
  },
  getBounds: function() {
    return [this._maxLeftOffset, this._maxRightOffset];
  },
  calcOffsetRatio: function(e) {
    const endEventData = eventData(e);
    return (endEventData.x - (this._savedEventData && this._savedEventData.x || 0)) / this._itemSizeFunc().call(this, e);
  },
  isFastSwipe: function(e) {
    const endEventData = eventData(e);
    return this.FAST_SWIPE_SPEED_LIMIT * Math.abs(endEventData.x - this._tickData.x) >= endEventData.time - this._tickData.time;
  }
};
var VerticalStrategy = {
  defaultItemSizeFunc: function() {
    return getHeight(this.getElement());
  },
  getBounds: function() {
    return [this._maxTopOffset, this._maxBottomOffset];
  },
  calcOffsetRatio: function(e) {
    const endEventData = eventData(e);
    return (endEventData.y - (this._savedEventData && this._savedEventData.y || 0)) / this._itemSizeFunc().call(this, e);
  },
  isFastSwipe: function(e) {
    const endEventData = eventData(e);
    return this.FAST_SWIPE_SPEED_LIMIT * Math.abs(endEventData.y - this._tickData.y) >= endEventData.time - this._tickData.time;
  }
};
var STRATEGIES = {
  horizontal: HorizontalStrategy,
  vertical: VerticalStrategy
};
var SwipeEmitter = emitter_gesture_default.inherit({
  TICK_INTERVAL: 300,
  FAST_SWIPE_SPEED_LIMIT: 10,
  ctor: function(element) {
    this.callBase(element);
    this.direction = "horizontal";
    this.elastic = true;
  },
  _getStrategy: function() {
    return STRATEGIES[this.direction];
  },
  _defaultItemSizeFunc: function() {
    return this._getStrategy().defaultItemSizeFunc.call(this);
  },
  _itemSizeFunc: function() {
    return this.itemSizeFunc || this._defaultItemSizeFunc;
  },
  _init: function(e) {
    this._tickData = eventData(e);
  },
  _start: function(e) {
    this._savedEventData = eventData(e);
    e = this._fireEvent("dxswipestart", e);
    if (!e.cancel) {
      this._maxLeftOffset = e.maxLeftOffset;
      this._maxRightOffset = e.maxRightOffset;
      this._maxTopOffset = e.maxTopOffset;
      this._maxBottomOffset = e.maxBottomOffset;
    }
  },
  _move: function(e) {
    const strategy = this._getStrategy();
    const moveEventData = eventData(e);
    let offset = strategy.calcOffsetRatio.call(this, e);
    offset = this._fitOffset(offset, this.elastic);
    if (moveEventData.time - this._tickData.time > this.TICK_INTERVAL) {
      this._tickData = moveEventData;
    }
    this._fireEvent("dxswipe", e, {
      offset
    });
    if (false !== e.cancelable) {
      e.preventDefault();
    }
  },
  _end: function(e) {
    const strategy = this._getStrategy();
    const offsetRatio = strategy.calcOffsetRatio.call(this, e);
    const isFast = strategy.isFastSwipe.call(this, e);
    let startOffset = offsetRatio;
    let targetOffset = this._calcTargetOffset(offsetRatio, isFast);
    startOffset = this._fitOffset(startOffset, this.elastic);
    targetOffset = this._fitOffset(targetOffset, false);
    this._fireEvent("dxswipeend", e, {
      offset: startOffset,
      targetOffset
    });
  },
  _fitOffset: function(offset, elastic) {
    const strategy = this._getStrategy();
    const bounds = strategy.getBounds.call(this);
    if (offset < -bounds[0]) {
      return elastic ? (-2 * bounds[0] + offset) / 3 : -bounds[0];
    }
    if (offset > bounds[1]) {
      return elastic ? (2 * bounds[1] + offset) / 3 : bounds[1];
    }
    return offset;
  },
  _calcTargetOffset: function(offsetRatio, isFast) {
    let result;
    if (isFast) {
      result = Math.ceil(Math.abs(offsetRatio));
      if (offsetRatio < 0) {
        result = -result;
      }
    } else {
      result = Math.round(offsetRatio);
    }
    return result;
  }
});
emitter_registrator_default({
  emitter: SwipeEmitter,
  events: ["dxswipestart", "dxswipe", "dxswipeend"]
});

// node_modules/devextreme/esm/renovation/utils/type_conversion.js
function toNumber(attribute) {
  return attribute ? Number(attribute.replace("px", "")) : 0;
}

// node_modules/devextreme/esm/renovation/ui/scroll_view/utils/get_element_style.js
function getElementStyle(el) {
  var _getWindow$getCompute, _getWindow;
  return el && hasWindow() ? null === (_getWindow$getCompute = (_getWindow = getWindow()).getComputedStyle) || void 0 === _getWindow$getCompute ? void 0 : _getWindow$getCompute.call(_getWindow, el) : null;
}
function getElementMargin(element, side) {
  const style = getElementStyle(element);
  return style ? toNumber(style[`margin${titleize(side)}`]) : 0;
}

// node_modules/devextreme/esm/__internal/ui/shared/m_grouped_data_converter_mixin.js
var isCorrectStructure = (data) => Array.isArray(data) && data.every((item) => {
  const hasTwoFields = 2 === Object.keys(item).length;
  const hasCorrectFields = "key" in item && "items" in item;
  return hasTwoFields && hasCorrectFields && Array.isArray(item.items);
});
var m_grouped_data_converter_mixin_default = {
  _getSpecificDataSourceOption() {
    let dataSource = this.option("dataSource");
    let hasSimpleItems = false;
    let data = {};
    if (this._getGroupedOption() && isCorrectStructure(dataSource)) {
      data = dataSource.reduce((accumulator, item) => {
        const items = item.items.map((innerItem) => {
          if (!isObject(innerItem)) {
            innerItem = {
              text: innerItem
            };
            hasSimpleItems = true;
          }
          if (!("key" in innerItem)) {
            innerItem.key = item.key;
          }
          return innerItem;
        });
        return accumulator.concat(items);
      }, []);
      dataSource = {
        store: {
          type: "array",
          data
        },
        group: {
          selector: "key",
          keepInitialKeyOrder: true
        }
      };
      if (hasSimpleItems) {
        dataSource.searchExpr = "text";
      }
    }
    return dataSource;
  }
};

// node_modules/devextreme/esm/__internal/ui/list/m_item.js
var ListItem = m_item_default.inherit({
  _renderWatchers() {
    this.callBase();
    this._startWatcher("badge", this._renderBadge.bind(this));
    this._startWatcher("showChevron", this._renderShowChevron.bind(this));
  },
  _renderBadge(badge) {
    this._$element.children(".dx-list-item-badge-container").remove();
    if (!badge) {
      return;
    }
    const $badge = renderer_default("<div>").addClass("dx-list-item-badge-container").append(renderer_default("<div>").addClass("dx-list-item-badge").addClass("dx-badge").text(badge));
    const $chevron = this._$element.children(".dx-list-item-chevron-container").first();
    $chevron.length > 0 ? $badge.insertBefore($chevron) : $badge.appendTo(this._$element);
  },
  _renderShowChevron(showChevron) {
    this._$element.children(".dx-list-item-chevron-container").remove();
    if (!showChevron) {
      return;
    }
    const $chevronContainer = renderer_default("<div>").addClass("dx-list-item-chevron-container");
    const $chevron = renderer_default("<div>").addClass("dx-list-item-chevron");
    $chevronContainer.append($chevron).appendTo(this._$element);
  }
});
var m_item_default2 = ListItem;

// node_modules/devextreme/esm/__internal/ui/list/m_list.base.js
var LIST_ITEM_SELECTOR = ".dx-list-item";
var SELECT_ALL_ITEM_SELECTOR = ".dx-list-select-all";
var groupItemsGetter = compileGetter("items");
var _scrollView;
var ListBase = ui_collection_widget_live_update_default.inherit({
  _activeStateUnit: [LIST_ITEM_SELECTOR, SELECT_ALL_ITEM_SELECTOR].join(","),
  _supportedKeys() {
    const that = this;
    const moveFocusPerPage = function(direction) {
      let $item = getEdgeVisibleItem(direction);
      const isFocusedItem = $item.is(that.option("focusedElement"));
      if (isFocusedItem) {
        !function($item2, direction2) {
          let resultPosition = $item2.position().top;
          if ("prev" === direction2) {
            resultPosition = $item2.position().top - getHeight(that.$element()) + getOuterHeight($item2);
          }
          that.scrollTo(resultPosition);
        }($item, direction);
        $item = getEdgeVisibleItem(direction);
      }
      that.option("focusedElement", getPublicElement($item));
      that.scrollToItem($item);
    };
    function getEdgeVisibleItem(direction) {
      const scrollTop = that.scrollTop();
      const containerHeight = getHeight(that.$element());
      let $item = renderer_default(that.option("focusedElement"));
      let isItemVisible = true;
      if (!$item.length) {
        return renderer_default();
      }
      while (isItemVisible) {
        const $nextItem = $item[direction]();
        if (!$nextItem.length) {
          break;
        }
        const nextItemLocation = $nextItem.position().top + getOuterHeight($nextItem) / 2;
        isItemVisible = nextItemLocation < containerHeight + scrollTop && nextItemLocation > scrollTop;
        if (isItemVisible) {
          $item = $nextItem;
        }
      }
      return $item;
    }
    return extend(this.callBase(), {
      leftArrow: noop,
      rightArrow: noop,
      pageUp() {
        moveFocusPerPage("prev");
        return false;
      },
      pageDown() {
        moveFocusPerPage("next");
        return false;
      }
    });
  },
  _getDefaultOptions() {
    return extend(this.callBase(), {
      hoverStateEnabled: true,
      pullRefreshEnabled: false,
      scrollingEnabled: true,
      selectByClick: true,
      showScrollbar: "onScroll",
      useNativeScrolling: true,
      bounceEnabled: true,
      scrollByContent: true,
      scrollByThumb: false,
      pullingDownText: message_default.format("dxList-pullingDownText"),
      pulledDownText: message_default.format("dxList-pulledDownText"),
      refreshingText: message_default.format("dxList-refreshingText"),
      pageLoadingText: message_default.format("dxList-pageLoadingText"),
      onScroll: null,
      onPullRefresh: null,
      onPageLoading: null,
      pageLoadMode: "scrollBottom",
      nextButtonText: message_default.format("dxList-nextButtonText"),
      onItemSwipe: null,
      grouped: false,
      onGroupRendered: null,
      collapsibleGroups: false,
      groupTemplate: "group",
      indicateLoading: true,
      activeStateEnabled: true,
      _itemAttributes: {
        role: "option"
      },
      useInkRipple: false,
      wrapItemText: false,
      _swipeEnabled: true,
      showChevronExpr: (data) => data ? data.showChevron : void 0,
      badgeExpr: (data) => data ? data.badge : void 0
    });
  },
  _defaultOptionsRules() {
    const themeName = current();
    return this.callBase().concat(deviceDependentOptions(), [{
      device: () => !nativeScrolling,
      options: {
        useNativeScrolling: false
      }
    }, {
      device: (device) => !nativeScrolling && !devices_default.isSimulator() && "desktop" === devices_default.real().deviceType && "generic" === device.platform,
      options: {
        showScrollbar: "onHover",
        pageLoadMode: "nextButton"
      }
    }, {
      device: () => "desktop" === devices_default.real().deviceType && !devices_default.isSimulator(),
      options: {
        focusStateEnabled: true
      }
    }, {
      device: () => isMaterial(themeName),
      options: {
        useInkRipple: true
      }
    }, {
      device: () => isMaterialBased(themeName),
      options: {
        pullingDownText: "",
        pulledDownText: "",
        refreshingText: "",
        pageLoadingText: ""
      }
    }]);
  },
  _visibilityChanged(visible) {
    if (visible) {
      this._updateLoadingState(true);
    }
  },
  _itemClass: () => "dx-list-item",
  _itemDataKey: () => "dxListItemData",
  _itemContainer() {
    return this._$container;
  },
  _getItemsContainer() {
    return this._$listContainer;
  },
  _cleanItemContainer() {
    this.callBase();
    const listContainer = this._getItemsContainer();
    renderer_default(listContainer).empty();
    listContainer.appendTo(this._$container);
  },
  _saveSelectionChangeEvent(e) {
    this._selectionChangeEventInstance = e;
  },
  _getSelectionChangeEvent() {
    return this._selectionChangeEventInstance;
  },
  _refreshItemElements() {
    if (!this.option("grouped")) {
      this._itemElementsCache = this._getItemsContainer().children(this._itemSelector());
    } else {
      this._itemElementsCache = this._getItemsContainer().children(".dx-list-group").children(".dx-list-group-body").children(this._itemSelector());
    }
  },
  _modifyByChanges() {
    this.callBase.apply(this, arguments);
    this._refreshItemElements();
    this._updateLoadingState(true);
  },
  reorderItem(itemElement, toItemElement) {
    const promise = this.callBase(itemElement, toItemElement);
    return promise.done(function() {
      this._refreshItemElements();
    });
  },
  deleteItem(itemElement) {
    const promise = this.callBase(itemElement);
    return promise.done(function() {
      this._refreshItemElements();
    });
  },
  _itemElements() {
    return this._itemElementsCache;
  },
  _itemSelectHandler(e) {
    if ("single" === this.option("selectionMode") && this.isItemSelected(e.currentTarget)) {
      return;
    }
    return this.callBase(e);
  },
  _allowDynamicItemsAppend: () => true,
  _init() {
    this.callBase();
    this._dataController.resetDataSourcePageIndex();
    this._$container = this.$element();
    this._$listContainer = renderer_default("<div>").addClass("dx-list-items");
    this._initScrollView();
    this._feedbackShowTimeout = 70;
    this._createGroupRenderAction();
  },
  _scrollBottomMode() {
    return "scrollBottom" === this.option("pageLoadMode");
  },
  _nextButtonMode() {
    return "nextButton" === this.option("pageLoadMode");
  },
  _dataSourceOptions() {
    const scrollBottom = this._scrollBottomMode();
    const nextButton = this._nextButtonMode();
    return extend(this.callBase(), {
      paginate: ensureDefined(scrollBottom || nextButton, true)
    });
  },
  _getGroupedOption() {
    return this.option("grouped");
  },
  _getGroupContainerByIndex(groupIndex) {
    return this._getItemsContainer().find(".dx-list-group").eq(groupIndex).find(".dx-list-group-body");
  },
  _dataSourceFromUrlLoadMode: () => "raw",
  _initScrollView() {
    const scrollingEnabled = this.option("scrollingEnabled");
    const pullRefreshEnabled = scrollingEnabled && this.option("pullRefreshEnabled");
    const autoPagingEnabled = scrollingEnabled && this._scrollBottomMode() && !!this._dataController.getDataSource();
    this._scrollView = this._createComponent(this.$element(), getScrollView(), {
      height: this.option("height"),
      width: this.option("width"),
      disabled: this.option("disabled") || !scrollingEnabled,
      onScroll: this._scrollHandler.bind(this),
      onPullDown: pullRefreshEnabled ? this._pullDownHandler.bind(this) : null,
      onReachBottom: autoPagingEnabled ? this._scrollBottomHandler.bind(this) : null,
      showScrollbar: this.option("showScrollbar"),
      useNative: this.option("useNativeScrolling"),
      bounceEnabled: this.option("bounceEnabled"),
      scrollByContent: this.option("scrollByContent"),
      scrollByThumb: this.option("scrollByThumb"),
      pullingDownText: this.option("pullingDownText"),
      pulledDownText: this.option("pulledDownText"),
      refreshingText: this.option("refreshingText"),
      reachBottomText: this.option("pageLoadingText"),
      useKeyboard: false
    });
    this._$container = renderer_default(this._scrollView.content());
    this._$listContainer.appendTo(this._$container);
    this._toggleWrapItemText(this.option("wrapItemText"));
    this._createScrollViewActions();
  },
  _toggleWrapItemText(value) {
    this._$listContainer.toggleClass("dx-wrap-item-text", value);
  },
  _createScrollViewActions() {
    this._scrollAction = this._createActionByOption("onScroll");
    this._pullRefreshAction = this._createActionByOption("onPullRefresh");
    this._pageLoadingAction = this._createActionByOption("onPageLoading");
  },
  _scrollHandler(e) {
    this._scrollAction && this._scrollAction(e);
  },
  _initTemplates() {
    this._templateManager.addDefaultTemplates({
      group: new BindableTemplate(($container, data) => {
        if (isPlainObject(data)) {
          if (data.key) {
            $container.text(data.key);
          }
        } else {
          $container.text(String(data));
        }
      }, ["key"], this.option("integrationOptions.watchMethod"))
    });
    this.callBase();
  },
  _prepareDefaultItemTemplate(data, $container) {
    this.callBase(data, $container);
    if (data.icon) {
      const $icon = getImageContainer(data.icon).addClass("dx-list-item-icon");
      const $iconContainer = renderer_default("<div>").addClass("dx-list-item-icon-container");
      $iconContainer.append($icon);
      $container.prepend($iconContainer);
    }
  },
  _getBindableFields: () => ["text", "html", "icon"],
  _updateLoadingState(tryLoadMore) {
    const dataController = this._dataController;
    const shouldLoadNextPage = this._scrollBottomMode() && tryLoadMore && !dataController.isLoading() && !this._isLastPage();
    if (this._shouldContinueLoading(shouldLoadNextPage)) {
      this._infiniteDataLoading();
    } else {
      this._scrollView.release(!shouldLoadNextPage && !dataController.isLoading());
      this._toggleNextButton(this._shouldRenderNextButton() && !this._isLastPage());
      this._loadIndicationSuppressed(false);
    }
  },
  _shouldRenderNextButton() {
    return this._nextButtonMode() && this._dataController.isLoaded();
  },
  _isDataSourceFirstLoadCompleted(newValue) {
    if (isDefined(newValue)) {
      this._isFirstLoadCompleted = newValue;
    }
    return this._isFirstLoadCompleted;
  },
  _dataSourceLoadingChangedHandler(isLoading) {
    if (this._loadIndicationSuppressed()) {
      return;
    }
    if (isLoading && this.option("indicateLoading")) {
      this._showLoadingIndicatorTimer = setTimeout(() => {
        const isEmpty = !this._itemElements().length;
        const shouldIndicateLoading = !isEmpty || this._isDataSourceFirstLoadCompleted();
        if (shouldIndicateLoading) {
          var _this$_scrollView;
          null === (_this$_scrollView = this._scrollView) || void 0 === _this$_scrollView || _this$_scrollView.startLoading();
        }
      });
    } else {
      clearTimeout(this._showLoadingIndicatorTimer);
      this._scrollView && this._scrollView.finishLoading();
    }
    if (!isLoading) {
      this._isDataSourceFirstLoadCompleted(false);
    }
  },
  _dataSourceChangedHandler() {
    if (!this._shouldAppendItems() && hasWindow()) {
      this._scrollView && this._scrollView.scrollTo(0);
    }
    this.callBase.apply(this, arguments);
    this._isDataSourceFirstLoadCompleted(true);
  },
  _refreshContent() {
    this._prepareContent();
    this._fireContentReadyAction();
  },
  _hideLoadingIfLoadIndicationOff() {
    if (!this.option("indicateLoading")) {
      this._dataSourceLoadingChangedHandler(false);
    }
  },
  _loadIndicationSuppressed(value) {
    if (!arguments.length) {
      return this._isLoadIndicationSuppressed;
    }
    this._isLoadIndicationSuppressed = value;
  },
  _scrollViewIsFull() {
    const scrollView = this._scrollView;
    return !scrollView || getHeight(scrollView.content()) > getHeight(scrollView.container());
  },
  _pullDownHandler(e) {
    this._pullRefreshAction(e);
    const dataController = this._dataController;
    if (dataController.getDataSource() && !dataController.isLoading()) {
      this._clearSelectedItems();
      dataController.pageIndex(0);
      dataController.reload();
    } else {
      this._updateLoadingState();
    }
  },
  _shouldContinueLoading(shouldLoadNextPage) {
    var _this$_scrollView$scr;
    const isBottomReached = getHeight(this._scrollView.content()) - getHeight(this._scrollView.container()) < ((null === (_this$_scrollView$scr = this._scrollView.scrollOffset()) || void 0 === _this$_scrollView$scr ? void 0 : _this$_scrollView$scr.top) ?? 0);
    return shouldLoadNextPage && (!this._scrollViewIsFull() || isBottomReached);
  },
  _infiniteDataLoading() {
    const isElementVisible = this.$element().is(":visible");
    if (isElementVisible) {
      clearTimeout(this._loadNextPageTimer);
      this._loadNextPageTimer = setTimeout(() => {
        this._loadNextPage();
      });
    }
  },
  _scrollBottomHandler(e) {
    this._pageLoadingAction(e);
    const dataController = this._dataController;
    if (!dataController.isLoading() && !this._isLastPage()) {
      this._loadNextPage();
    } else {
      this._updateLoadingState();
    }
  },
  _renderItems(items) {
    if (this.option("grouped")) {
      each(items, this._renderGroup.bind(this));
      this._attachGroupCollapseEvent();
      this._renderEmptyMessage();
      if (isMaterial()) {
        this.attachGroupHeaderInkRippleEvents();
      }
    } else {
      this.callBase.apply(this, arguments);
    }
    this._refreshItemElements();
    this._updateLoadingState(true);
  },
  _attachGroupCollapseEvent() {
    const eventName = addNamespace(CLICK_EVENT_NAME, this.NAME);
    const $element = this.$element();
    const collapsibleGroups = this.option("collapsibleGroups");
    $element.toggleClass("dx-list-collapsible-groups", collapsibleGroups);
    events_engine_default.off($element, eventName, ".dx-list-group-header");
    if (collapsibleGroups) {
      events_engine_default.on($element, eventName, ".dx-list-group-header", (e) => {
        this._createAction((e2) => {
          const $group = renderer_default(e2.event.currentTarget).parent();
          this._collapseGroupHandler($group);
          if (this.option("focusStateEnabled")) {
            this.option("focusedElement", getPublicElement($group.find(".dx-list-item").eq(0)));
          }
        }, {
          validatingTargetName: "element"
        })({
          event: e
        });
      });
    }
  },
  _collapseGroupHandler($group, toggle) {
    const deferred = Deferred();
    if ($group.hasClass("dx-list-group-collapsed") === toggle) {
      return deferred.resolve();
    }
    const $groupBody = $group.children(".dx-list-group-body");
    const startHeight = getOuterHeight($groupBody);
    let endHeight = 0;
    if (0 === startHeight) {
      setHeight($groupBody, "auto");
      endHeight = getOuterHeight($groupBody);
    }
    $group.toggleClass("dx-list-group-collapsed", toggle);
    fx_default.animate($groupBody, {
      type: "custom",
      from: {
        height: startHeight
      },
      to: {
        height: endHeight
      },
      duration: 200,
      complete: function() {
        this.updateDimensions();
        this._updateLoadingState(true);
        deferred.resolve();
      }.bind(this)
    });
    return deferred.promise();
  },
  _dataSourceLoadErrorHandler() {
    this._forgetNextPageLoading();
    if (this._initialized) {
      this._renderEmptyMessage();
      this._updateLoadingState();
    }
  },
  _initMarkup() {
    this._itemElementsCache = renderer_default();
    this.$element().addClass("dx-list");
    this.callBase();
    this.option("useInkRipple") && this._renderInkRipple();
    this.setAria({
      role: "group",
      roledescription: "list"
    }, this.$element());
    this.setAria({
      role: "application"
    }, this._focusTarget());
    this._setListAria();
  },
  _setListAria() {
    const {
      items,
      allowItemDeleting
    } = this.option();
    const label = allowItemDeleting ? message_default.format("dxList-listAriaLabel-deletable") : message_default.format("dxList-listAriaLabel");
    const listArea = null !== items && void 0 !== items && items.length ? {
      role: "listbox",
      label
    } : {
      role: void 0,
      label: void 0
    };
    this.setAria(listArea, this._$listContainer);
  },
  _focusTarget() {
    return this._itemContainer();
  },
  _renderInkRipple() {
    this._inkRipple = render();
  },
  _toggleActiveState($element, value, e) {
    this.callBase.apply(this, arguments);
    const that = this;
    if (!this._inkRipple) {
      return;
    }
    const config = {
      element: $element,
      event: e
    };
    if (value) {
      if (isMaterial()) {
        this._inkRippleTimer = setTimeout(() => {
          that._inkRipple.showWave(config);
        }, 35);
      } else {
        that._inkRipple.showWave(config);
      }
    } else {
      clearTimeout(this._inkRippleTimer);
      this._inkRipple.hideWave(config);
    }
  },
  _postprocessRenderItem(args) {
    this._refreshItemElements();
    this.callBase.apply(this, arguments);
    if (this.option("_swipeEnabled")) {
      this._attachSwipeEvent(renderer_default(args.itemElement));
    }
  },
  _attachSwipeEvent($itemElement) {
    const endEventName = addNamespace(SWIPE_END_EVENT, this.NAME);
    events_engine_default.on($itemElement, endEventName, this._itemSwipeEndHandler.bind(this));
  },
  _itemSwipeEndHandler(e) {
    this._itemDXEventHandler(e, "onItemSwipe", {
      direction: e.offset < 0 ? "left" : "right"
    });
  },
  _nextButtonHandler(e) {
    this._pageLoadingAction(e);
    const dataController = this._dataController;
    if (dataController.getDataSource() && !dataController.isLoading()) {
      this._scrollView.toggleLoading(true);
      this._$nextButton.detach();
      this._loadIndicationSuppressed(true);
      this._loadNextPage();
    }
  },
  _renderGroup(index, group) {
    const $groupElement = renderer_default("<div>").addClass("dx-list-group").appendTo(this._getItemsContainer());
    const id = `dx-${new guid_default().toString()}`;
    const groupAria = {
      role: "group",
      labelledby: id
    };
    this.setAria(groupAria, $groupElement);
    const $groupHeaderElement = renderer_default("<div>").addClass("dx-list-group-header").attr("id", id).appendTo($groupElement);
    const groupTemplateName = this.option("groupTemplate");
    const groupTemplate = this._getTemplate(group.template || groupTemplateName, group, index, $groupHeaderElement);
    const renderArgs = {
      index,
      itemData: group,
      container: getPublicElement($groupHeaderElement)
    };
    this._createItemByTemplate(groupTemplate, renderArgs);
    renderer_default("<div>").addClass("dx-list-group-header-indicator").prependTo($groupHeaderElement);
    this._renderingGroupIndex = index;
    const $groupBody = renderer_default("<div>").addClass("dx-list-group-body").appendTo($groupElement);
    each(groupItemsGetter(group) || [], (itemIndex, item) => {
      this._renderItem({
        group: index,
        item: itemIndex
      }, item, $groupBody);
    });
    this._groupRenderAction({
      groupElement: getPublicElement($groupElement),
      groupIndex: index,
      groupData: group
    });
  },
  downInkRippleHandler(e) {
    this._toggleActiveState(renderer_default(e.currentTarget), true, e);
  },
  upInkRippleHandler(e) {
    this._toggleActiveState(renderer_default(e.currentTarget), false);
  },
  attachGroupHeaderInkRippleEvents() {
    const $element = this.$element();
    this._downInkRippleHandler = this._downInkRippleHandler || this.downInkRippleHandler.bind(this);
    this._upInkRippleHandler = this._upInkRippleHandler || this.upInkRippleHandler.bind(this);
    const downArguments = [$element, "dxpointerdown", ".dx-list-group-header", this._downInkRippleHandler];
    const upArguments = [$element, "dxpointerup dxpointerout", ".dx-list-group-header", this._upInkRippleHandler];
    events_engine_default.off(...downArguments);
    events_engine_default.on(...downArguments);
    events_engine_default.off(...upArguments);
    events_engine_default.on(...upArguments);
  },
  _createGroupRenderAction() {
    this._groupRenderAction = this._createActionByOption("onGroupRendered");
  },
  _clean() {
    clearTimeout(this._inkRippleTimer);
    if (this._$nextButton) {
      this._$nextButton.remove();
      this._$nextButton = null;
    }
    this.callBase.apply(this, arguments);
  },
  _dispose() {
    this._isDataSourceFirstLoadCompleted(false);
    clearTimeout(this._holdTimer);
    clearTimeout(this._loadNextPageTimer);
    clearTimeout(this._showLoadingIndicatorTimer);
    this.callBase();
  },
  _toggleDisabledState(value) {
    this.callBase(value);
    this._scrollView.option("disabled", value || !this.option("scrollingEnabled"));
  },
  _toggleNextButton(value) {
    const dataController = this._dataController;
    const $nextButton = this._getNextButton();
    this.$element().toggleClass("dx-has-next", value);
    if (value && dataController.isLoaded()) {
      $nextButton.appendTo(this._itemContainer());
    }
    if (!value) {
      $nextButton.detach();
    }
  },
  _getNextButton() {
    if (!this._$nextButton) {
      this._$nextButton = this._createNextButton();
    }
    return this._$nextButton;
  },
  _createNextButton() {
    const $result = renderer_default("<div>").addClass("dx-list-next-button");
    const $button = renderer_default("<div>").appendTo($result);
    this._createComponent($button, button_default, {
      text: this.option("nextButtonText"),
      onClick: this._nextButtonHandler.bind(this),
      type: isMaterialBased() ? "default" : void 0,
      integrationOptions: {}
    });
    return $result;
  },
  _moveFocus() {
    this.callBase.apply(this, arguments);
    this.scrollToItem(this.option("focusedElement"));
  },
  _refresh() {
    if (!hasWindow()) {
      this.callBase();
    } else {
      const scrollTop = this._scrollView.scrollTop();
      this.callBase();
      scrollTop && this._scrollView.scrollTo(scrollTop);
    }
  },
  _optionChanged(args) {
    switch (args.name) {
      case "pageLoadMode":
        this._toggleNextButton(args.value);
        this._initScrollView();
        break;
      case "dataSource":
        this.callBase(args);
        this._initScrollView();
        this._isDataSourceFirstLoadCompleted(false);
        break;
      case "items":
        this.callBase(args);
        this._isDataSourceFirstLoadCompleted(false);
        break;
      case "pullingDownText":
      case "pulledDownText":
      case "refreshingText":
      case "pageLoadingText":
      case "showScrollbar":
      case "bounceEnabled":
      case "scrollByContent":
      case "scrollByThumb":
      case "useNativeScrolling":
      case "scrollingEnabled":
      case "pullRefreshEnabled":
        this._initScrollView();
        this._updateLoadingState(true);
        break;
      case "nextButtonText":
      case "onItemSwipe":
      case "useInkRipple":
      case "grouped":
      case "collapsibleGroups":
      case "groupTemplate":
      case "showChevronExpr":
      case "badgeExpr":
        this._invalidate();
        break;
      case "onScroll":
      case "onPullRefresh":
      case "onPageLoading":
        this._createScrollViewActions();
        break;
      case "wrapItemText":
        this._toggleWrapItemText(args.value);
        break;
      case "onGroupRendered":
        this._createGroupRenderAction();
        break;
      case "width":
      case "height":
        this.callBase(args);
        this._scrollView.option(args.name, args.value);
        this._scrollView.update();
        break;
      case "indicateLoading":
        this._hideLoadingIfLoadIndicationOff();
        break;
      case "visible":
        this.callBase(args);
        this._scrollView.update();
        break;
      case "rtlEnabled":
        this._initScrollView();
        this.callBase(args);
        break;
      case "_swipeEnabled":
      case "selectByClick":
        break;
      default:
        this.callBase(args);
    }
  },
  _extendActionArgs($itemElement) {
    if (!this.option("grouped")) {
      return this.callBase($itemElement);
    }
    const $group = $itemElement.closest(".dx-list-group");
    const $item = $group.find(".dx-list-item");
    return extend(this.callBase($itemElement), {
      itemIndex: {
        group: $group.index(),
        item: $item.index($itemElement)
      }
    });
  },
  expandGroup(groupIndex) {
    const deferred = Deferred();
    const $group = this._getItemsContainer().find(".dx-list-group").eq(groupIndex);
    this._collapseGroupHandler($group, false).done(() => {
      deferred.resolveWith(this);
    });
    return deferred.promise();
  },
  collapseGroup(groupIndex) {
    const deferred = Deferred();
    const $group = this._getItemsContainer().find(".dx-list-group").eq(groupIndex);
    this._collapseGroupHandler($group, true).done(() => {
      deferred.resolveWith(this);
    });
    return deferred;
  },
  updateDimensions() {
    const that = this;
    const deferred = Deferred();
    if (that._scrollView) {
      that._scrollView.update().done(() => {
        !that._scrollViewIsFull() && that._updateLoadingState(true);
        deferred.resolveWith(that);
      });
    } else {
      deferred.resolveWith(that);
    }
    return deferred.promise();
  },
  reload() {
    this.callBase();
    this.scrollTo(0);
    this._pullDownHandler();
  },
  repaint() {
    this.scrollTo(0);
    this.callBase();
  },
  scrollTop() {
    return this._scrollView.scrollOffset().top;
  },
  clientHeight() {
    return this._scrollView.clientHeight();
  },
  scrollHeight() {
    return this._scrollView.scrollHeight();
  },
  scrollBy(distance) {
    this._scrollView.scrollBy(distance);
  },
  scrollTo(location) {
    this._scrollView.scrollTo(location);
  },
  scrollToItem(itemElement) {
    const $item = this._editStrategy.getItemElement(itemElement);
    const item = null === $item || void 0 === $item ? void 0 : $item.get(0);
    this._scrollView.scrollToElement(item, {
      bottom: getElementMargin(item, "bottom")
    });
  },
  _dimensionChanged() {
    this.updateDimensions();
  }
}).include(m_grouped_data_converter_mixin_default);
ListBase.ItemClass = m_item_default2;
function getScrollView() {
  return _scrollView || scroll_view_default;
}

export {
  ui_collection_widget_live_update_default,
  TOOLBAR_CLASS,
  m_toolbar_base_default,
  resizable_default,
  ui_popup_default,
  SWIPE_START_EVENT,
  SWIPE_EVENT,
  SWIPE_END_EVENT,
  toNumber,
  m_grouped_data_converter_mixin_default,
  ListBase
};
//# sourceMappingURL=chunk-6WF2XDOW.js.map
