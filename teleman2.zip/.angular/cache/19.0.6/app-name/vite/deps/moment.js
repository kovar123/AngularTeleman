import {
  require_moment
} from "./chunk-K5W6IUUB.js";
import "./chunk-N6ESDQJH.js";
export default require_moment();
//# sourceMappingURL=moment.js.map
