import {
  fx_default,
  getBoundingRect,
  move,
  ui_overlay_default
} from "./chunk-QXE45QVL.js";
import {
  ui_widget_default
} from "./chunk-ZEY4S4J4.js";
import {
  CLICK_EVENT_NAME,
  EmptyTemplate,
  component_registrator_default,
  getPublicElement,
  triggerResizeEvent
} from "./chunk-MM4NENTZ.js";
import {
  DxComponent,
  DxIntegrationModule,
  DxTemplateHost,
  DxTemplateModule,
  NestedOptionHost,
  WatcherHelper
} from "./chunk-ZXJK4LK6.js";
import {
  camelize,
  getWidth,
  renderer_default,
  setHeight2 as setHeight,
  setWidth2 as setWidth
} from "./chunk-MU4Z4OEA.js";
import {
  events_engine_default
} from "./chunk-RC2BNL3X.js";
import {
  Deferred,
  ensureDefined,
  hasWindow,
  when
} from "./chunk-4BRW6FUL.js";
import {
  extend,
  isDefined,
  isFunction
} from "./chunk-UTUFIS2B.js";
import {
  Component,
  ElementRef,
  Inject,
  Input,
  NgModule,
  NgZone,
  Output,
  PLATFORM_ID,
  TransferState,
  setClassMetadata,
  ɵɵInheritDefinitionFeature,
  ɵɵProvidersFeature,
  ɵɵdefineComponent,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdirectiveInject,
  ɵɵprojection,
  ɵɵprojectionDef
} from "./chunk-JMD3HP77.js";

// node_modules/devextreme/esm/__internal/ui/drawer/m_drawer.animation.js
var animation = {
  moveTo(config) {
    const {
      $element
    } = config;
    const {
      position
    } = config;
    const direction = config.direction || "left";
    const toConfig = {};
    let animationType;
    switch (direction) {
      case "right":
        toConfig.transform = `translate(${position}px, 0px)`;
        animationType = "custom";
        break;
      case "left":
        toConfig.left = position;
        animationType = "slide";
        break;
      case "top":
      case "bottom":
        toConfig.top = position;
        animationType = "slide";
    }
    fx_default.animate($element, {
      type: animationType,
      to: toConfig,
      duration: config.duration,
      complete: config.complete
    });
  },
  margin(config) {
    const {
      $element
    } = config;
    const {
      margin
    } = config;
    const direction = config.direction || "left";
    const toConfig = {};
    toConfig[`margin${camelize(direction, true)}`] = margin;
    fx_default.animate($element, {
      to: toConfig,
      duration: config.duration,
      complete: config.complete
    });
  },
  fade($element, config, duration, completeAction) {
    fx_default.animate($element, {
      type: "fade",
      to: config.to,
      from: config.from,
      duration,
      complete: completeAction
    });
  },
  size(config) {
    const {
      $element
    } = config;
    const {
      size
    } = config;
    const direction = config.direction || "left";
    const marginTop = config.marginTop || 0;
    const {
      duration
    } = config;
    const toConfig = {};
    if ("right" === direction || "left" === direction) {
      toConfig.width = size;
    } else {
      toConfig.height = size;
    }
    if ("bottom" === direction) {
      toConfig.marginTop = marginTop;
    }
    fx_default.animate($element, {
      to: toConfig,
      duration,
      complete: config.complete
    });
  },
  complete($element) {
    fx_default.stop($element, true);
  }
};

// node_modules/devextreme/esm/__internal/ui/drawer/m_drawer.rendering.strategy.js
var DrawerStrategy = class {
  constructor(drawer) {
    this._drawer = drawer;
  }
  getDrawerInstance() {
    return this._drawer;
  }
  renderPanelContent(whenPanelContentRendered) {
    const drawer = this.getDrawerInstance();
    const template = drawer._getTemplate(drawer.option("template"));
    if (template) {
      template.render({
        container: drawer.content(),
        onRendered: () => {
          whenPanelContentRendered.resolve();
        }
      });
    }
  }
  renderPosition(changePositionUsingFxAnimation, animationDuration) {
    const whenPositionAnimationCompleted = Deferred();
    const whenShaderAnimationCompleted = Deferred();
    const drawer = this.getDrawerInstance();
    if (changePositionUsingFxAnimation) {
      when.apply(renderer_default, [whenPositionAnimationCompleted, whenShaderAnimationCompleted]).done(() => {
        drawer._animationCompleteHandler();
      });
    }
    this._internalRenderPosition(changePositionUsingFxAnimation, whenPositionAnimationCompleted);
    if (!changePositionUsingFxAnimation) {
      drawer.resizeViewContent();
    }
    this.renderShaderVisibility(changePositionUsingFxAnimation, animationDuration, whenShaderAnimationCompleted);
  }
  _getPanelOffset(isDrawerOpened) {
    const drawer = this.getDrawerInstance();
    const size = drawer.isHorizontalDirection() ? drawer.getRealPanelWidth() : drawer.getRealPanelHeight();
    if (isDrawerOpened) {
      return -(size - drawer.getMaxSize());
    }
    return -(size - drawer.getMinSize());
  }
  _getPanelSize(isDrawerOpened) {
    return isDrawerOpened ? this.getDrawerInstance().getMaxSize() : this.getDrawerInstance().getMinSize();
  }
  renderShaderVisibility(changePositionUsingFxAnimation, duration, whenAnimationCompleted) {
    const drawer = this.getDrawerInstance();
    const isShaderVisible = drawer.option("opened");
    const fadeConfig = isShaderVisible ? {
      from: 0,
      to: 1
    } : {
      from: 1,
      to: 0
    };
    if (changePositionUsingFxAnimation) {
      animation.fade(renderer_default(drawer._$shader), fadeConfig, duration, () => {
        this._drawer._toggleShaderVisibility(isShaderVisible);
        whenAnimationCompleted.resolve();
      });
    } else {
      drawer._toggleShaderVisibility(isShaderVisible);
      drawer._$shader.css("opacity", fadeConfig.to);
    }
  }
  getPanelContent() {
    return renderer_default(this.getDrawerInstance().content());
  }
  setPanelSize(calcFromRealPanelSize) {
    this.refreshPanelElementSize(calcFromRealPanelSize);
  }
  refreshPanelElementSize(calcFromRealPanelSize) {
    const drawer = this.getDrawerInstance();
    const panelSize = this._getPanelSize(drawer.option("opened"));
    if (drawer.isHorizontalDirection()) {
      setWidth(renderer_default(drawer.content()), calcFromRealPanelSize ? drawer.getRealPanelWidth() : panelSize);
    } else {
      setHeight(renderer_default(drawer.content()), calcFromRealPanelSize ? drawer.getRealPanelHeight() : panelSize);
    }
  }
  isViewContentFirst() {
    return false;
  }
  onPanelContentRendered() {
  }
};
var m_drawer_rendering_strategy_default = DrawerStrategy;

// node_modules/devextreme/esm/__internal/ui/drawer/m_drawer.rendering.strategy.overlap.js
var OverlapStrategy = class extends m_drawer_rendering_strategy_default {
  renderPanelContent(whenPanelContentRendered) {
    delete this._initialPosition;
    const drawer = this.getDrawerInstance();
    const {
      opened,
      minSize
    } = drawer.option();
    drawer._overlay = drawer._createComponent(drawer.content(), ui_overlay_default, {
      shading: false,
      container: drawer.content(),
      visualContainer: drawer.getOverlayTarget(),
      position: this._getOverlayPosition(),
      width: opened ? "auto" : minSize || 0,
      height: "100%",
      templatesRenderAsynchronously: drawer.option("templatesRenderAsynchronously"),
      animation: {
        show: {
          duration: 0
        }
      },
      onPositioned: function(e) {
        this._fixOverlayPosition(e.component.$content());
      }.bind(this),
      contentTemplate: drawer.option("template"),
      onContentReady: (args) => {
        whenPanelContentRendered.resolve();
        this._processOverlayZIndex(args.component.content());
      },
      visible: true,
      propagateOutsideClick: true
    });
  }
  _fixOverlayPosition($overlayContent) {
    const position = ensureDefined(this._initialPosition, {
      left: 0,
      top: 0
    });
    move($overlayContent, position);
    if ("right" === this.getDrawerInstance().calcTargetPosition()) {
      $overlayContent.css("left", "auto");
    }
    if ("bottom" === this.getDrawerInstance().calcTargetPosition()) {
      $overlayContent.css("top", "auto");
      $overlayContent.css("bottom", "0px");
    }
  }
  _getOverlayPosition() {
    const drawer = this.getDrawerInstance();
    const panelPosition = drawer.calcTargetPosition();
    let result = {};
    switch (panelPosition) {
      case "left":
        result = {
          my: "top left",
          at: "top left"
        };
        break;
      case "right":
        result = {
          my: drawer.option("rtlEnabled") ? "top left" : "top right",
          at: "top right"
        };
        break;
      case "top":
      case "bottom":
        result = {
          my: panelPosition,
          at: panelPosition
        };
    }
    result.of = drawer.getOverlayTarget();
    return result;
  }
  refreshPanelElementSize(calcFromRealPanelSize) {
    const drawer = this.getDrawerInstance();
    const overlay = drawer.getOverlay();
    if (drawer.isHorizontalDirection()) {
      overlay.option("height", "100%");
      overlay.option("width", calcFromRealPanelSize ? drawer.getRealPanelWidth() : this._getPanelSize(drawer.option("opened")));
    } else {
      overlay.option("width", getWidth(drawer.getOverlayTarget()));
      overlay.option("height", calcFromRealPanelSize ? drawer.getRealPanelHeight() : this._getPanelSize(drawer.option("opened")));
    }
  }
  onPanelContentRendered() {
    this._updateViewContentStyles();
  }
  _updateViewContentStyles() {
    const drawer = this.getDrawerInstance();
    renderer_default(drawer.viewContent()).css(`padding${camelize(drawer.calcTargetPosition(), true)}`, drawer.option("minSize"));
    renderer_default(drawer.viewContent()).css("transform", "inherit");
  }
  _internalRenderPosition(changePositionUsingFxAnimation, whenAnimationCompleted) {
    const drawer = this.getDrawerInstance();
    const $panel = renderer_default(drawer.content());
    const $panelOverlayContent = drawer.getOverlay().$content();
    const revealMode = drawer.option("revealMode");
    const targetPanelPosition = drawer.calcTargetPosition();
    const panelSize = this._getPanelSize(drawer.option("opened"));
    const panelOffset = this._getPanelOffset(drawer.option("opened")) * drawer._getPositionCorrection();
    const marginTop = drawer.getRealPanelHeight() - panelSize;
    this._updateViewContentStyles();
    if (changePositionUsingFxAnimation) {
      if ("slide" === revealMode) {
        this._initialPosition = drawer.isHorizontalDirection() ? {
          left: panelOffset
        } : {
          top: panelOffset
        };
        animation.moveTo({
          complete: () => {
            whenAnimationCompleted.resolve();
          },
          duration: drawer.option("animationDuration"),
          direction: targetPanelPosition,
          $element: $panel,
          position: panelOffset
        });
      } else if ("expand" === revealMode) {
        this._initialPosition = drawer.isHorizontalDirection() ? {
          left: 0
        } : {
          top: 0
        };
        move($panelOverlayContent, this._initialPosition);
        animation.size({
          complete: () => {
            whenAnimationCompleted.resolve();
          },
          duration: drawer.option("animationDuration"),
          direction: targetPanelPosition,
          $element: $panelOverlayContent,
          size: panelSize,
          marginTop
        });
      }
    } else if ("slide" === revealMode) {
      this._initialPosition = drawer.isHorizontalDirection() ? {
        left: panelOffset
      } : {
        top: panelOffset
      };
      move($panel, this._initialPosition);
    } else if ("expand" === revealMode) {
      this._initialPosition = drawer.isHorizontalDirection() ? {
        left: 0
      } : {
        top: 0
      };
      move($panelOverlayContent, this._initialPosition);
      if (drawer.isHorizontalDirection()) {
        renderer_default($panelOverlayContent).css("width", panelSize);
      } else {
        renderer_default($panelOverlayContent).css("height", panelSize);
        if ("bottom" === targetPanelPosition) {
          renderer_default($panelOverlayContent).css("marginTop", marginTop);
        }
      }
    }
  }
  getPanelContent() {
    return renderer_default(this.getDrawerInstance().getOverlay().content());
  }
  _processOverlayZIndex($element) {
    const styles = renderer_default($element).get(0).style;
    const zIndex = styles.zIndex || 1;
    this.getDrawerInstance().setZIndex(zIndex);
  }
  isViewContentFirst(position) {
    return "right" === position || "bottom" === position;
  }
};
var m_drawer_rendering_strategy_overlap_default = OverlapStrategy;

// node_modules/devextreme/esm/__internal/ui/drawer/m_drawer.rendering.strategy.push.js
var PushStrategy = class extends m_drawer_rendering_strategy_default {
  _internalRenderPosition(changePositionUsingFxAnimation, whenAnimationCompleted) {
    const drawer = this.getDrawerInstance();
    const openedPanelSize = this._getPanelSize(true);
    const contentPosition = this._getPanelSize(drawer.option("opened")) * drawer._getPositionCorrection();
    renderer_default(drawer.content()).css(drawer.isHorizontalDirection() ? "width" : "height", openedPanelSize);
    if (drawer.getMinSize()) {
      let paddingCssPropertyName = "padding";
      switch (drawer.calcTargetPosition()) {
        case "left":
          paddingCssPropertyName += "Right";
          break;
        case "right":
          paddingCssPropertyName += "Left";
          break;
        case "top":
          paddingCssPropertyName += "Bottom";
          break;
        case "bottom":
          paddingCssPropertyName += "Top";
      }
      renderer_default(drawer.viewContent()).css(paddingCssPropertyName, drawer.getMinSize());
    }
    if (changePositionUsingFxAnimation) {
      animation.moveTo({
        $element: renderer_default(drawer.viewContent()),
        position: contentPosition,
        direction: drawer.calcTargetPosition(),
        duration: drawer.option("animationDuration"),
        complete: () => {
          whenAnimationCompleted.resolve();
        }
      });
    } else if (drawer.isHorizontalDirection()) {
      move(renderer_default(drawer.viewContent()), {
        left: contentPosition
      });
    } else {
      move(renderer_default(drawer.viewContent()), {
        top: contentPosition
      });
    }
  }
  onPanelContentRendered() {
    renderer_default(this.getDrawerInstance().viewContent()).addClass("dx-theme-background-color");
  }
};
var m_drawer_rendering_strategy_push_default = PushStrategy;

// node_modules/devextreme/esm/__internal/ui/drawer/m_drawer.rendering.strategy.shrink.js
var ShrinkStrategy = class extends m_drawer_rendering_strategy_default {
  _internalRenderPosition(changePositionUsingFxAnimation, whenAnimationCompleted) {
    const drawer = this.getDrawerInstance();
    const direction = drawer.calcTargetPosition();
    const $panel = renderer_default(drawer.content());
    const panelSize = this._getPanelSize(drawer.option("opened"));
    const panelOffset = this._getPanelOffset(drawer.option("opened"));
    const revealMode = drawer.option("revealMode");
    if (changePositionUsingFxAnimation) {
      if ("slide" === revealMode) {
        animation.margin({
          complete: () => {
            whenAnimationCompleted.resolve();
          },
          $element: $panel,
          duration: drawer.option("animationDuration"),
          direction,
          margin: panelOffset
        });
      } else if ("expand" === revealMode) {
        animation.size({
          complete: () => {
            whenAnimationCompleted.resolve();
          },
          $element: $panel,
          duration: drawer.option("animationDuration"),
          direction,
          size: panelSize
        });
      }
    } else if ("slide" === revealMode) {
      $panel.css(`margin${camelize(direction, true)}`, panelOffset);
    } else if ("expand" === revealMode) {
      $panel.css(drawer.isHorizontalDirection() ? "width" : "height", panelSize);
    }
  }
  isViewContentFirst(position, isRtl) {
    return (isRtl ? "left" === position : "right" === position) || "bottom" === position;
  }
};
var m_drawer_rendering_strategy_shrink_default = ShrinkStrategy;

// node_modules/devextreme/esm/__internal/ui/drawer/m_drawer.js
var Drawer = ui_widget_default.inherit({
  _getDefaultOptions() {
    return extend(this.callBase(), {
      position: "left",
      opened: false,
      minSize: null,
      maxSize: null,
      shading: false,
      template: "panel",
      openedStateMode: "shrink",
      revealMode: "slide",
      animationEnabled: true,
      animationDuration: 400,
      closeOnOutsideClick: false,
      contentTemplate: "content"
    });
  },
  _init() {
    this.callBase();
    this._initStrategy();
    this.$element().addClass("dx-drawer");
    this._whenAnimationCompleted = void 0;
    this._whenPanelContentRendered = void 0;
    this._whenPanelContentRefreshed = void 0;
    this._$wrapper = renderer_default("<div>").addClass("dx-drawer-wrapper");
    this._$viewContentWrapper = renderer_default("<div>").addClass("dx-drawer-content");
    this._$wrapper.append(this._$viewContentWrapper);
    this.$element().append(this._$wrapper);
  },
  _initStrategy() {
    switch (this.option("openedStateMode")) {
      case "push":
      default:
        this._strategy = new m_drawer_rendering_strategy_push_default(this);
        break;
      case "shrink":
        this._strategy = new m_drawer_rendering_strategy_shrink_default(this);
        break;
      case "overlap":
        this._strategy = new m_drawer_rendering_strategy_overlap_default(this);
    }
  },
  _getAnonymousTemplateName: () => "content",
  _initTemplates() {
    const defaultTemplates = {};
    defaultTemplates.panel = new EmptyTemplate();
    defaultTemplates.content = new EmptyTemplate();
    this._templateManager.addDefaultTemplates(defaultTemplates);
    this.callBase();
  },
  _viewContentWrapperClickHandler(e) {
    let closeOnOutsideClick = this.option("closeOnOutsideClick");
    if (isFunction(closeOnOutsideClick)) {
      closeOnOutsideClick = closeOnOutsideClick(e);
    }
    if (closeOnOutsideClick && this.option("opened")) {
      this.stopAnimations();
      if (this.option("shading")) {
        e.preventDefault();
      }
      this.hide();
    }
  },
  _initMarkup() {
    this.callBase();
    this._toggleOpenedStateClass(this.option("opened"));
    this._renderPanelContentWrapper();
    this._refreshOpenedStateModeClass();
    this._refreshRevealModeClass();
    this._renderShader();
    this._refreshPositionClass();
    this._whenPanelContentRendered = Deferred();
    this._strategy.renderPanelContent(this._whenPanelContentRendered);
    this._strategy.onPanelContentRendered();
    this._renderViewContent();
    events_engine_default.off(this._$viewContentWrapper, CLICK_EVENT_NAME);
    events_engine_default.on(this._$viewContentWrapper, CLICK_EVENT_NAME, this._viewContentWrapperClickHandler.bind(this));
    this._refreshWrapperChildrenOrder();
  },
  _render() {
    this._initMinMaxSize();
    this.callBase();
    this._whenPanelContentRendered.always(() => {
      this._initMinMaxSize();
      this._strategy.refreshPanelElementSize("slide" === this.option("revealMode"));
      this._renderPosition(this.option("opened"), true);
      this._removePanelManualPosition();
    });
  },
  _removePanelManualPosition() {
    if (this._$panelContentWrapper.attr("manualposition")) {
      this._$panelContentWrapper.removeAttr("manualPosition");
      this._$panelContentWrapper.css({
        position: "",
        top: "",
        left: "",
        right: "",
        bottom: ""
      });
    }
  },
  _togglePanelContentHiddenClass() {
    const callback = () => {
      const {
        minSize,
        opened
      } = this.option();
      const shouldBeSet = minSize ? false : !opened;
      this._$panelContentWrapper.toggleClass("dx-drawer-panel-content-hidden", shouldBeSet);
    };
    if (this._whenAnimationCompleted && !this.option("opened")) {
      when(this._whenAnimationCompleted).done(callback);
    } else {
      callback();
    }
  },
  _renderPanelContentWrapper() {
    const {
      openedStateMode,
      opened,
      minSize
    } = this.option();
    this._$panelContentWrapper = renderer_default("<div>").addClass("dx-drawer-panel-content");
    this._togglePanelContentHiddenClass();
    const position = this.calcTargetPosition();
    if ("push" === openedStateMode && ["top", "bottom"].includes(position)) {
      this._$panelContentWrapper.addClass("dx-drawer-panel-content-push-top-or-bottom");
    }
    if ("overlap" !== openedStateMode && !opened && !minSize) {
      this._$panelContentWrapper.attr("manualposition", true);
      this._$panelContentWrapper.css({
        position: "absolute",
        top: "-10000px",
        left: "-10000px",
        right: "auto",
        bottom: "auto"
      });
    }
    this._$wrapper.append(this._$panelContentWrapper);
  },
  _refreshOpenedStateModeClass(prevOpenedStateMode) {
    if (prevOpenedStateMode) {
      this.$element().removeClass(`dx-drawer-${prevOpenedStateMode}`);
    }
    this.$element().addClass(`dx-drawer-${this.option("openedStateMode")}`);
  },
  _refreshPositionClass(prevPosition) {
    if (prevPosition) {
      this.$element().removeClass(`dx-drawer-${prevPosition}`);
    }
    this.$element().addClass(`dx-drawer-${this.calcTargetPosition()}`);
  },
  _refreshWrapperChildrenOrder() {
    const position = this.calcTargetPosition();
    if (this._strategy.isViewContentFirst(position, this.option("rtlEnabled"))) {
      this._$wrapper.prepend(this._$viewContentWrapper);
    } else {
      this._$wrapper.prepend(this._$panelContentWrapper);
    }
  },
  _refreshRevealModeClass(prevRevealMode) {
    if (prevRevealMode) {
      this.$element().removeClass(`dx-drawer-${prevRevealMode}`);
    }
    this.$element().addClass(`dx-drawer-${this.option("revealMode")}`);
  },
  _renderViewContent() {
    const contentTemplateOption = this.option("contentTemplate");
    const contentTemplate = this._getTemplate(contentTemplateOption);
    if (contentTemplate) {
      const $viewTemplate = contentTemplate.render({
        container: this.viewContent(),
        noModel: true,
        transclude: this._templateManager.anonymousTemplateName === contentTemplateOption
      });
      if ($viewTemplate.hasClass("ng-scope")) {
        renderer_default(this._$viewContentWrapper).children().not(".dx-drawer-shader").replaceWith($viewTemplate);
      }
    }
  },
  _renderShader() {
    this._$shader = this._$shader || renderer_default("<div>").addClass("dx-drawer-shader");
    this._$shader.appendTo(this.viewContent());
    this._toggleShaderVisibility(this.option("opened"));
  },
  _initSize() {
    this._initMinMaxSize();
  },
  _initMinMaxSize() {
    const realPanelSize = this.isHorizontalDirection() ? this.getRealPanelWidth() : this.getRealPanelHeight();
    this._maxSize = this.option("maxSize") || realPanelSize;
    this._minSize = this.option("minSize") || 0;
  },
  calcTargetPosition() {
    const position = this.option("position");
    const rtl = this.option("rtlEnabled");
    let result = position;
    if ("before" === position) {
      result = rtl ? "right" : "left";
    } else if ("after" === position) {
      result = rtl ? "left" : "right";
    }
    return result;
  },
  getOverlayTarget() {
    return this._$wrapper;
  },
  getOverlay() {
    return this._overlay;
  },
  getMaxSize() {
    return this._maxSize;
  },
  getMinSize() {
    return this._minSize;
  },
  getRealPanelWidth() {
    if (hasWindow()) {
      if (isDefined(this.option("templateSize"))) {
        return this.option("templateSize");
      }
      return getBoundingRect(this._getPanelTemplateElement()).width;
    }
    return 0;
  },
  getRealPanelHeight() {
    if (hasWindow()) {
      if (isDefined(this.option("templateSize"))) {
        return this.option("templateSize");
      }
      return getBoundingRect(this._getPanelTemplateElement()).height;
    }
    return 0;
  },
  _getPanelTemplateElement() {
    const $panelContent = this._strategy.getPanelContent();
    let $result = $panelContent;
    if ($panelContent.children().length) {
      $result = $panelContent.children().eq(0);
      if ($panelContent.hasClass("dx-overlay-content") && $result.hasClass("dx-template-wrapper") && $result.children().length) {
        $result = $result.children().eq(0);
      }
    }
    return $result.get(0);
  },
  getElementHeight($element) {
    const $children = $element.children();
    return $children.length ? getBoundingRect($children.eq(0).get(0)).height : getBoundingRect($element.get(0)).height;
  },
  isHorizontalDirection() {
    const position = this.calcTargetPosition();
    return "left" === position || "right" === position;
  },
  stopAnimations(jumpToEnd) {
    fx_default.stop(this._$shader, jumpToEnd);
    fx_default.stop(renderer_default(this.content()), jumpToEnd);
    fx_default.stop(renderer_default(this.viewContent()), jumpToEnd);
    const overlay = this.getOverlay();
    if (overlay) {
      fx_default.stop(renderer_default(overlay.$content()), jumpToEnd);
    }
  },
  setZIndex(zIndex) {
    this._$shader.css("zIndex", zIndex - 1);
    this._$panelContentWrapper.css("zIndex", zIndex);
  },
  resizeContent() {
    this.resizeViewContent;
  },
  resizeViewContent() {
    triggerResizeEvent(this.viewContent());
  },
  _isInvertedPosition() {
    const position = this.calcTargetPosition();
    return "right" === position || "bottom" === position;
  },
  _renderPosition(isDrawerOpened, disableAnimation, jumpToEnd) {
    this.stopAnimations(jumpToEnd);
    if (!hasWindow()) {
      return;
    }
    renderer_default(this.viewContent()).css("paddingLeft", 0);
    renderer_default(this.viewContent()).css("paddingRight", 0);
    renderer_default(this.viewContent()).css("paddingTop", 0);
    renderer_default(this.viewContent()).css("paddingBottom", 0);
    let animationEnabled = this.option("animationEnabled");
    if (true === disableAnimation) {
      animationEnabled = false;
    }
    if (isDrawerOpened) {
      this._toggleShaderVisibility(isDrawerOpened);
    }
    this._strategy.renderPosition(animationEnabled, this.option("animationDuration"));
  },
  _animationCompleteHandler() {
    this.resizeViewContent();
    if (this._whenAnimationCompleted) {
      this._whenAnimationCompleted.resolve();
    }
  },
  _getPositionCorrection() {
    return this._isInvertedPosition() ? -1 : 1;
  },
  _dispose() {
    animation.complete(renderer_default(this.viewContent()));
    this.callBase();
  },
  _visibilityChanged(visible) {
    if (visible) {
      this._dimensionChanged();
    }
  },
  _dimensionChanged() {
    this._initMinMaxSize();
    this._strategy.refreshPanelElementSize("slide" === this.option("revealMode"));
    this._renderPosition(this.option("opened"), true);
  },
  _toggleShaderVisibility(visible) {
    if (this.option("shading")) {
      this._$shader.toggleClass("dx-state-invisible", !visible);
      this._$shader.css("visibility", visible ? "visible" : "hidden");
    } else {
      this._$shader.toggleClass("dx-state-invisible", true);
    }
  },
  _toggleOpenedStateClass(opened) {
    this.$element().toggleClass("dx-drawer-opened", opened);
  },
  _refreshPanel() {
    renderer_default(this.viewContent()).css("left", 0);
    renderer_default(this.viewContent()).css("transform", "translate(0px, 0px)");
    renderer_default(this.viewContent()).removeClass("dx-theme-background-color");
    this._removePanelContentWrapper();
    this._removeOverlay();
    this._renderPanelContentWrapper();
    this._refreshWrapperChildrenOrder();
    this._whenPanelContentRefreshed = Deferred();
    this._strategy.renderPanelContent(this._whenPanelContentRefreshed);
    this._strategy.onPanelContentRendered();
    if (hasWindow()) {
      this._whenPanelContentRefreshed.always(() => {
        this._strategy.refreshPanelElementSize("slide" === this.option("revealMode"));
        this._renderPosition(this.option("opened"), true, true);
        this._removePanelManualPosition();
      });
    }
  },
  _clean() {
    this._cleanFocusState();
    this._removePanelContentWrapper();
    this._removeOverlay();
  },
  _removePanelContentWrapper() {
    if (this._$panelContentWrapper) {
      this._$panelContentWrapper.remove();
    }
  },
  _removeOverlay() {
    if (this._overlay) {
      this._overlay.dispose();
      delete this._overlay;
      delete this._$panelContentWrapper;
    }
  },
  _optionChanged(args) {
    switch (args.name) {
      case "width":
        this.callBase(args);
        this._dimensionChanged();
        break;
      case "opened":
        this._renderPosition(this.option("opened"));
        this._toggleOpenedStateClass(args.value);
        this._togglePanelContentHiddenClass();
        break;
      case "position":
        this._refreshPositionClass(args.previousValue);
        this._refreshWrapperChildrenOrder();
        this._invalidate();
        break;
      case "contentTemplate":
      case "template":
        this._invalidate();
        break;
      case "openedStateMode":
        this._initStrategy();
        this._refreshOpenedStateModeClass(args.previousValue);
        this._refreshPanel();
        break;
      case "minSize":
        this._initMinMaxSize();
        this._renderPosition(this.option("opened"), true);
        this._togglePanelContentHiddenClass();
        break;
      case "maxSize":
        this._initMinMaxSize();
        this._renderPosition(this.option("opened"), true);
        break;
      case "revealMode":
        this._refreshRevealModeClass(args.previousValue);
        this._refreshPanel();
        break;
      case "shading":
        this._toggleShaderVisibility(this.option("opened"));
        break;
      case "animationEnabled":
      case "animationDuration":
      case "closeOnOutsideClick":
        break;
      default:
        this.callBase(args);
    }
  },
  content() {
    return getPublicElement(this._$panelContentWrapper);
  },
  viewContent() {
    return getPublicElement(this._$viewContentWrapper);
  },
  show() {
    return this.toggle(true);
  },
  hide() {
    return this.toggle(false);
  },
  toggle(opened) {
    const targetOpened = void 0 === opened ? !this.option("opened") : opened;
    this._whenAnimationCompleted = Deferred();
    this.option("opened", targetOpened);
    return this._whenAnimationCompleted.promise();
  }
});
component_registrator_default("dxDrawer", Drawer);
var m_drawer_default = Drawer;

// node_modules/devextreme/esm/ui/drawer.js
var drawer_default = m_drawer_default;

// node_modules/devextreme-angular/fesm2022/devextreme-angular-ui-drawer.mjs
var _c0 = ["*"];
var DxDrawerComponent = class _DxDrawerComponent extends DxComponent {
  instance = null;
  /**
   * Specifies whether the UI component changes its visual state as a result of user interaction.
  
   */
  get activeStateEnabled() {
    return this._getOption("activeStateEnabled");
  }
  set activeStateEnabled(value) {
    this._setOption("activeStateEnabled", value);
  }
  /**
   * Specifies the duration of the drawer&apos;s opening and closing animation (in milliseconds). Applies only if animationEnabled is true.
  
   */
  get animationDuration() {
    return this._getOption("animationDuration");
  }
  set animationDuration(value) {
    this._setOption("animationDuration", value);
  }
  /**
   * Specifies whether to use an opening and closing animation.
  
   */
  get animationEnabled() {
    return this._getOption("animationEnabled");
  }
  set animationEnabled(value) {
    this._setOption("animationEnabled", value);
  }
  /**
   * Specifies whether to close the drawer if a user clicks or taps the view area.
  
   */
  get closeOnOutsideClick() {
    return this._getOption("closeOnOutsideClick");
  }
  set closeOnOutsideClick(value) {
    this._setOption("closeOnOutsideClick", value);
  }
  /**
   * Specifies whether the UI component responds to user interaction.
  
   */
  get disabled() {
    return this._getOption("disabled");
  }
  set disabled(value) {
    this._setOption("disabled", value);
  }
  /**
   * Specifies the global attributes to be attached to the UI component&apos;s container element.
  
   */
  get elementAttr() {
    return this._getOption("elementAttr");
  }
  set elementAttr(value) {
    this._setOption("elementAttr", value);
  }
  /**
   * Specifies the UI component&apos;s height.
  
   */
  get height() {
    return this._getOption("height");
  }
  set height(value) {
    this._setOption("height", value);
  }
  /**
   * Specifies text for a hint that appears when a user pauses on the UI component.
  
   */
  get hint() {
    return this._getOption("hint");
  }
  set hint(value) {
    this._setOption("hint", value);
  }
  /**
   * Specifies whether the UI component changes its state when a user pauses on it.
  
   */
  get hoverStateEnabled() {
    return this._getOption("hoverStateEnabled");
  }
  set hoverStateEnabled(value) {
    this._setOption("hoverStateEnabled", value);
  }
  /**
   * Specifies the drawer&apos;s width or height (depending on the drawer&apos;s position) in the opened state.
  
   */
  get maxSize() {
    return this._getOption("maxSize");
  }
  set maxSize(value) {
    this._setOption("maxSize", value);
  }
  /**
   * Specifies the drawer&apos;s width or height (depending on the drawer&apos;s position) in the closed state.
  
   */
  get minSize() {
    return this._getOption("minSize");
  }
  set minSize(value) {
    this._setOption("minSize", value);
  }
  /**
   * Specifies whether the drawer is opened.
  
   */
  get opened() {
    return this._getOption("opened");
  }
  set opened(value) {
    this._setOption("opened", value);
  }
  /**
   * Specifies how the drawer interacts with the view in the opened state.
  
   */
  get openedStateMode() {
    return this._getOption("openedStateMode");
  }
  set openedStateMode(value) {
    this._setOption("openedStateMode", value);
  }
  /**
   * Specifies the drawer&apos;s position in relation to the view.
  
   */
  get position() {
    return this._getOption("position");
  }
  set position(value) {
    this._setOption("position", value);
  }
  /**
   * Specifies the drawer&apos;s reveal mode.
  
   */
  get revealMode() {
    return this._getOption("revealMode");
  }
  set revealMode(value) {
    this._setOption("revealMode", value);
  }
  /**
   * Switches the UI component to a right-to-left representation.
  
   */
  get rtlEnabled() {
    return this._getOption("rtlEnabled");
  }
  set rtlEnabled(value) {
    this._setOption("rtlEnabled", value);
  }
  /**
   * Specifies whether to shade the view when the drawer is opened.
  
   */
  get shading() {
    return this._getOption("shading");
  }
  set shading(value) {
    this._setOption("shading", value);
  }
  /**
   * Specifies the drawer&apos;s content.
  
   */
  get template() {
    return this._getOption("template");
  }
  set template(value) {
    this._setOption("template", value);
  }
  /**
   * Specifies whether the UI component is visible.
  
   */
  get visible() {
    return this._getOption("visible");
  }
  set visible(value) {
    this._setOption("visible", value);
  }
  /**
   * Specifies the UI component&apos;s width.
  
   */
  get width() {
    return this._getOption("width");
  }
  set width(value) {
    this._setOption("width", value);
  }
  /**
  
   * A function that is executed before the UI component is disposed of.
  
  
   */
  onDisposing;
  /**
  
   * A function used in JavaScript frameworks to save the UI component instance.
  
  
   */
  onInitialized;
  /**
  
   * A function that is executed after a UI component property is changed.
  
  
   */
  onOptionChanged;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  activeStateEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  animationDurationChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  animationEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  closeOnOutsideClickChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  disabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  elementAttrChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  heightChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  hintChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  hoverStateEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  maxSizeChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  minSizeChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  openedChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  openedStateModeChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  positionChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  revealModeChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  rtlEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  shadingChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  templateChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  visibleChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  widthChange;
  constructor(elementRef, ngZone, templateHost, _watcherHelper, optionHost, transferState, platformId) {
    super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
    this._createEventEmitters([{
      subscribe: "disposing",
      emit: "onDisposing"
    }, {
      subscribe: "initialized",
      emit: "onInitialized"
    }, {
      subscribe: "optionChanged",
      emit: "onOptionChanged"
    }, {
      emit: "activeStateEnabledChange"
    }, {
      emit: "animationDurationChange"
    }, {
      emit: "animationEnabledChange"
    }, {
      emit: "closeOnOutsideClickChange"
    }, {
      emit: "disabledChange"
    }, {
      emit: "elementAttrChange"
    }, {
      emit: "heightChange"
    }, {
      emit: "hintChange"
    }, {
      emit: "hoverStateEnabledChange"
    }, {
      emit: "maxSizeChange"
    }, {
      emit: "minSizeChange"
    }, {
      emit: "openedChange"
    }, {
      emit: "openedStateModeChange"
    }, {
      emit: "positionChange"
    }, {
      emit: "revealModeChange"
    }, {
      emit: "rtlEnabledChange"
    }, {
      emit: "shadingChange"
    }, {
      emit: "templateChange"
    }, {
      emit: "visibleChange"
    }, {
      emit: "widthChange"
    }]);
    optionHost.setHost(this);
  }
  _createInstance(element, options) {
    return new drawer_default(element, options);
  }
  ngOnDestroy() {
    this._destroyWidget();
  }
  /** @nocollapse */
  static ɵfac = function DxDrawerComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _DxDrawerComponent)(ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(NgZone), ɵɵdirectiveInject(DxTemplateHost), ɵɵdirectiveInject(WatcherHelper), ɵɵdirectiveInject(NestedOptionHost), ɵɵdirectiveInject(TransferState), ɵɵdirectiveInject(PLATFORM_ID));
  };
  /** @nocollapse */
  static ɵcmp = ɵɵdefineComponent({
    type: _DxDrawerComponent,
    selectors: [["dx-drawer"]],
    inputs: {
      activeStateEnabled: "activeStateEnabled",
      animationDuration: "animationDuration",
      animationEnabled: "animationEnabled",
      closeOnOutsideClick: "closeOnOutsideClick",
      disabled: "disabled",
      elementAttr: "elementAttr",
      height: "height",
      hint: "hint",
      hoverStateEnabled: "hoverStateEnabled",
      maxSize: "maxSize",
      minSize: "minSize",
      opened: "opened",
      openedStateMode: "openedStateMode",
      position: "position",
      revealMode: "revealMode",
      rtlEnabled: "rtlEnabled",
      shading: "shading",
      template: "template",
      visible: "visible",
      width: "width"
    },
    outputs: {
      onDisposing: "onDisposing",
      onInitialized: "onInitialized",
      onOptionChanged: "onOptionChanged",
      activeStateEnabledChange: "activeStateEnabledChange",
      animationDurationChange: "animationDurationChange",
      animationEnabledChange: "animationEnabledChange",
      closeOnOutsideClickChange: "closeOnOutsideClickChange",
      disabledChange: "disabledChange",
      elementAttrChange: "elementAttrChange",
      heightChange: "heightChange",
      hintChange: "hintChange",
      hoverStateEnabledChange: "hoverStateEnabledChange",
      maxSizeChange: "maxSizeChange",
      minSizeChange: "minSizeChange",
      openedChange: "openedChange",
      openedStateModeChange: "openedStateModeChange",
      positionChange: "positionChange",
      revealModeChange: "revealModeChange",
      rtlEnabledChange: "rtlEnabledChange",
      shadingChange: "shadingChange",
      templateChange: "templateChange",
      visibleChange: "visibleChange",
      widthChange: "widthChange"
    },
    standalone: false,
    features: [ɵɵProvidersFeature([DxTemplateHost, WatcherHelper, NestedOptionHost]), ɵɵInheritDefinitionFeature],
    ngContentSelectors: _c0,
    decls: 1,
    vars: 0,
    template: function DxDrawerComponent_Template(rf, ctx) {
      if (rf & 1) {
        ɵɵprojectionDef();
        ɵɵprojection(0);
      }
    },
    encapsulation: 2
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DxDrawerComponent, [{
    type: Component,
    args: [{
      selector: "dx-drawer",
      template: "<ng-content></ng-content>",
      providers: [DxTemplateHost, WatcherHelper, NestedOptionHost]
    }]
  }], function() {
    return [{
      type: ElementRef
    }, {
      type: NgZone
    }, {
      type: DxTemplateHost
    }, {
      type: WatcherHelper
    }, {
      type: NestedOptionHost
    }, {
      type: TransferState
    }, {
      type: void 0,
      decorators: [{
        type: Inject,
        args: [PLATFORM_ID]
      }]
    }];
  }, {
    activeStateEnabled: [{
      type: Input
    }],
    animationDuration: [{
      type: Input
    }],
    animationEnabled: [{
      type: Input
    }],
    closeOnOutsideClick: [{
      type: Input
    }],
    disabled: [{
      type: Input
    }],
    elementAttr: [{
      type: Input
    }],
    height: [{
      type: Input
    }],
    hint: [{
      type: Input
    }],
    hoverStateEnabled: [{
      type: Input
    }],
    maxSize: [{
      type: Input
    }],
    minSize: [{
      type: Input
    }],
    opened: [{
      type: Input
    }],
    openedStateMode: [{
      type: Input
    }],
    position: [{
      type: Input
    }],
    revealMode: [{
      type: Input
    }],
    rtlEnabled: [{
      type: Input
    }],
    shading: [{
      type: Input
    }],
    template: [{
      type: Input
    }],
    visible: [{
      type: Input
    }],
    width: [{
      type: Input
    }],
    onDisposing: [{
      type: Output
    }],
    onInitialized: [{
      type: Output
    }],
    onOptionChanged: [{
      type: Output
    }],
    activeStateEnabledChange: [{
      type: Output
    }],
    animationDurationChange: [{
      type: Output
    }],
    animationEnabledChange: [{
      type: Output
    }],
    closeOnOutsideClickChange: [{
      type: Output
    }],
    disabledChange: [{
      type: Output
    }],
    elementAttrChange: [{
      type: Output
    }],
    heightChange: [{
      type: Output
    }],
    hintChange: [{
      type: Output
    }],
    hoverStateEnabledChange: [{
      type: Output
    }],
    maxSizeChange: [{
      type: Output
    }],
    minSizeChange: [{
      type: Output
    }],
    openedChange: [{
      type: Output
    }],
    openedStateModeChange: [{
      type: Output
    }],
    positionChange: [{
      type: Output
    }],
    revealModeChange: [{
      type: Output
    }],
    rtlEnabledChange: [{
      type: Output
    }],
    shadingChange: [{
      type: Output
    }],
    templateChange: [{
      type: Output
    }],
    visibleChange: [{
      type: Output
    }],
    widthChange: [{
      type: Output
    }]
  });
})();
var DxDrawerModule = class _DxDrawerModule {
  /** @nocollapse */
  static ɵfac = function DxDrawerModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _DxDrawerModule)();
  };
  /** @nocollapse */
  static ɵmod = ɵɵdefineNgModule({
    type: _DxDrawerModule,
    declarations: [DxDrawerComponent],
    imports: [DxIntegrationModule, DxTemplateModule],
    exports: [DxDrawerComponent, DxTemplateModule]
  });
  /** @nocollapse */
  static ɵinj = ɵɵdefineInjector({
    imports: [DxIntegrationModule, DxTemplateModule, DxTemplateModule]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DxDrawerModule, [{
    type: NgModule,
    args: [{
      imports: [DxIntegrationModule, DxTemplateModule],
      declarations: [DxDrawerComponent],
      exports: [DxDrawerComponent, DxTemplateModule]
    }]
  }], null, null);
})();

export {
  drawer_default,
  DxDrawerComponent,
  DxDrawerModule
};
/*! Bundled license information:

devextreme-angular/fesm2022/devextreme-angular-ui-drawer.mjs:
  (*!
   * devextreme-angular
   * Version: 24.1.4
   * Build date: Mon Jul 15 2024
   *
   * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
   *
   * This software may be modified and distributed under the terms
   * of the MIT license. See the LICENSE file in the root of the project for details.
   *
   * https://github.com/DevExpress/devextreme-angular
   *)
*/
//# sourceMappingURL=chunk-JM55LIY5.js.map
