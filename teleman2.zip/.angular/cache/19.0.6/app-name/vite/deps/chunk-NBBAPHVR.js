import {
  Scroller,
  SimulatedStrategy,
  m_scrollable_default,
  m_scrollable_native_default
} from "./chunk-7PCGKOZK.js";
import {
  load_indicator_default
} from "./chunk-DGNKDK3D.js";
import {
  message_default
} from "./chunk-M7JKWUQP.js";
import {
  isFluent,
  isMaterial,
  isMaterialBased
} from "./chunk-6PD6EB72.js";
import {
  move,
  ui_overlay_default
} from "./chunk-QXE45QVL.js";
import {
  component_registrator_default,
  eventData,
  getPublicElement
} from "./chunk-MM4NENTZ.js";
import {
  devices_default
} from "./chunk-76GCZVPW.js";
import {
  getHeight,
  getOuterHeight,
  renderer_default
} from "./chunk-MU4Z4OEA.js";
import {
  Deferred,
  callbacks_default,
  each,
  executeAsync,
  hasWindow,
  noop
} from "./chunk-4BRW6FUL.js";
import {
  extend
} from "./chunk-UTUFIS2B.js";

// node_modules/devextreme/esm/__internal/ui/m_load_panel.js
var LoadPanel = ui_overlay_default.inherit({
  _supportedKeys() {
    return extend(this.callBase(), {
      escape: noop
    });
  },
  _getDefaultOptions() {
    return extend(this.callBase(), {
      message: message_default.format("Loading"),
      width: 222,
      height: 90,
      animation: null,
      showIndicator: true,
      indicatorSrc: "",
      showPane: true,
      delay: 0,
      templatesRenderAsynchronously: false,
      hideTopOverlayHandler: null,
      focusStateEnabled: false,
      propagateOutsideClick: true,
      preventScrollEvents: false
    });
  },
  _defaultOptionsRules() {
    return this.callBase().concat([{
      device: {
        platform: "generic"
      },
      options: {
        shadingColor: "transparent"
      }
    }, {
      device: () => isMaterial(),
      options: {
        message: "",
        width: 60,
        height: 60,
        maxHeight: 60,
        maxWidth: 60
      }
    }, {
      device: () => isFluent(),
      options: {
        width: "auto",
        height: "auto"
      }
    }]);
  },
  _init() {
    this.callBase.apply(this, arguments);
  },
  _render() {
    this.callBase();
    this.$element().addClass("dx-loadpanel");
    this.$wrapper().addClass("dx-loadpanel-wrapper");
    this._updateWrapperAria();
  },
  _updateWrapperAria() {
    this.$wrapper().removeAttr("aria-label").removeAttr("role");
    const showIndicator = this.option("showIndicator");
    if (!showIndicator) {
      const aria = this._getAriaAttributes();
      this.$wrapper().attr(aria);
    }
  },
  _getAriaAttributes() {
    const {
      message
    } = this.option();
    const label = message || message_default.format("Loading");
    const aria = {
      role: "alert",
      "aria-label": label
    };
    return aria;
  },
  _renderContentImpl() {
    this.callBase();
    this.$content().addClass("dx-loadpanel-content");
    this._$loadPanelContentWrapper = renderer_default("<div>").addClass("dx-loadpanel-content-wrapper");
    this._$loadPanelContentWrapper.appendTo(this.$content());
    this._togglePaneVisible();
    this._cleanPreviousContent();
    this._renderLoadIndicator();
    this._renderMessage();
  },
  _show() {
    const delay = this.option("delay");
    if (!delay) {
      return this.callBase();
    }
    const deferred = Deferred();
    const callBase = this.callBase.bind(this);
    this._clearShowTimeout();
    this._showTimeout = setTimeout(() => {
      callBase().done(() => {
        deferred.resolve();
      });
    }, delay);
    return deferred.promise();
  },
  _hide() {
    this._clearShowTimeout();
    return this.callBase();
  },
  _clearShowTimeout() {
    clearTimeout(this._showTimeout);
  },
  _renderMessage() {
    if (!this._$loadPanelContentWrapper) {
      return;
    }
    const message = this.option("message");
    if (!message) {
      return;
    }
    const $message = renderer_default("<div>").addClass("dx-loadpanel-message").text(message);
    this._$loadPanelContentWrapper.append($message);
  },
  _renderLoadIndicator() {
    if (!this._$loadPanelContentWrapper || !this.option("showIndicator")) {
      return;
    }
    if (!this._$indicator) {
      this._$indicator = renderer_default("<div>").addClass("dx-loadpanel-indicator").appendTo(this._$loadPanelContentWrapper);
    }
    this._createComponent(this._$indicator, load_indicator_default, {
      elementAttr: this._getAriaAttributes(),
      indicatorSrc: this.option("indicatorSrc")
    });
  },
  _cleanPreviousContent() {
    this.$content().find(".dx-loadpanel-message").remove();
    this.$content().find(".dx-loadpanel-indicator").remove();
    delete this._$indicator;
  },
  _togglePaneVisible() {
    this.$content().toggleClass("dx-loadpanel-pane-hidden", !this.option("showPane"));
  },
  _optionChanged(args) {
    switch (args.name) {
      case "delay":
        break;
      case "message":
      case "showIndicator":
        this._cleanPreviousContent();
        this._renderLoadIndicator();
        this._renderMessage();
        this._updateWrapperAria();
        break;
      case "showPane":
        this._togglePaneVisible();
        break;
      case "indicatorSrc":
        this._renderLoadIndicator();
        break;
      default:
        this.callBase(args);
    }
  },
  _dispose() {
    this._clearShowTimeout();
    this.callBase();
  }
});
component_registrator_default("dxLoadPanel", LoadPanel);
var m_load_panel_default = LoadPanel;

// node_modules/devextreme/esm/ui/load_panel.js
var load_panel_default = m_load_panel_default;

// node_modules/devextreme/esm/__internal/ui/scroll_view/m_scroll_view.native.pull_down.js
var PullDownNativeScrollViewStrategy = m_scrollable_native_default.inherit({
  _init(scrollView) {
    this.callBase(scrollView);
    this._$topPocket = scrollView._$topPocket;
    this._$pullDown = scrollView._$pullDown;
    this._$refreshingText = scrollView._$refreshingText;
    this._$scrollViewContent = renderer_default(scrollView.content());
    this._$container = renderer_default(scrollView.container());
    this._initCallbacks();
  },
  _initCallbacks() {
    this.pullDownCallbacks = callbacks_default();
    this.releaseCallbacks = callbacks_default();
    this.reachBottomCallbacks = callbacks_default();
  },
  render() {
    this.callBase();
    this._renderPullDown();
    this._releaseState();
  },
  _renderPullDown() {
    const $image = renderer_default("<div>").addClass("dx-scrollview-pull-down-image");
    const $loadContainer = renderer_default("<div>").addClass("dx-scrollview-pull-down-indicator");
    const $loadIndicator = new load_indicator_default(renderer_default("<div>")).$element();
    const $text = this._$pullDownText = renderer_default("<div>").addClass("dx-scrollview-pull-down-text");
    this._$pullingDownText = renderer_default("<div>").text(this.option("pullingDownText")).appendTo($text);
    this._$pulledDownText = renderer_default("<div>").text(this.option("pulledDownText")).appendTo($text);
    this._$refreshingText = renderer_default("<div>").text(this.option("refreshingText")).appendTo($text);
    this._$pullDown.empty().append($image).append($loadContainer.append($loadIndicator)).append($text);
  },
  _releaseState() {
    this._state = 0;
    this._refreshPullDownText();
  },
  _refreshPullDownText() {
    const that = this;
    const pullDownTextItems = [{
      element: this._$pullingDownText,
      visibleState: 0
    }, {
      element: this._$pulledDownText,
      visibleState: 1
    }, {
      element: this._$refreshingText,
      visibleState: 2
    }];
    each(pullDownTextItems, (_, item) => {
      const action = that._state === item.visibleState ? "addClass" : "removeClass";
      item.element[action]("dx-scrollview-pull-down-text-visible");
    });
  },
  update() {
    this.callBase();
    this._setTopPocketOffset();
  },
  _updateDimensions() {
    this.callBase();
    this._topPocketSize = this._$topPocket.get(0).clientHeight;
    const contentEl = this._$scrollViewContent.get(0);
    const containerEl = this._$container.get(0);
    this._bottomBoundary = Math.max(contentEl.clientHeight - containerEl.clientHeight, 0);
  },
  _allowedDirections() {
    const allowedDirections = this.callBase();
    allowedDirections.vertical = allowedDirections.vertical || this._pullDownEnabled;
    return allowedDirections;
  },
  _setTopPocketOffset() {
    this._$topPocket.css({
      top: -this._topPocketSize
    });
  },
  handleEnd() {
    this.callBase();
    this._complete();
  },
  handleStop() {
    this.callBase();
    this._complete();
  },
  _complete() {
    if (1 === this._state) {
      this._setPullDownOffset(this._topPocketSize);
      clearTimeout(this._pullDownRefreshTimeout);
      this._pullDownRefreshTimeout = setTimeout(() => {
        this._pullDownRefreshing();
      }, 400);
    }
  },
  _setPullDownOffset(offset) {
    move(this._$topPocket, {
      top: offset
    });
    move(this._$scrollViewContent, {
      top: offset
    });
  },
  handleScroll(e) {
    this.callBase(e);
    if (2 === this._state) {
      return;
    }
    const currentLocation = this.location().top;
    const scrollDelta = (this._location || 0) - currentLocation;
    this._location = currentLocation;
    if (this._isPullDown()) {
      this._pullDownReady();
    } else if (scrollDelta > 0 && this._isReachBottom()) {
      this._reachBottom();
    } else {
      this._stateReleased();
    }
  },
  _isPullDown() {
    return this._pullDownEnabled && this._location >= this._topPocketSize;
  },
  _isReachBottom() {
    return this._reachBottomEnabled && Math.round(this._bottomBoundary + Math.floor(this._location)) <= 1;
  },
  _reachBottom() {
    if (3 === this._state) {
      return;
    }
    this._state = 3;
    this.reachBottomCallbacks.fire();
  },
  _pullDownReady() {
    if (1 === this._state) {
      return;
    }
    this._state = 1;
    this._$pullDown.addClass("dx-scrollview-pull-down-ready");
    this._refreshPullDownText();
  },
  _stateReleased() {
    if (0 === this._state) {
      return;
    }
    this._$pullDown.removeClass("dx-scrollview-pull-down-loading").removeClass("dx-scrollview-pull-down-ready");
    this._releaseState();
  },
  _pullDownRefreshing() {
    if (2 === this._state) {
      return;
    }
    this._state = 2;
    this._$pullDown.addClass("dx-scrollview-pull-down-loading").removeClass("dx-scrollview-pull-down-ready");
    this._refreshPullDownText();
    this.pullDownCallbacks.fire();
  },
  pullDownEnable(enabled) {
    if (enabled) {
      this._updateDimensions();
      this._setTopPocketOffset();
    }
    this._pullDownEnabled = enabled;
  },
  reachBottomEnable(enabled) {
    this._reachBottomEnabled = enabled;
  },
  pendingRelease() {
    this._state = 1;
  },
  release() {
    const deferred = Deferred();
    this._updateDimensions();
    clearTimeout(this._releaseTimeout);
    if (3 === this._state) {
      this._state = 0;
    }
    this._releaseTimeout = setTimeout(() => {
      this._setPullDownOffset(0);
      this._stateReleased();
      this.releaseCallbacks.fire();
      this._updateAction();
      deferred.resolve();
    }, 400);
    return deferred.promise();
  },
  dispose() {
    clearTimeout(this._pullDownRefreshTimeout);
    clearTimeout(this._releaseTimeout);
    this.callBase();
  }
});
var m_scroll_view_native_pull_down_default = PullDownNativeScrollViewStrategy;

// node_modules/devextreme/esm/__internal/ui/scroll_view/m_scroll_view.native.swipe_down.js
var SwipeDownNativeScrollViewStrategy = m_scrollable_native_default.inherit({
  _init(scrollView) {
    this.callBase(scrollView);
    this._$topPocket = scrollView._$topPocket;
    this._$pullDown = scrollView._$pullDown;
    this._$scrollViewContent = renderer_default(scrollView.content());
    this._$container = renderer_default(scrollView.container());
    this._initCallbacks();
    this._location = 0;
  },
  _initCallbacks() {
    this.pullDownCallbacks = callbacks_default();
    this.releaseCallbacks = callbacks_default();
    this.reachBottomCallbacks = callbacks_default();
  },
  render() {
    this.callBase();
    this._renderPullDown();
    this._releaseState();
  },
  _renderPullDown() {
    const $loadContainer = renderer_default("<div>").addClass("dx-scrollview-pull-down-indicator");
    const $loadIndicator = new load_indicator_default(renderer_default("<div>")).$element();
    this._$icon = renderer_default("<div>").addClass("dx-icon-pulldown");
    this._$pullDown.empty().append(this._$icon).append($loadContainer.append($loadIndicator));
  },
  _releaseState() {
    this._state = 0;
    this._releasePullDown();
    this._updateDimensions();
  },
  _releasePullDown() {
    this._$pullDown.css({
      opacity: 0
    });
  },
  _updateDimensions() {
    this.callBase();
    this._topPocketSize = this._$topPocket.get(0).clientHeight;
    const contentEl = this._$scrollViewContent.get(0);
    const containerEl = this._$container.get(0);
    this._bottomBoundary = Math.max(contentEl.clientHeight - containerEl.clientHeight, 0);
  },
  _allowedDirections() {
    const allowedDirections = this.callBase();
    allowedDirections.vertical = allowedDirections.vertical || this._pullDownEnabled;
    return allowedDirections;
  },
  handleInit(e) {
    this.callBase(e);
    if (0 === this._state && 0 === this._location) {
      this._startClientY = eventData(e.originalEvent).y;
      this._state = 4;
    }
  },
  handleMove(e) {
    this.callBase(e);
    this._deltaY = eventData(e.originalEvent).y - this._startClientY;
    if (4 === this._state) {
      if (this._pullDownEnabled && this._deltaY > 0) {
        this._state = 5;
      } else {
        this._complete();
      }
    }
    if (5 === this._state) {
      e.preventDefault();
      this._movePullDown();
    }
  },
  _movePullDown() {
    const pullDownHeight = this._getPullDownHeight();
    const top = Math.min(3 * pullDownHeight, this._deltaY + this._getPullDownStartPosition());
    const angle = 180 * top / pullDownHeight / 3;
    this._$pullDown.css({
      opacity: 1
    }).toggleClass("dx-scrollview-pull-down-refreshing", top < pullDownHeight);
    move(this._$pullDown, {
      top
    });
    this._$icon.css({
      transform: `rotate(${angle}deg)`
    });
  },
  _isPullDown() {
    return this._pullDownEnabled && 5 === this._state && this._deltaY >= this._getPullDownHeight() - this._getPullDownStartPosition();
  },
  _getPullDownHeight() {
    return Math.round(0.05 * getOuterHeight(this._$element));
  },
  _getPullDownStartPosition() {
    return -Math.round(1.5 * getOuterHeight(this._$pullDown));
  },
  handleEnd() {
    if (this._isPullDown()) {
      this._pullDownRefreshing();
    }
    this._complete();
  },
  handleStop() {
    this._complete();
  },
  _complete() {
    if (4 === this._state || 5 === this._state) {
      this._releaseState();
    }
  },
  handleScroll(e) {
    this.callBase(e);
    if (2 === this._state) {
      return;
    }
    const currentLocation = this.location().top;
    const scrollDelta = this._location - currentLocation;
    this._location = currentLocation;
    if (scrollDelta > 0 && this._isReachBottom()) {
      this._reachBottom();
    } else {
      this._stateReleased();
    }
  },
  _isReachBottom() {
    return this._reachBottomEnabled && Math.round(this._bottomBoundary + Math.floor(this._location)) <= 1;
  },
  _reachBottom() {
    this.reachBottomCallbacks.fire();
  },
  _stateReleased() {
    if (0 === this._state) {
      return;
    }
    this._$pullDown.removeClass("dx-scrollview-pull-down-loading");
    this._releaseState();
  },
  _pullDownRefreshing() {
    this._state = 2;
    this._pullDownRefreshHandler();
  },
  _pullDownRefreshHandler() {
    this._refreshPullDown();
    this.pullDownCallbacks.fire();
  },
  _refreshPullDown() {
    this._$pullDown.addClass("dx-scrollview-pull-down-loading");
    move(this._$pullDown, {
      top: this._getPullDownHeight()
    });
  },
  pullDownEnable(enabled) {
    this._$topPocket.toggle(enabled);
    this._pullDownEnabled = enabled;
  },
  reachBottomEnable(enabled) {
    this._reachBottomEnabled = enabled;
  },
  pendingRelease() {
    this._state = 1;
  },
  release() {
    const deferred = Deferred();
    this._updateDimensions();
    clearTimeout(this._releaseTimeout);
    this._releaseTimeout = setTimeout(() => {
      this._stateReleased();
      this.releaseCallbacks.fire();
      this._updateAction();
      deferred.resolve();
    }, 800);
    return deferred.promise();
  },
  dispose() {
    clearTimeout(this._pullDownRefreshTimeout);
    clearTimeout(this._releaseTimeout);
    this.callBase();
  }
});
var m_scroll_view_native_swipe_down_default = SwipeDownNativeScrollViewStrategy;

// node_modules/devextreme/esm/__internal/ui/scroll_view/m_scroll_view.simulated.js
var math = Math;
var ScrollViewScroller = Scroller.inherit({
  ctor() {
    this._topPocketSize = 0;
    this._bottomPocketSize = 0;
    this.callBase.apply(this, arguments);
    this._initCallbacks();
    this._releaseState();
  },
  _releaseState() {
    this._state = 0;
    this._refreshPullDownText();
  },
  _refreshPullDownText() {
    const that = this;
    const pullDownTextItems = [{
      element: this._$pullingDownText,
      visibleState: 0
    }, {
      element: this._$pulledDownText,
      visibleState: 1
    }, {
      element: this._$refreshingText,
      visibleState: 2
    }];
    each(pullDownTextItems, (_, item) => {
      const action = that._state === item.visibleState ? "addClass" : "removeClass";
      item.element[action]("dx-scrollview-pull-down-text-visible");
    });
  },
  _initCallbacks() {
    this.pullDownCallbacks = callbacks_default();
    this.releaseCallbacks = callbacks_default();
    this.reachBottomCallbacks = callbacks_default();
  },
  _updateBounds() {
    const considerPockets = "horizontal" !== this._direction;
    if (considerPockets) {
      this._topPocketSize = this._$topPocket.get(0).clientHeight;
      this._bottomPocketSize = this._$bottomPocket.get(0).clientHeight;
      const containerEl = this._$container.get(0);
      const contentEl = this._$content.get(0);
      this._bottomBoundary = Math.max(contentEl.clientHeight - this._bottomPocketSize - containerEl.clientHeight, 0);
    }
    this.callBase();
  },
  _updateScrollbar() {
    this._scrollbar.option({
      containerSize: this._containerSize(),
      contentSize: this._contentSize() - this._topPocketSize - this._bottomPocketSize,
      scaleRatio: this._getScaleRatio()
    });
  },
  _moveContent() {
    this.callBase();
    if (this._isPullDown()) {
      this._pullDownReady();
    } else if (this._isReachBottom()) {
      this._reachBottomReady();
    } else if (0 !== this._state) {
      this._stateReleased();
    }
  },
  _moveScrollbar() {
    this._scrollbar.moveTo(this._topPocketSize + this._location);
  },
  _isPullDown() {
    return this._pullDownEnabled && this._location >= 0;
  },
  _isReachBottom() {
    const containerEl = this._$container.get(0);
    return this._reachBottomEnabled && Math.round(this._bottomBoundary - Math.ceil(containerEl.scrollTop)) <= 1;
  },
  _scrollComplete() {
    if (this._inBounds() && 1 === this._state) {
      this._pullDownRefreshing();
    } else if (this._inBounds() && 3 === this._state) {
      this._reachBottomLoading();
    } else {
      this.callBase();
    }
  },
  _reachBottomReady() {
    if (3 === this._state) {
      return;
    }
    this._state = 3;
    this._minOffset = this._getMinOffset();
  },
  _getMaxOffset() {
    return -this._topPocketSize;
  },
  _getMinOffset() {
    return math.min(this.callBase(), -this._topPocketSize);
  },
  _reachBottomLoading() {
    this.reachBottomCallbacks.fire();
  },
  _pullDownReady() {
    if (1 === this._state) {
      return;
    }
    this._state = 1;
    this._maxOffset = 0;
    this._$pullDown.addClass("dx-scrollview-pull-down-ready");
    this._refreshPullDownText();
  },
  _stateReleased() {
    if (0 === this._state) {
      return;
    }
    this._releaseState();
    this._updateBounds();
    this._$pullDown.removeClass("dx-scrollview-pull-down-loading").removeClass("dx-scrollview-pull-down-ready");
    this.releaseCallbacks.fire();
  },
  _pullDownRefreshing() {
    if (2 === this._state) {
      return;
    }
    this._state = 2;
    this._$pullDown.addClass("dx-scrollview-pull-down-loading").removeClass("dx-scrollview-pull-down-ready");
    this._refreshPullDownText();
    this.pullDownCallbacks.fire();
  },
  _releaseHandler() {
    if (0 === this._state) {
      this._moveToBounds();
    }
    this._update();
    if (this._releaseTask) {
      this._releaseTask.abort();
    }
    this._releaseTask = executeAsync(this._release.bind(this));
    return this._releaseTask.promise;
  },
  _release() {
    this._stateReleased();
    this._scrollComplete();
  },
  _reachBottomEnablingHandler(enabled) {
    if (this._reachBottomEnabled === enabled) {
      return;
    }
    this._reachBottomEnabled = enabled;
    this._updateBounds();
  },
  _pullDownEnablingHandler(enabled) {
    if (this._pullDownEnabled === enabled) {
      return;
    }
    this._pullDownEnabled = enabled;
    this._considerTopPocketChange();
    this._updateHandler();
  },
  _considerTopPocketChange() {
    this._location -= getHeight(this._$topPocket) || -this._topPocketSize;
    this._maxOffset = 0;
    this._move();
  },
  _pendingReleaseHandler() {
    this._state = 1;
  },
  dispose() {
    if (this._releaseTask) {
      this._releaseTask.abort();
    }
    this.callBase();
  }
});
var SimulatedScrollViewStrategy = SimulatedStrategy.inherit({
  _init(scrollView) {
    this.callBase(scrollView);
    this._$pullDown = scrollView._$pullDown;
    this._$topPocket = scrollView._$topPocket;
    this._$bottomPocket = scrollView._$bottomPocket;
    this._initCallbacks();
  },
  _initCallbacks() {
    this.pullDownCallbacks = callbacks_default();
    this.releaseCallbacks = callbacks_default();
    this.reachBottomCallbacks = callbacks_default();
  },
  render() {
    this._renderPullDown();
    this.callBase();
  },
  _renderPullDown() {
    const $image = renderer_default("<div>").addClass("dx-scrollview-pull-down-image");
    const $loadContainer = renderer_default("<div>").addClass("dx-scrollview-pull-down-indicator");
    const $loadIndicator = new load_indicator_default(renderer_default("<div>")).$element();
    const $text = this._$pullDownText = renderer_default("<div>").addClass("dx-scrollview-pull-down-text");
    this._$pullingDownText = renderer_default("<div>").text(this.option("pullingDownText")).appendTo($text);
    this._$pulledDownText = renderer_default("<div>").text(this.option("pulledDownText")).appendTo($text);
    this._$refreshingText = renderer_default("<div>").text(this.option("refreshingText")).appendTo($text);
    this._$pullDown.empty().append($image).append($loadContainer.append($loadIndicator)).append($text);
  },
  pullDownEnable(enabled) {
    this._eventHandler("pullDownEnabling", enabled);
  },
  reachBottomEnable(enabled) {
    this._eventHandler("reachBottomEnabling", enabled);
  },
  _createScroller(direction) {
    const that = this;
    const scroller = that._scrollers[direction] = new ScrollViewScroller(that._scrollerOptions(direction));
    scroller.pullDownCallbacks.add(() => {
      that.pullDownCallbacks.fire();
    });
    scroller.releaseCallbacks.add(() => {
      that.releaseCallbacks.fire();
    });
    scroller.reachBottomCallbacks.add(() => {
      that.reachBottomCallbacks.fire();
    });
  },
  _scrollerOptions(direction) {
    return extend(this.callBase(direction), {
      $topPocket: this._$topPocket,
      $bottomPocket: this._$bottomPocket,
      $pullDown: this._$pullDown,
      $pullDownText: this._$pullDownText,
      $pullingDownText: this._$pullingDownText,
      $pulledDownText: this._$pulledDownText,
      $refreshingText: this._$refreshingText
    });
  },
  pendingRelease() {
    this._eventHandler("pendingRelease");
  },
  release() {
    return this._eventHandler("release").done(this._updateAction);
  },
  location() {
    const location = this.callBase();
    location.top += getHeight(this._$topPocket);
    return location;
  },
  dispose() {
    each(this._scrollers, function() {
      this.dispose();
    });
    this.callBase();
  }
});
var m_scroll_view_simulated_default = SimulatedScrollViewStrategy;

// node_modules/devextreme/esm/__internal/ui/scroll_view/m_scroll_view.js
var SCROLLVIEW_LOADPANEL = "dx-scrollview-loadpanel";
var refreshStrategies = {
  pullDown: m_scroll_view_native_pull_down_default,
  swipeDown: m_scroll_view_native_swipe_down_default,
  simulated: m_scroll_view_simulated_default
};
var isServerSide = !hasWindow();
var scrollViewServerConfig = {
  finishLoading: noop,
  release: noop,
  refresh: noop,
  scrollOffset: () => ({
    top: 0,
    left: 0
  }),
  _optionChanged(args) {
    if ("onUpdated" !== args.name) {
      return this.callBase.apply(this, arguments);
    }
  }
};
var ScrollView = m_scrollable_default.inherit(isServerSide ? scrollViewServerConfig : {
  _getDefaultOptions() {
    return extend(this.callBase(), {
      pullingDownText: message_default.format("dxScrollView-pullingDownText"),
      pulledDownText: message_default.format("dxScrollView-pulledDownText"),
      refreshingText: message_default.format("dxScrollView-refreshingText"),
      reachBottomText: message_default.format("dxScrollView-reachBottomText"),
      onPullDown: null,
      onReachBottom: null,
      refreshStrategy: "pullDown"
    });
  },
  _defaultOptionsRules() {
    return this.callBase().concat([{
      device() {
        const realDevice = devices_default.real();
        return "android" === realDevice.platform;
      },
      options: {
        refreshStrategy: "swipeDown"
      }
    }, {
      device: () => isMaterialBased(),
      options: {
        pullingDownText: "",
        pulledDownText: "",
        refreshingText: "",
        reachBottomText: ""
      }
    }]);
  },
  _init() {
    this.callBase();
    this._loadingIndicatorEnabled = true;
  },
  _initScrollableMarkup() {
    this.callBase();
    this.$element().addClass("dx-scrollview");
    this._initContent();
    this._initTopPocket();
    this._initBottomPocket();
    this._initLoadPanel();
  },
  _initContent() {
    const $content = renderer_default("<div>").addClass("dx-scrollview-content");
    this._$content.wrapInner($content);
  },
  _initTopPocket() {
    const $topPocket = this._$topPocket = renderer_default("<div>").addClass("dx-scrollview-top-pocket");
    const $pullDown = this._$pullDown = renderer_default("<div>").addClass("dx-scrollview-pull-down");
    $topPocket.append($pullDown);
    this._$content.prepend($topPocket);
  },
  _initBottomPocket() {
    const $bottomPocket = this._$bottomPocket = renderer_default("<div>").addClass("dx-scrollview-bottom-pocket");
    const $reachBottom = this._$reachBottom = renderer_default("<div>").addClass("dx-scrollview-scrollbottom");
    const $loadContainer = renderer_default("<div>").addClass("dx-scrollview-scrollbottom-indicator");
    const $loadIndicator = new load_indicator_default(renderer_default("<div>")).$element();
    const $text = this._$reachBottomText = renderer_default("<div>").addClass("dx-scrollview-scrollbottom-text");
    this._updateReachBottomText();
    $reachBottom.append($loadContainer.append($loadIndicator)).append($text);
    $bottomPocket.append($reachBottom);
    this._$content.append($bottomPocket);
  },
  _initLoadPanel() {
    const $loadPanelElement = renderer_default("<div>").addClass(SCROLLVIEW_LOADPANEL).appendTo(this.$element());
    const loadPanelOptions = {
      shading: false,
      delay: 400,
      message: this.option("refreshingText"),
      position: {
        of: this.$element()
      }
    };
    this._loadPanel = this._createComponent($loadPanelElement, load_panel_default, loadPanelOptions);
  },
  _updateReachBottomText() {
    this._$reachBottomText.text(this.option("reachBottomText"));
  },
  _createStrategy() {
    const strategyName = this.option("useNative") ? this.option("refreshStrategy") : "simulated";
    const strategyClass = refreshStrategies[strategyName];
    this._strategy = new strategyClass(this);
    this._strategy.pullDownCallbacks.add(this._pullDownHandler.bind(this));
    this._strategy.releaseCallbacks.add(this._releaseHandler.bind(this));
    this._strategy.reachBottomCallbacks.add(this._reachBottomHandler.bind(this));
  },
  _createActions() {
    this.callBase();
    this._pullDownAction = this._createActionByOption("onPullDown");
    this._reachBottomAction = this._createActionByOption("onReachBottom");
    this._tryRefreshPocketState();
  },
  _tryRefreshPocketState() {
    this._pullDownEnable(this.hasActionSubscription("onPullDown"));
    this._reachBottomEnable(this.hasActionSubscription("onReachBottom"));
  },
  on(eventName) {
    const result = this.callBase.apply(this, arguments);
    if ("pullDown" === eventName || "reachBottom" === eventName) {
      this._tryRefreshPocketState();
    }
    return result;
  },
  _pullDownEnable(enabled) {
    if (0 === arguments.length) {
      return this._pullDownEnabled;
    }
    if (this._$pullDown && this._strategy) {
      this._$pullDown.toggle(enabled);
      this._strategy.pullDownEnable(enabled);
      this._pullDownEnabled = enabled;
    }
  },
  _reachBottomEnable(enabled) {
    if (0 === arguments.length) {
      return this._reachBottomEnabled;
    }
    if (this._$reachBottom && this._strategy) {
      this._$reachBottom.toggle(enabled);
      this._strategy.reachBottomEnable(enabled);
      this._reachBottomEnabled = enabled;
    }
  },
  _pullDownHandler() {
    this._loadingIndicator(false);
    this._pullDownLoading();
  },
  _loadingIndicator(value) {
    if (arguments.length < 1) {
      return this._loadingIndicatorEnabled;
    }
    this._loadingIndicatorEnabled = value;
  },
  _pullDownLoading() {
    this.startLoading();
    this._pullDownAction();
  },
  _reachBottomHandler() {
    this._loadingIndicator(false);
    this._reachBottomLoading();
  },
  _reachBottomLoading() {
    this.startLoading();
    this._reachBottomAction();
  },
  _releaseHandler() {
    this.finishLoading();
    this._loadingIndicator(true);
  },
  _optionChanged(args) {
    switch (args.name) {
      case "onPullDown":
      case "onReachBottom":
        this._createActions();
        break;
      case "pullingDownText":
      case "pulledDownText":
      case "refreshingText":
      case "refreshStrategy":
        this._invalidate();
        break;
      case "reachBottomText":
        this._updateReachBottomText();
        break;
      default:
        this.callBase(args);
    }
  },
  content() {
    return getPublicElement(this._$content.children().eq(1));
  },
  release(preventReachBottom) {
    if (void 0 !== preventReachBottom) {
      this.toggleLoading(!preventReachBottom);
    }
    return this._strategy.release();
  },
  toggleLoading(showOrHide) {
    this._reachBottomEnable(showOrHide);
  },
  refresh() {
    if (!this.hasActionSubscription("onPullDown")) {
      return;
    }
    this._strategy.pendingRelease();
    this._pullDownLoading();
  },
  startLoading() {
    if (this._loadingIndicator() && this.$element().is(":visible")) {
      this._loadPanel.show();
    }
    this._lock();
  },
  finishLoading() {
    this._loadPanel.hide();
    this._unlock();
  },
  _dispose() {
    this._strategy.dispose();
    this.callBase();
    if (this._loadPanel) {
      this._loadPanel.$element().remove();
    }
  }
});
component_registrator_default("dxScrollView", ScrollView);
var m_scroll_view_default = ScrollView;

// node_modules/devextreme/esm/ui/scroll_view.js
var scroll_view_default = m_scroll_view_default;

export {
  load_panel_default,
  scroll_view_default
};
//# sourceMappingURL=chunk-NBBAPHVR.js.map
