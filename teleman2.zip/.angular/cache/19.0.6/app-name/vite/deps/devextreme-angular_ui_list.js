import {
  DxListComponent,
  DxListModule
} from "./chunk-F6OJDGKH.js";
import "./chunk-BW76ND5E.js";
import "./chunk-6WF2XDOW.js";
import "./chunk-NBBAPHVR.js";
import "./chunk-5T2OPQKL.js";
import "./chunk-D77BQ7AD.js";
import "./chunk-JXQ6JBGW.js";
import "./chunk-VOSGCXDL.js";
import "./chunk-7RZOWSI4.js";
import "./chunk-7PCGKOZK.js";
import "./chunk-DGNKDK3D.js";
import "./chunk-5HHW3WTB.js";
import "./chunk-AF6BX6BR.js";
import "./chunk-M7JKWUQP.js";
import "./chunk-6PD6EB72.js";
import "./chunk-QXE45QVL.js";
import "./chunk-ZEY4S4J4.js";
import "./chunk-CADIH4ZJ.js";
import "./chunk-MM4NENTZ.js";
import "./chunk-76GCZVPW.js";
import "./chunk-ZXJK4LK6.js";
import "./chunk-IRP4I5CC.js";
import "./chunk-MU4Z4OEA.js";
import "./chunk-RC2BNL3X.js";
import "./chunk-W35F6NCE.js";
import "./chunk-4BRW6FUL.js";
import "./chunk-UTUFIS2B.js";
import "./chunk-ECTAQLWV.js";
import "./chunk-JMD3HP77.js";
import "./chunk-UG3XN6F5.js";
import "./chunk-K3IIKLCY.js";
import "./chunk-WISTXZPE.js";
import "./chunk-N6ESDQJH.js";
export {
  DxListComponent,
  DxListModule
};
//# sourceMappingURL=devextreme-angular_ui_list.js.map
