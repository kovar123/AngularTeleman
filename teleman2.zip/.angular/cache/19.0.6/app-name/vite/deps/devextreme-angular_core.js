import {
  BaseNestedOption,
  CollectionNestedOption,
  CollectionNestedOptionContainerImpl,
  DX_TEMPLATE_WRAPPER_CLASS,
  DxComponent,
  DxComponentExtension,
  DxIntegrationModule,
  DxServerTransferStateModule,
  DxTemplateDirective,
  DxTemplateHost,
  DxTemplateModule,
  EmitterHelper,
  IterableDifferHelper,
  NestedOption,
  NestedOptionHost,
  NgEventsStrategy,
  RenderData,
  WatcherHelper,
  extractTemplate,
  getElement,
  getServerStateKey
} from "./chunk-ZXJK4LK6.js";
import "./chunk-IRP4I5CC.js";
import "./chunk-MU4Z4OEA.js";
import "./chunk-RC2BNL3X.js";
import "./chunk-W35F6NCE.js";
import "./chunk-4BRW6FUL.js";
import "./chunk-UTUFIS2B.js";
import "./chunk-ECTAQLWV.js";
import "./chunk-JMD3HP77.js";
import "./chunk-UG3XN6F5.js";
import "./chunk-K3IIKLCY.js";
import "./chunk-WISTXZPE.js";
import "./chunk-N6ESDQJH.js";
export {
  BaseNestedOption,
  CollectionNestedOption,
  CollectionNestedOptionContainerImpl,
  DX_TEMPLATE_WRAPPER_CLASS,
  DxComponent,
  DxComponentExtension,
  DxIntegrationModule,
  DxServerTransferStateModule,
  DxTemplateDirective,
  DxTemplateHost,
  DxTemplateModule,
  EmitterHelper,
  IterableDifferHelper,
  NestedOption,
  NestedOptionHost,
  NgEventsStrategy,
  RenderData,
  WatcherHelper,
  extractTemplate,
  getElement,
  getServerStateKey
};
//# sourceMappingURL=devextreme-angular_core.js.map
