import { Component } from '@angular/core';

@Component({
  templateUrl: 'home.component.html',
  styleUrls: [ './home.component.scss' ],
  standalone: false
})

export class HomeComponent {
  constructor() {}
}
