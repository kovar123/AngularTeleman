export const navigation = [
  {
    text: 'Home',
    path: '/home',
    icon: 'home',
    items: [
      {
        text: 'Programy',
        path: '/programs',
        icon: 'doc',
      }
    ]
  }
];


     
     

