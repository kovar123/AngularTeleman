export enum Action {
  CHANGE_THEME,
  TRANSCRIPT,FILTER
}
