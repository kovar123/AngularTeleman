export const languages = ['pl-PL','en-US'];
export const defaultLanguage = languages[0];
