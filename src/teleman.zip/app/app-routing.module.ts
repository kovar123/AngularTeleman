import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService } from './shared/services';
import { HomeComponent } from './pages/home/home.component';
import { ProfileComponent } from './pages/profile/profile.component';
import { TvprogramComponent } from './pages/My/tvprogram/tvprogram.component';
import { DxDataGridModule, DxFormModule, DxHtmlEditorModule, DxPopupModule, DxSwitchModule, DxTextBoxModule } from 'devextreme-angular';
import { DxButtonModule, DxProgressBarModule } from 'devextreme-angular';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { OpenAiFormComponent } from './shared/openAI/OpenAiForm/OpenAiForm.component';
import { ProgressSpecialComponent } from './pages/My/progress-special/progress-special.component';
import { MyListaComponent } from './pages/My/my-lista/my-lista.component';
import { AsyncPipe } from '@angular/common';
import { SpeechModule } from './services/speech/speech/speech.module';






const routes: Routes = [
  // {
  //   path: 'profile',
  //   component: ProfileComponent,
  //   canActivate: [AuthGuardService]
  // },
  // {
  //   path: 'home',
  //   component: HomeComponent,
  //   canActivate: [AuthGuardService]
  // },
  // {
  //   path: 'login-form',
  //   component: LoginFormComponent,
  //   canActivate: [AuthGuardService]
  // },
  // {
  //   path: 'reset-password',
  //   component: ResetPasswordFormComponent,
  //   canActivate: [AuthGuardService]
  // },
  // {
  //   path: 'create-account',
  //   component: CreateAccountFormComponent,
  //   canActivate: [AuthGuardService]
  // },
  // {
  //   path: 'change-password/:recoveryCode',
  //   component: ChangePasswordFormComponent,
  //   canActivate: [AuthGuardService]
  // },
  {
    path: 'programs',
    component: TvprogramComponent,
    canActivate: [AuthGuardService],
  },
  // {
  //   path: 'openAiTest',
  //   component: OpenAiFormComponent,
  //   canActivate: [AuthGuardService],
  // },
  //   {
  //   path: 'speechTest',
  //   component: WebSpeechComponent,
  //   canActivate: [AuthGuardService],
  // },

    {
    path: '**',
    redirectTo: 'home'
   }
]


@NgModule({
  imports: [
    RouterModule.forRoot(routes, { useHash: true }),
    DxDataGridModule, DxSelectBoxModule, DxFormModule,AsyncPipe,DxPopupModule,
    DxButtonModule, DxProgressBarModule, DxSwitchModule, DxTextBoxModule, DxHtmlEditorModule,MyListaComponent,SpeechModule
    
  ],
  providers: [AuthGuardService ],
  exports: [RouterModule],
  
  declarations: [
    HomeComponent,
    ProfileComponent,
    TvprogramComponent,
    OpenAiFormComponent,ProgressSpecialComponent
    
  ]
})
export class AppRoutingModule { }
