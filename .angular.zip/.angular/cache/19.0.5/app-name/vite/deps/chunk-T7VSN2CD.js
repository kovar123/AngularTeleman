import {
  list_light_default,
  m_list_edit_decorator_default,
  register
} from "./chunk-TK46GMF2.js";
import {
  ListBase,
  ui_popup_default
} from "./chunk-MJ4KNKI6.js";
import {
  text_box_default,
  ui_search_box_mixin_default
} from "./chunk-HIIKPTPP.js";
import {
  BindableTemplate,
  ui_collection_widget_edit_default
} from "./chunk-VOSGCXDL.js";
import {
  DxiButtonModule,
  DxiItemComponent,
  DxiItemModule,
  DxiMenuItemComponent,
  DxiMenuItemModule,
  DxoCursorOffsetModule,
  DxoItemDraggingModule,
  DxoOptionsModule,
  DxoSearchEditorOptionsModule
} from "./chunk-FQJQBZFP.js";
import {
  button_default
} from "./chunk-SXMMF6QJ.js";
import {
  m_animator_default
} from "./chunk-CYLWHOEL.js";
import {
  DRAG_END_EVENT,
  DRAG_ENTER_EVENT,
  DRAG_EVENT,
  DRAG_LEAVE_EVENT,
  DRAG_START_EVENT,
  OverlayPositionController,
  fx_default,
  getBoundingRect,
  locate,
  move,
  position_default,
  resetPosition,
  ui_overlay_default
} from "./chunk-DOIRN5IG.js";
import {
  fitIntoRange
} from "./chunk-CADIH4ZJ.js";
import {
  message_default
} from "./chunk-M7JKWUQP.js";
import {
  isMaterial,
  isMaterialBased
} from "./chunk-6PD6EB72.js";
import {
  ACTIVE_EVENT_NAME,
  CLICK_EVENT_NAME,
  EmptyTemplate,
  _objectWithoutPropertiesLoose,
  addNamespace,
  component_registrator_default,
  dom_component_default,
  getPublicElement,
  isMouseEvent,
  needSkipEvent,
  pointer_default
} from "./chunk-MM4NENTZ.js";
import {
  ui_errors_default,
  value
} from "./chunk-76GCZVPW.js";
import {
  DxComponent,
  DxIntegrationModule,
  DxTemplateHost,
  DxTemplateModule,
  IterableDifferHelper,
  NestedOptionHost,
  WatcherHelper
} from "./chunk-7YZ53GCH.js";
import {
  dasherize,
  getHeight,
  getOuterHeight,
  getOuterWidth,
  getWidth,
  renderer_default,
  setHeight2 as setHeight,
  setWidth2 as setWidth
} from "./chunk-MU4Z4OEA.js";
import {
  events_engine_default
} from "./chunk-RC2BNL3X.js";
import {
  Deferred,
  _extends,
  dom_adapter_default,
  fromPromise,
  getWindow,
  hasWindow,
  noop,
  pairToObject,
  splitPair,
  when
} from "./chunk-4BRW6FUL.js";
import {
  extend,
  isDefined,
  isFunction,
  isNumeric,
  isObject,
  isString,
  quadToObject
} from "./chunk-UTUFIS2B.js";
import {
  Component,
  ContentChildren,
  ElementRef,
  Inject,
  Input,
  NgModule,
  NgZone,
  Output,
  PLATFORM_ID,
  TransferState,
  setClassMetadata,
  ɵɵInheritDefinitionFeature,
  ɵɵNgOnChangesFeature,
  ɵɵProvidersFeature,
  ɵɵcontentQuery,
  ɵɵdefineComponent,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdirectiveInject,
  ɵɵloadQuery,
  ɵɵqueryRefresh
} from "./chunk-5YDKINUH.js";

// node_modules/devextreme/esm/__internal/ui/list/m_list.edit.decorator_menu_helper.js
var EditDecoratorMenuHelperMixin = {
  _menuEnabled() {
    return !!this._menuItems().length;
  },
  _menuItems() {
    return this._list.option("menuItems");
  },
  _deleteEnabled() {
    return this._list.option("allowItemDeleting");
  },
  _fireMenuAction($itemElement, action) {
    this._list._itemEventHandlerByHandler($itemElement, action, {}, {
      excludeValidators: ["disabled", "readOnly"]
    });
  }
};
var m_list_edit_decorator_menu_helper_default = EditDecoratorMenuHelperMixin;

// node_modules/devextreme/esm/__internal/ui/list/m_list.edit.decorator.context.js
var CONTEXTMENU_CLASS = "dx-list-context-menu";
register("menu", "context", m_list_edit_decorator_default.inherit({
  _init() {
    const $menu = renderer_default("<div>").addClass(CONTEXTMENU_CLASS);
    this._list.$element().append($menu);
    this._menu = this._renderOverlay($menu);
  },
  _renderOverlay($element) {
    return this._list._createComponent($element, ui_overlay_default, {
      shading: false,
      deferRendering: true,
      hideOnParentScroll: true,
      hideOnOutsideClick: (e) => !renderer_default(e.target).closest(`.${CONTEXTMENU_CLASS}`).length,
      animation: {
        show: {
          type: "slide",
          duration: 300,
          from: {
            height: 0,
            opacity: 1
          },
          to: {
            height: function() {
              return getOuterHeight(this._$menuList);
            }.bind(this),
            opacity: 1
          }
        },
        hide: {
          type: "slide",
          duration: 0,
          from: {
            opacity: 1
          },
          to: {
            opacity: 0
          }
        }
      },
      _ignoreFunctionValueDeprecation: true,
      height: function() {
        return this._$menuList ? getOuterHeight(this._$menuList) : 0;
      }.bind(this),
      width: function() {
        return getOuterWidth(this._list.$element());
      }.bind(this),
      onContentReady: this._renderMenuContent.bind(this)
    });
  },
  _renderMenuContent(e) {
    const $overlayContent = e.component.$content();
    const items = this._menuItems().slice();
    if (this._deleteEnabled()) {
      items.push({
        text: message_default.format("dxListEditDecorator-delete"),
        action: this._deleteItem.bind(this)
      });
    }
    this._$menuList = renderer_default("<div>");
    this._list._createComponent(this._$menuList, ListBase, {
      items,
      onItemClick: this._menuItemClickHandler.bind(this),
      height: "auto",
      integrationOptions: {}
    });
    $overlayContent.addClass("dx-list-context-menucontent");
    $overlayContent.append(this._$menuList);
  },
  _menuItemClickHandler(args) {
    this._menu.hide();
    this._fireMenuAction(this._$itemWithMenu, args.itemData.action);
  },
  _deleteItem() {
    this._list.deleteItem(this._$itemWithMenu);
  },
  handleContextMenu($itemElement) {
    this._$itemWithMenu = $itemElement;
    this._menu.option({
      position: {
        my: "top",
        at: "bottom",
        of: $itemElement,
        collision: "flip"
      }
    });
    this._menu.show();
    return true;
  },
  dispose() {
    if (this._menu) {
      this._menu.$element().remove();
    }
    this.callBase.apply(this, arguments);
  }
}).include(m_list_edit_decorator_menu_helper_default));

// node_modules/devextreme/esm/__internal/ui/list/m_list.edit.decorator.switchable.js
var {
  abstract
} = m_list_edit_decorator_default;
var LIST_EDIT_DECORATOR = "dxListEditDecorator";
var POINTER_DOWN_EVENT_NAME = addNamespace(pointer_default.down, LIST_EDIT_DECORATOR);
var ACTIVE_EVENT_NAME2 = addNamespace(ACTIVE_EVENT_NAME, LIST_EDIT_DECORATOR);
var SWITCHABLE_DELETE_READY_CLASS = "dx-list-switchable-delete-ready";
var SWITCHABLE_MENU_SHIELD_POSITIONING_CLASS = "dx-list-switchable-menu-shield-positioning";
var SWITCHABLE_DELETE_TOP_SHIELD_CLASS = "dx-list-switchable-delete-top-shield";
var SWITCHABLE_DELETE_BOTTOM_SHIELD_CLASS = "dx-list-switchable-delete-bottom-shield";
var SWITCHABLE_MENU_ITEM_SHIELD_POSITIONING_CLASS = "dx-list-switchable-menu-item-shield-positioning";
var SWITCHABLE_DELETE_ITEM_CONTENT_SHIELD_CLASS = "dx-list-switchable-delete-item-content-shield";
var SWITCHABLE_DELETE_BUTTON_CONTAINER_CLASS = "dx-list-switchable-delete-button-container";
var SwitchableEditDecorator = m_list_edit_decorator_default.inherit({
  _init() {
    this._$topShield = renderer_default("<div>").addClass(SWITCHABLE_DELETE_TOP_SHIELD_CLASS);
    this._$bottomShield = renderer_default("<div>").addClass(SWITCHABLE_DELETE_BOTTOM_SHIELD_CLASS);
    this._$itemContentShield = renderer_default("<div>").addClass(SWITCHABLE_DELETE_ITEM_CONTENT_SHIELD_CLASS);
    events_engine_default.on(this._$topShield, POINTER_DOWN_EVENT_NAME, this._cancelDeleteReadyItem.bind(this));
    events_engine_default.on(this._$bottomShield, POINTER_DOWN_EVENT_NAME, this._cancelDeleteReadyItem.bind(this));
    this._list.$element().append(this._$topShield.toggle(false)).append(this._$bottomShield.toggle(false));
  },
  handleClick() {
    return this._cancelDeleteReadyItem();
  },
  _cancelDeleteReadyItem() {
    if (!this._$readyToDeleteItem) {
      return false;
    }
    this._cancelDelete(this._$readyToDeleteItem);
    return true;
  },
  _cancelDelete($itemElement) {
    this._toggleDeleteReady($itemElement, false);
  },
  _toggleDeleteReady($itemElement, readyToDelete) {
    if (void 0 === readyToDelete) {
      readyToDelete = !this._isReadyToDelete($itemElement);
    }
    this._toggleShields($itemElement, readyToDelete);
    this._toggleScrolling(readyToDelete);
    this._cacheReadyToDeleteItem($itemElement, readyToDelete);
    this._animateToggleDelete($itemElement, readyToDelete);
  },
  _isReadyToDelete: ($itemElement) => $itemElement.hasClass(SWITCHABLE_DELETE_READY_CLASS),
  _toggleShields($itemElement, enabled) {
    this._list.$element().toggleClass(SWITCHABLE_MENU_SHIELD_POSITIONING_CLASS, enabled);
    this._$topShield.toggle(enabled);
    this._$bottomShield.toggle(enabled);
    if (enabled) {
      this._updateShieldsHeight($itemElement);
    }
    this._toggleContentShield($itemElement, enabled);
  },
  _updateShieldsHeight($itemElement) {
    const $list = this._list.$element();
    const listTopOffset = $list.offset().top;
    const listHeight = getOuterHeight($list);
    const itemTopOffset = $itemElement.offset().top;
    const itemHeight = getOuterHeight($itemElement);
    const dirtyTopShieldHeight = itemTopOffset - listTopOffset;
    const dirtyBottomShieldHeight = listHeight - itemHeight - dirtyTopShieldHeight;
    setHeight(this._$topShield, Math.max(dirtyTopShieldHeight, 0));
    setHeight(this._$bottomShield, Math.max(dirtyBottomShieldHeight, 0));
  },
  _toggleContentShield($itemElement, enabled) {
    if (enabled) {
      $itemElement.find(".dx-list-item-content").first().append(this._$itemContentShield);
    } else {
      this._$itemContentShield.detach();
    }
  },
  _toggleScrolling(readyToDelete) {
    const scrollView = this._list.$element().dxScrollView("instance");
    if (readyToDelete) {
      scrollView.on("start", this._cancelScrolling);
    } else {
      scrollView.off("start", this._cancelScrolling);
    }
  },
  _cancelScrolling(args) {
    args.event.cancel = true;
  },
  _cacheReadyToDeleteItem($itemElement, cache) {
    if (cache) {
      this._$readyToDeleteItem = $itemElement;
    } else {
      delete this._$readyToDeleteItem;
    }
  },
  _animateToggleDelete($itemElement, readyToDelete) {
    if (readyToDelete) {
      this._enablePositioning($itemElement);
      this._prepareDeleteReady($itemElement);
      this._animatePrepareDeleteReady($itemElement);
      events_engine_default.off($itemElement, pointer_default.up);
    } else {
      this._forgetDeleteReady($itemElement);
      this._animateForgetDeleteReady($itemElement).done(this._disablePositioning.bind(this, $itemElement));
    }
  },
  _enablePositioning($itemElement) {
    $itemElement.addClass(SWITCHABLE_MENU_ITEM_SHIELD_POSITIONING_CLASS);
    events_engine_default.on($itemElement, ACTIVE_EVENT_NAME2, noop);
    events_engine_default.one($itemElement, pointer_default.up, this._disablePositioning.bind(this, $itemElement));
  },
  _disablePositioning($itemElement) {
    $itemElement.removeClass(SWITCHABLE_MENU_ITEM_SHIELD_POSITIONING_CLASS);
    events_engine_default.off($itemElement, ACTIVE_EVENT_NAME2);
  },
  _prepareDeleteReady($itemElement) {
    $itemElement.addClass(SWITCHABLE_DELETE_READY_CLASS);
  },
  _forgetDeleteReady($itemElement) {
    $itemElement.removeClass(SWITCHABLE_DELETE_READY_CLASS);
  },
  _animatePrepareDeleteReady: abstract,
  _animateForgetDeleteReady: abstract,
  _getDeleteButtonContainer($itemElement) {
    $itemElement = $itemElement || this._$readyToDeleteItem;
    return $itemElement.children(`.${SWITCHABLE_DELETE_BUTTON_CONTAINER_CLASS}`);
  },
  _deleteItem($itemElement) {
    $itemElement = $itemElement || this._$readyToDeleteItem;
    this._getDeleteButtonContainer($itemElement).detach();
    if ($itemElement.is(".dx-state-disabled, .dx-state-disabled *")) {
      return;
    }
    this._list.deleteItem($itemElement).always(this._cancelDelete.bind(this, $itemElement));
  },
  _isRtlEnabled() {
    return this._list.option("rtlEnabled");
  },
  dispose() {
    if (this._$topShield) {
      this._$topShield.remove();
    }
    if (this._$bottomShield) {
      this._$bottomShield.remove();
    }
    this.callBase.apply(this, arguments);
  }
});
var m_list_edit_decorator_switchable_default = SwitchableEditDecorator;

// node_modules/devextreme/esm/__internal/ui/list/m_list.edit.decorator.switchable.button.js
var SWITCHABLE_DELETE_BUTTON_CONTAINER_CLASS2 = "dx-list-switchable-delete-button-container";
var SWITCHABLE_DELETE_BUTTON_WRAPPER_CLASS = "dx-list-switchable-delete-button-wrapper";
var SWITCHABLE_DELETE_BUTTON_INNER_WRAPPER_CLASS = "dx-list-switchable-delete-button-inner-wrapper";
var SWITCHABLE_DELETE_BUTTON_CLASS = "dx-list-switchable-delete-button";
var SwitchableButtonEditDecorator = m_list_edit_decorator_switchable_default.inherit({
  _init() {
    this.callBase.apply(this, arguments);
    const $buttonContainer = renderer_default("<div>").addClass(SWITCHABLE_DELETE_BUTTON_CONTAINER_CLASS2);
    const $buttonWrapper = renderer_default("<div>").addClass(SWITCHABLE_DELETE_BUTTON_WRAPPER_CLASS);
    const $buttonInnerWrapper = renderer_default("<div>").addClass(SWITCHABLE_DELETE_BUTTON_INNER_WRAPPER_CLASS);
    const $button = renderer_default("<div>").addClass(SWITCHABLE_DELETE_BUTTON_CLASS);
    this._list._createComponent($button, button_default, {
      text: message_default.format("dxListEditDecorator-delete"),
      type: "danger",
      stylingMode: isMaterialBased() ? "text" : "contained",
      onClick: function(e) {
        this._deleteItem();
        e.event.stopPropagation();
      }.bind(this),
      integrationOptions: {},
      elementAttr: {
        role: null,
        "aria-label": null
      },
      tabIndex: -1
    });
    $buttonContainer.append($buttonWrapper);
    $buttonWrapper.append($buttonInnerWrapper);
    $buttonInnerWrapper.append($button);
    this._$buttonContainer = $buttonContainer;
  },
  _enablePositioning($itemElement) {
    this.callBase.apply(this, arguments);
    fx_default.stop(this._$buttonContainer, true);
    this._$buttonContainer.appendTo($itemElement);
  },
  _disablePositioning() {
    this.callBase.apply(this, arguments);
    this._$buttonContainer.detach();
  },
  _animatePrepareDeleteReady() {
    const rtl = this._isRtlEnabled();
    const listWidth = getWidth(this._list.$element());
    const buttonWidth = this._buttonWidth();
    const fromValue = rtl ? listWidth : -buttonWidth;
    const toValue = rtl ? listWidth - buttonWidth : 0;
    return fx_default.animate(this._$buttonContainer, {
      type: "custom",
      duration: 200,
      from: {
        right: fromValue
      },
      to: {
        right: toValue
      }
    });
  },
  _animateForgetDeleteReady() {
    const rtl = this._isRtlEnabled();
    const listWidth = getWidth(this._list.$element());
    const buttonWidth = this._buttonWidth();
    const fromValue = rtl ? listWidth - buttonWidth : 0;
    const toValue = rtl ? listWidth : -buttonWidth;
    return fx_default.animate(this._$buttonContainer, {
      type: "custom",
      duration: 200,
      from: {
        right: fromValue
      },
      to: {
        right: toValue
      }
    });
  },
  _buttonWidth() {
    if (!this._buttonContainerWidth) {
      this._buttonContainerWidth = getOuterWidth(this._$buttonContainer);
    }
    return this._buttonContainerWidth;
  },
  dispose() {
    if (this._$buttonContainer) {
      this._$buttonContainer.remove();
    }
    this.callBase.apply(this, arguments);
  }
});
var TOGGLE_DELETE_SWITCH_CONTAINER_CLASS = "dx-list-toggle-delete-switch-container";
var TOGGLE_DELETE_SWITCH_CLASS = "dx-list-toggle-delete-switch";
register("delete", "toggle", SwitchableButtonEditDecorator.inherit({
  beforeBag(config) {
    const {
      $itemElement
    } = config;
    const {
      $container
    } = config;
    const $toggle = renderer_default("<div>").addClass(TOGGLE_DELETE_SWITCH_CLASS);
    this._list._createComponent($toggle, button_default, {
      icon: "toggle-delete",
      onClick: function(e) {
        fx_default.stop(this._$buttonContainer, false);
        this._toggleDeleteReady($itemElement);
        e.event.stopPropagation();
      }.bind(this),
      integrationOptions: {},
      elementAttr: {
        role: null,
        "aria-label": null
      },
      tabIndex: -1
    });
    $container.addClass(TOGGLE_DELETE_SWITCH_CONTAINER_CLASS);
    $container.append($toggle);
  }
}));
register("delete", "slideButton", SwitchableButtonEditDecorator.inherit({
  _shouldHandleSwipe: true,
  _swipeEndHandler($itemElement, args) {
    if (0 !== args.targetOffset) {
      fx_default.stop(this._$buttonContainer, false);
      this._toggleDeleteReady($itemElement);
    }
    return true;
  }
}));

// node_modules/devextreme/esm/renovation/ui/resizable/utils.js
var borderWidthStyles = {
  left: "borderLeftWidth",
  top: "borderTopWidth",
  right: "borderRightWidth",
  bottom: "borderBottomWidth"
};

// node_modules/devextreme/esm/__internal/ui/popover/m_popover_position_controller.js
var _excluded = ["shading", "target", "$arrow"];
var WEIGHT_OF_SIDES = {
  left: -1,
  top: -1,
  center: 0,
  right: 1,
  bottom: 1
};
var POPOVER_POSITION_ALIASES = {
  top: {
    my: "bottom center",
    at: "top center",
    collision: "fit flip"
  },
  bottom: {
    my: "top center",
    at: "bottom center",
    collision: "fit flip"
  },
  right: {
    my: "left center",
    at: "right center",
    collision: "flip fit"
  },
  left: {
    my: "right center",
    at: "left center",
    collision: "flip fit"
  }
};
var POPOVER_DEFAULT_BOUNDARY_OFFSET = {
  h: 10,
  v: 10
};
var PopoverPositionController = class extends OverlayPositionController {
  constructor(_ref) {
    let {
      shading,
      target,
      $arrow
    } = _ref, args = _objectWithoutPropertiesLoose(_ref, _excluded);
    super(args);
    this._props = _extends({}, this._props, {
      shading,
      target
    });
    this._$arrow = $arrow;
    this._positionSide = void 0;
    this.updatePosition(this._props.position);
  }
  positionWrapper() {
    if (this._props.shading) {
      this._$wrapper.css({
        top: 0,
        left: 0
      });
    }
  }
  updateTarget(target) {
    this._props.target = target;
    this.updatePosition(this._props.position);
  }
  _renderBoundaryOffset() {
  }
  _getContainerPosition() {
    const offset = pairToObject(this._position.offset || "");
    let {
      h: hOffset,
      v: vOffset
    } = offset;
    const isVerticalSide = this._isVerticalSide();
    const isHorizontalSide = this._isHorizontalSide();
    if (isVerticalSide || isHorizontalSide) {
      const isPopoverInside = this._isPopoverInside();
      const sign = (isPopoverInside ? -1 : 1) * WEIGHT_OF_SIDES[this._positionSide];
      const arrowSize = isVerticalSide ? getHeight(this._$arrow) : getWidth(this._$arrow);
      const arrowSizeCorrection = this._getContentBorderWidth(this._positionSide);
      const arrowOffset = sign * (arrowSize - arrowSizeCorrection);
      isVerticalSide ? vOffset += arrowOffset : hOffset += arrowOffset;
    }
    return extend({}, this._position, {
      offset: `${hOffset} ${vOffset}`
    });
  }
  _getContentBorderWidth(side) {
    const borderWidth = this._$content.css(borderWidthStyles[side]);
    return parseInt(borderWidth) || 0;
  }
  _isPopoverInside() {
    const my = position_default.setup.normalizeAlign(this._position.my);
    const at = position_default.setup.normalizeAlign(this._position.at);
    return my.h === at.h && my.v === at.v;
  }
  _isVerticalSide() {
    let side = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this._positionSide;
    return "top" === side || "bottom" === side;
  }
  _isHorizontalSide() {
    let side = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this._positionSide;
    return "left" === side || "right" === side;
  }
  _getDisplaySide(position) {
    const my = position_default.setup.normalizeAlign(position.my);
    const at = position_default.setup.normalizeAlign(position.at);
    const weightSign = WEIGHT_OF_SIDES[my.h] === WEIGHT_OF_SIDES[at.h] && WEIGHT_OF_SIDES[my.v] === WEIGHT_OF_SIDES[at.v] ? -1 : 1;
    const horizontalWeight = Math.abs(WEIGHT_OF_SIDES[my.h] - weightSign * WEIGHT_OF_SIDES[at.h]);
    const verticalWeight = Math.abs(WEIGHT_OF_SIDES[my.v] - weightSign * WEIGHT_OF_SIDES[at.v]);
    return horizontalWeight > verticalWeight ? at.h : at.v;
  }
  _normalizePosition(positionProp) {
    const defaultPositionConfig = {
      of: this._props.target,
      boundaryOffset: POPOVER_DEFAULT_BOUNDARY_OFFSET
    };
    let resultPosition;
    if (isDefined(positionProp)) {
      resultPosition = extend(true, {}, defaultPositionConfig, this._positionToObject(positionProp));
    } else {
      resultPosition = defaultPositionConfig;
    }
    this._positionSide = this._getDisplaySide(resultPosition);
    return resultPosition;
  }
  _positionToObject(positionProp) {
    if (isString(positionProp)) {
      return extend({}, POPOVER_POSITION_ALIASES[positionProp]);
    }
    return positionProp;
  }
};

// node_modules/devextreme/esm/__internal/ui/popover/m_popover.js
var POSITION_FLIP_MAP = {
  left: "right",
  top: "bottom",
  right: "left",
  bottom: "top",
  center: "center"
};
var getEventNameByOption = function(optionValue) {
  return isObject(optionValue) ? optionValue.name : optionValue;
};
var getEventName = function(that, optionName) {
  const optionValue = that.option(optionName);
  return getEventNameByOption(optionValue);
};
var getEventDelay = function(that, optionName) {
  const optionValue = that.option(optionName);
  return isObject(optionValue) && optionValue.delay;
};
var attachEvent = function(that, name) {
  const {
    target,
    shading,
    disabled,
    hideEvent
  } = that.option();
  const isSelector = isString(target);
  const shouldIgnoreHideEvent = shading && "hide" === name;
  const event = shouldIgnoreHideEvent ? null : getEventName(that, `${name}Event`);
  if (shouldIgnoreHideEvent && hideEvent) {
    ui_errors_default.log("W1020");
  }
  if (!event || disabled) {
    return;
  }
  const eventName = addNamespace(event, that.NAME);
  const action = that._createAction(function() {
    const delay = getEventDelay(that, `${name}Event`);
    this._clearEventsTimeouts();
    if (delay) {
      this._timeouts[name] = setTimeout(() => {
        that[name]();
      }, delay);
    } else {
      that[name]();
    }
  }.bind(that), {
    validatingTargetName: "target"
  });
  const handler = function(e) {
    action({
      event: e,
      target: renderer_default(e.currentTarget)
    });
  };
  const EVENT_HANDLER_NAME = `_${name}EventHandler`;
  if (isSelector) {
    that[EVENT_HANDLER_NAME] = handler;
    events_engine_default.on(dom_adapter_default.getDocument(), eventName, target, handler);
  } else {
    const targetElement = getPublicElement(renderer_default(target));
    that[EVENT_HANDLER_NAME] = void 0;
    events_engine_default.on(targetElement, eventName, handler);
  }
};
var detachEvent = function(that, target, name, event) {
  let eventName = event || getEventName(that, `${name}Event`);
  if (!eventName) {
    return;
  }
  eventName = addNamespace(eventName, that.NAME);
  const EVENT_HANDLER_NAME = `_${name}EventHandler`;
  if (that[EVENT_HANDLER_NAME]) {
    events_engine_default.off(dom_adapter_default.getDocument(), eventName, target, that[EVENT_HANDLER_NAME]);
  } else {
    events_engine_default.off(getPublicElement(renderer_default(target)), eventName);
  }
};
var Popover = ui_popup_default.inherit({
  _getDefaultOptions() {
    return extend(this.callBase(), {
      target: void 0,
      shading: false,
      position: extend({}, POPOVER_POSITION_ALIASES.bottom),
      hideOnOutsideClick: true,
      animation: {
        show: {
          type: "fade",
          from: 0,
          to: 1
        },
        hide: {
          type: "fade",
          from: 1,
          to: 0
        }
      },
      showTitle: false,
      width: "auto",
      height: "auto",
      dragEnabled: false,
      resizeEnabled: false,
      fullScreen: false,
      hideOnParentScroll: true,
      arrowPosition: "",
      arrowOffset: 0,
      _fixWrapperPosition: true
    });
  },
  _defaultOptionsRules: () => [{
    device: {
      platform: "ios"
    },
    options: {
      arrowPosition: {
        boundaryOffset: {
          h: 20,
          v: -10
        },
        collision: "fit"
      }
    }
  }, {
    device: () => !hasWindow(),
    options: {
      animation: null
    }
  }, {
    device: () => isMaterialBased(),
    options: {
      useFlatToolbarButtons: true
    }
  }, {
    device: () => isMaterial(),
    options: {
      useDefaultToolbarButtons: true,
      showCloseButton: false
    }
  }],
  _init() {
    var _this$option;
    this.callBase();
    this._renderArrow();
    this._timeouts = {};
    this.$element().addClass("dx-popover");
    this.$wrapper().addClass("dx-popover-wrapper");
    const isInteractive = null === (_this$option = this.option("toolbarItems")) || void 0 === _this$option ? void 0 : _this$option.length;
    this.setAria("role", isInteractive ? "dialog" : "tooltip");
  },
  _render() {
    this.callBase.apply(this, arguments);
    this._detachEvents(this.option("target"));
    this._attachEvents();
  },
  _detachEvents(target) {
    detachEvent(this, target, "show");
    detachEvent(this, target, "hide");
  },
  _attachEvents() {
    attachEvent(this, "show");
    attachEvent(this, "hide");
  },
  _renderArrow() {
    this._$arrow = renderer_default("<div>").addClass("dx-popover-arrow").prependTo(this.$overlayContent());
  },
  _documentDownHandler(e) {
    if (this._isOutsideClick(e)) {
      return this.callBase(e);
    }
    return true;
  },
  _isOutsideClick(e) {
    return !renderer_default(e.target).closest(this.option("target")).length;
  },
  _animate(animation) {
    if (animation && animation.to && "object" === typeof animation.to) {
      extend(animation.to, {
        position: this._getContainerPosition()
      });
    }
    this.callBase.apply(this, arguments);
  },
  _stopAnimation() {
    this.callBase.apply(this, arguments);
  },
  _renderTitle() {
    this.$wrapper().toggleClass("dx-popover-without-title", !this.option("showTitle"));
    this.callBase();
  },
  _renderPosition() {
    let shouldUpdateDimensions = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : true;
    this.callBase();
    this._renderOverlayPosition(shouldUpdateDimensions);
    this._actions.onPositioned();
  },
  _renderOverlayPosition(shouldUpdateDimensions) {
    this._resetOverlayPosition(shouldUpdateDimensions);
    this._updateContentSize(shouldUpdateDimensions);
    const contentPosition = this._getContainerPosition();
    const resultLocation = position_default.setup(this.$overlayContent(), contentPosition);
    const positionSide = this._getSideByLocation(resultLocation);
    this._togglePositionClass(`dx-position-${positionSide}`);
    this._toggleFlippedClass(resultLocation.h.flip, resultLocation.v.flip);
    const isArrowVisible = this._isHorizontalSide() || this._isVerticalSide();
    if (isArrowVisible) {
      this._renderArrowPosition(positionSide);
    }
  },
  _resetOverlayPosition(shouldUpdateDimensions) {
    this._setContentHeight(shouldUpdateDimensions);
    this._togglePositionClass(`dx-position-${this._positionController._positionSide}`);
    move(this.$overlayContent(), {
      left: 0,
      top: 0
    });
    this._$arrow.css({
      top: "auto",
      right: "auto",
      bottom: "auto",
      left: "auto"
    });
  },
  _updateContentSize(shouldUpdateDimensions) {
    if (!this.$content() || !shouldUpdateDimensions) {
      return;
    }
    const containerLocation = position_default.calculate(this.$overlayContent(), this._getContainerPosition());
    if (containerLocation.h.oversize > 0 && this._isHorizontalSide() && !containerLocation.h.fit) {
      const newContainerWidth = getWidth(this.$overlayContent()) - containerLocation.h.oversize;
      setWidth(this.$overlayContent(), newContainerWidth);
    }
    if (containerLocation.v.oversize > 0 && this._isVerticalSide() && !containerLocation.v.fit) {
      const newOverlayContentHeight = getHeight(this.$overlayContent()) - containerLocation.v.oversize;
      const newPopupContentHeight = getHeight(this.$content()) - containerLocation.v.oversize;
      setHeight(this.$overlayContent(), newOverlayContentHeight);
      setHeight(this.$content(), newPopupContentHeight);
    }
  },
  _getContainerPosition() {
    return this._positionController._getContainerPosition();
  },
  _getHideOnParentScrollTarget() {
    return renderer_default(this._positionController._position.of || this.callBase());
  },
  _getSideByLocation(location) {
    const isFlippedByVertical = location.v.flip;
    const isFlippedByHorizontal = location.h.flip;
    return this._isVerticalSide() && isFlippedByVertical || this._isHorizontalSide() && isFlippedByHorizontal || this._isPopoverInside() ? POSITION_FLIP_MAP[this._positionController._positionSide] : this._positionController._positionSide;
  },
  _togglePositionClass(positionClass) {
    this.$wrapper().removeClass("dx-position-left dx-position-right dx-position-top dx-position-bottom").addClass(positionClass);
  },
  _toggleFlippedClass(isFlippedHorizontal, isFlippedVertical) {
    this.$wrapper().toggleClass("dx-popover-flipped-horizontal", isFlippedHorizontal).toggleClass("dx-popover-flipped-vertical", isFlippedVertical);
  },
  _renderArrowPosition(side) {
    const arrowRect = getBoundingRect(this._$arrow.get(0));
    const arrowFlip = -(this._isVerticalSide(side) ? arrowRect.height : arrowRect.width);
    this._$arrow.css(POSITION_FLIP_MAP[side], arrowFlip);
    const axis = this._isVerticalSide(side) ? "left" : "top";
    const sizeProperty = this._isVerticalSide(side) ? "width" : "height";
    const $target = renderer_default(this._positionController._position.of);
    const targetOffset = position_default.offset($target) || {
      top: 0,
      left: 0
    };
    const contentOffset = position_default.offset(this.$overlayContent());
    const arrowSize = arrowRect[sizeProperty];
    const contentLocation = contentOffset[axis];
    const contentSize = getBoundingRect(this.$overlayContent().get(0))[sizeProperty];
    const targetLocation = targetOffset[axis];
    const targetElement = $target.get(0);
    const targetSize = targetElement && !targetElement.preventDefault ? getBoundingRect(targetElement)[sizeProperty] : 0;
    const min = Math.max(contentLocation, targetLocation);
    const max = Math.min(contentLocation + contentSize, targetLocation + targetSize);
    let arrowLocation;
    if ("start" === this.option("arrowPosition")) {
      arrowLocation = min - contentLocation;
    } else if ("end" === this.option("arrowPosition")) {
      arrowLocation = max - contentLocation - arrowSize;
    } else {
      arrowLocation = (min + max) / 2 - contentLocation - arrowSize / 2;
    }
    const borderWidth = this._positionController._getContentBorderWidth(side);
    const finalArrowLocation = fitIntoRange(arrowLocation - borderWidth + this.option("arrowOffset"), borderWidth, contentSize - arrowSize - 2 * borderWidth);
    this._$arrow.css(axis, finalArrowLocation);
  },
  _isPopoverInside() {
    return this._positionController._isPopoverInside();
  },
  _setContentHeight(fullUpdate) {
    if (fullUpdate) {
      this.callBase();
    }
  },
  _getPositionControllerConfig() {
    const {
      shading,
      target
    } = this.option();
    return extend({}, this.callBase(), {
      target,
      shading,
      $arrow: this._$arrow
    });
  },
  _initPositionController() {
    this._positionController = new PopoverPositionController(this._getPositionControllerConfig());
  },
  _renderWrapperDimensions() {
    if (this.option("shading")) {
      this.$wrapper().css({
        width: "100%",
        height: "100%"
      });
    }
  },
  _isVerticalSide(side) {
    return this._positionController._isVerticalSide(side);
  },
  _isHorizontalSide(side) {
    return this._positionController._isHorizontalSide(side);
  },
  _clearEventTimeout(name) {
    clearTimeout(this._timeouts[name]);
  },
  _clearEventsTimeouts() {
    this._clearEventTimeout("show");
    this._clearEventTimeout("hide");
  },
  _clean() {
    this._detachEvents(this.option("target"));
    this.callBase.apply(this, arguments);
  },
  _optionChanged(args) {
    switch (args.name) {
      case "arrowPosition":
      case "arrowOffset":
        this._renderGeometry();
        break;
      case "fullScreen":
        if (args.value) {
          this.option("fullScreen", false);
        }
        break;
      case "target":
        args.previousValue && this._detachEvents(args.previousValue);
        this._positionController.updateTarget(args.value);
        this._invalidate();
        break;
      case "showEvent":
      case "hideEvent": {
        const name = args.name.substring(0, 4);
        const event = getEventNameByOption(args.previousValue);
        this.hide();
        detachEvent(this, this.option("target"), name, event);
        attachEvent(this, name);
        break;
      }
      case "visible":
        this._clearEventTimeout(args.value ? "show" : "hide");
        this.callBase(args);
        break;
      default:
        this.callBase(args);
    }
  },
  show(target) {
    if (target) {
      this.option("target", target);
    }
    return this.callBase();
  }
});
component_registrator_default("dxPopover", Popover);
var m_popover_default = Popover;

// node_modules/devextreme/esm/ui/popover/ui.popover.js
var ui_popover_default = m_popover_default;

// node_modules/devextreme/esm/__internal/ui/m_action_sheet.js
var window = getWindow();
var ActionSheet = ui_collection_widget_edit_default.inherit({
  _getDefaultOptions() {
    return extend(this.callBase(), {
      usePopover: false,
      target: null,
      title: "",
      showTitle: true,
      showCancelButton: true,
      cancelText: message_default.format("Cancel"),
      onCancelClick: null,
      visible: false,
      noDataText: "",
      focusStateEnabled: false,
      selectByClick: false
    });
  },
  _defaultOptionsRules() {
    return this.callBase().concat([{
      device: {
        platform: "ios",
        tablet: true
      },
      options: {
        usePopover: true
      }
    }]);
  },
  _initTemplates() {
    this.callBase();
    this._templateManager.addDefaultTemplates({
      item: new BindableTemplate(($container, data) => {
        const button = new button_default(renderer_default("<div>"), extend({
          onClick: data && data.click,
          stylingMode: data && data.stylingMode || "outlined"
        }, data));
        $container.append(button.$element());
      }, ["disabled", "icon", "text", "type", "onClick", "click", "stylingMode"], this.option("integrationOptions.watchMethod"))
    });
  },
  _itemContainer() {
    return this._$itemContainer;
  },
  _itemClass: () => "dx-actionsheet-item",
  _itemDataKey: () => "dxActionSheetItemData",
  _toggleVisibility: noop,
  _renderDimensions: noop,
  _initMarkup() {
    this.callBase();
    this.$element().addClass("dx-actionsheet");
    this._createItemContainer();
  },
  _render() {
    this._renderPopup();
  },
  _createItemContainer() {
    this._$itemContainer = renderer_default("<div>").addClass("dx-actionsheet-container");
    this._renderDisabled();
  },
  _renderDisabled() {
    this._$itemContainer.toggleClass("dx-state-disabled", this.option("disabled"));
  },
  _renderPopup() {
    this._$popup = renderer_default("<div>").appendTo(this.$element());
    this._isPopoverMode() ? this._createPopover() : this._createPopup();
    this._renderPopupTitle();
    this._mapPopupOption("visible");
  },
  _mapPopupOption(optionName) {
    this._popup && this._popup.option(optionName, this.option(optionName));
  },
  _isPopoverMode() {
    return this.option("usePopover") && this.option("target");
  },
  _renderPopupTitle() {
    this._mapPopupOption("showTitle");
    this._popup && this._popup.$wrapper().toggleClass("dx-actionsheet-without-title", !this.option("showTitle"));
  },
  _clean() {
    if (this._$popup) {
      this._$popup.remove();
    }
    this.callBase();
  },
  _overlayConfig() {
    return {
      onInitialized: function(args) {
        this._popup = args.component;
      }.bind(this),
      disabled: false,
      showTitle: true,
      title: this.option("title"),
      deferRendering: true,
      onContentReady: this._popupContentReadyAction.bind(this),
      onHidden: this.hide.bind(this)
    };
  },
  _createPopover() {
    this._createComponent(this._$popup, ui_popover_default, extend(this._overlayConfig(), {
      width: this.option("width") || 200,
      height: this.option("height") || "auto",
      target: this.option("target")
    }));
    this._popup.$overlayContent().attr("role", "dialog");
    this._popup.$wrapper().addClass("dx-actionsheet-popover-wrapper");
  },
  _createPopup() {
    this._createComponent(this._$popup, ui_popup_default, extend(this._overlayConfig(), {
      dragEnabled: false,
      width: this.option("width") || "100%",
      height: this.option("height") || "auto",
      showCloseButton: false,
      position: {
        my: "bottom",
        at: "bottom",
        of: window
      },
      animation: {
        show: {
          type: "slide",
          duration: 400,
          from: {
            position: {
              my: "top",
              at: "bottom",
              of: window
            }
          },
          to: {
            position: {
              my: "bottom",
              at: "bottom",
              of: window
            }
          }
        },
        hide: {
          type: "slide",
          duration: 400,
          from: {
            position: {
              my: "bottom",
              at: "bottom",
              of: window
            }
          },
          to: {
            position: {
              my: "top",
              at: "bottom",
              of: window
            }
          }
        }
      }
    }));
    this._popup.$wrapper().addClass("dx-actionsheet-popup-wrapper");
  },
  _popupContentReadyAction() {
    this._popup.$content().append(this._$itemContainer);
    this._attachClickEvent();
    this._attachHoldEvent();
    this._prepareContent();
    this._renderContent();
    this._renderCancelButton();
  },
  _renderCancelButton() {
    if (this._isPopoverMode()) {
      return;
    }
    if (this._$cancelButton) {
      this._$cancelButton.remove();
    }
    if (this.option("showCancelButton")) {
      const cancelClickAction = this._createActionByOption("onCancelClick") || noop;
      const that = this;
      this._$cancelButton = renderer_default("<div>").addClass("dx-actionsheet-cancel").appendTo(this._popup && this._popup.$content());
      this._createComponent(this._$cancelButton, button_default, {
        disabled: false,
        stylingMode: "outlined",
        text: this.option("cancelText"),
        onClick(e) {
          const hidingArgs = {
            event: e,
            cancel: false
          };
          cancelClickAction(hidingArgs);
          if (!hidingArgs.cancel) {
            that.hide();
          }
        },
        integrationOptions: {}
      });
    }
  },
  _attachItemClickEvent: noop,
  _itemClickHandler(e) {
    this.callBase(e);
    if (!renderer_default(e.target).is(".dx-state-disabled, .dx-state-disabled *")) {
      this.hide();
    }
  },
  _itemHoldHandler(e) {
    this.callBase(e);
    if (!renderer_default(e.target).is(".dx-state-disabled, .dx-state-disabled *")) {
      this.hide();
    }
  },
  _optionChanged(args) {
    switch (args.name) {
      case "width":
      case "height":
      case "visible":
      case "title":
        this._mapPopupOption(args.name);
        break;
      case "disabled":
        this._renderDisabled();
        break;
      case "showTitle":
        this._renderPopupTitle();
        break;
      case "showCancelButton":
      case "onCancelClick":
      case "cancelText":
        this._renderCancelButton();
        break;
      case "target":
      case "usePopover":
      case "items":
        this._invalidate();
        break;
      default:
        this.callBase(args);
    }
  },
  toggle(showing) {
    const that = this;
    const d = Deferred();
    that._popup.toggle(showing).done(() => {
      that.option("visible", showing);
      d.resolveWith(that);
    });
    return d.promise();
  },
  show() {
    return this.toggle(true);
  },
  hide() {
    return this.toggle(false);
  }
});
component_registrator_default("dxActionSheet", ActionSheet);
var m_action_sheet_default = ActionSheet;

// node_modules/devextreme/esm/ui/action_sheet.js
var action_sheet_default = m_action_sheet_default;

// node_modules/devextreme/esm/__internal/ui/list/m_list.edit.decorator.switchable.slide.js
var LIST_EDIT_DECORATOR2 = "dxListEditDecorator";
var CLICK_EVENT_NAME2 = addNamespace(CLICK_EVENT_NAME, LIST_EDIT_DECORATOR2);
var ACTIVE_EVENT_NAME3 = addNamespace(ACTIVE_EVENT_NAME, LIST_EDIT_DECORATOR2);
var SLIDE_MENU_CLASS = "dx-list-slide-menu";
var SLIDE_MENU_WRAPPER_CLASS = "dx-list-slide-menu-wrapper";
var SLIDE_MENU_CONTENT_CLASS = "dx-list-slide-menu-content";
var SLIDE_MENU_BUTTONS_CONTAINER_CLASS = "dx-list-slide-menu-buttons-container";
var SLIDE_MENU_BUTTONS_CLASS = "dx-list-slide-menu-buttons";
var SLIDE_MENU_BUTTON_CLASS = "dx-list-slide-menu-button";
var SLIDE_MENU_BUTTON_MENU_CLASS = "dx-list-slide-menu-button-menu";
var SLIDE_MENU_BUTTON_DELETE_CLASS = "dx-list-slide-menu-button-delete";
var SLIDE_MENU_ANIMATION_EASING = "cubic-bezier(0.075, 0.82, 0.165, 1)";
register("menu", "slide", m_list_edit_decorator_switchable_default.inherit({
  _shouldHandleSwipe: true,
  _init() {
    this.callBase.apply(this, arguments);
    this._$buttonsContainer = renderer_default("<div>").addClass(SLIDE_MENU_BUTTONS_CONTAINER_CLASS);
    events_engine_default.on(this._$buttonsContainer, ACTIVE_EVENT_NAME3, noop);
    this._$buttons = renderer_default("<div>").addClass(SLIDE_MENU_BUTTONS_CLASS).appendTo(this._$buttonsContainer);
    this._renderMenu();
    this._renderDeleteButton();
  },
  _renderMenu() {
    if (!this._menuEnabled()) {
      return;
    }
    const menuItems = this._menuItems();
    if (1 === menuItems.length) {
      const menuItem = menuItems[0];
      this._renderMenuButton(menuItem.text, (e) => {
        e.stopPropagation();
        this._fireAction(menuItem);
      });
    } else {
      const $menu = renderer_default("<div>").addClass(SLIDE_MENU_CLASS);
      this._menu = this._list._createComponent($menu, action_sheet_default, {
        showTitle: false,
        items: menuItems,
        onItemClick: function(args) {
          this._fireAction(args.itemData);
        }.bind(this),
        integrationOptions: {}
      });
      $menu.appendTo(this._list.$element());
      const $menuButton = this._renderMenuButton(message_default.format("dxListEditDecorator-more"), (e) => {
        e.stopPropagation();
        this._menu.show();
      });
      this._menu.option("target", $menuButton);
    }
  },
  _renderMenuButton(text, action) {
    const $menuButton = renderer_default("<div>").addClass(SLIDE_MENU_BUTTON_CLASS).addClass(SLIDE_MENU_BUTTON_MENU_CLASS).text(text);
    this._$buttons.append($menuButton);
    events_engine_default.on($menuButton, CLICK_EVENT_NAME2, action);
    return $menuButton;
  },
  _renderDeleteButton() {
    if (!this._deleteEnabled()) {
      return;
    }
    const $deleteButton = renderer_default("<div>").addClass(SLIDE_MENU_BUTTON_CLASS).addClass(SLIDE_MENU_BUTTON_DELETE_CLASS).text(isMaterialBased() ? "" : message_default.format("dxListEditDecorator-delete"));
    events_engine_default.on($deleteButton, CLICK_EVENT_NAME2, (e) => {
      e.stopPropagation();
      this._deleteItem();
    });
    this._$buttons.append($deleteButton);
  },
  _fireAction(menuItem) {
    this._fireMenuAction(renderer_default(this._cachedNode), menuItem.action);
    this._cancelDeleteReadyItem();
  },
  modifyElement(config) {
    this.callBase.apply(this, arguments);
    const {
      $itemElement
    } = config;
    $itemElement.addClass(SLIDE_MENU_WRAPPER_CLASS);
    const $slideMenuContent = renderer_default("<div>").addClass(SLIDE_MENU_CONTENT_CLASS);
    $itemElement.wrapInner($slideMenuContent);
  },
  _getDeleteButtonContainer() {
    return this._$buttonsContainer;
  },
  handleClick(_, e) {
    if (renderer_default(e.target).closest(`.${SLIDE_MENU_CONTENT_CLASS}`).length) {
      return this.callBase.apply(this, arguments);
    }
    return false;
  },
  _swipeStartHandler($itemElement) {
    this._enablePositioning($itemElement);
    this._cacheItemData($itemElement);
    this._setPositions(this._getPositions(0));
  },
  _swipeUpdateHandler($itemElement, args) {
    const rtl = this._isRtlEnabled();
    const signCorrection = rtl ? -1 : 1;
    const isItemReadyToDelete = this._isReadyToDelete($itemElement);
    const moveJustStarted = this._getCurrentPositions().content === this._getStartPositions().content;
    if (moveJustStarted && !isItemReadyToDelete && args.offset * signCorrection > 0) {
      args.cancel = true;
      return;
    }
    const offset = this._cachedItemWidth * args.offset;
    const startOffset = isItemReadyToDelete ? -this._cachedButtonWidth * signCorrection : 0;
    const correctedOffset = (offset + startOffset) * signCorrection;
    const percent = correctedOffset < 0 ? Math.abs((offset + startOffset) / this._cachedButtonWidth) : 0;
    this._setPositions(this._getPositions(percent));
    return true;
  },
  _getStartPositions() {
    const rtl = this._isRtlEnabled();
    const signCorrection = rtl ? -1 : 1;
    return {
      content: 0,
      buttonsContainer: rtl ? -this._cachedButtonWidth : this._cachedItemWidth,
      buttons: -this._cachedButtonWidth * signCorrection
    };
  },
  _getPositions(percent) {
    const rtl = this._isRtlEnabled();
    const signCorrection = rtl ? -1 : 1;
    const startPositions = this._getStartPositions();
    return {
      content: startPositions.content - percent * this._cachedButtonWidth * signCorrection,
      buttonsContainer: startPositions.buttonsContainer - Math.min(percent, 1) * this._cachedButtonWidth * signCorrection,
      buttons: startPositions.buttons + Math.min(percent, 1) * this._cachedButtonWidth * signCorrection
    };
  },
  _getCurrentPositions() {
    return {
      content: locate(this._$cachedContent).left,
      buttonsContainer: locate(this._$buttonsContainer).left,
      buttons: locate(this._$buttons).left
    };
  },
  _setPositions(positions) {
    move(this._$cachedContent, {
      left: positions.content
    });
    move(this._$buttonsContainer, {
      left: positions.buttonsContainer
    });
    move(this._$buttons, {
      left: positions.buttons
    });
  },
  _cacheItemData($itemElement) {
    if ($itemElement[0] === this._cachedNode) {
      return;
    }
    this._$cachedContent = $itemElement.find(`.${SLIDE_MENU_CONTENT_CLASS}`);
    this._cachedItemWidth = getOuterWidth($itemElement);
    this._cachedButtonWidth = this._cachedButtonWidth || getOuterWidth(this._$buttons);
    setWidth(this._$buttonsContainer, this._cachedButtonWidth);
    if (this._$cachedContent.length) {
      this._cachedNode = $itemElement[0];
    }
  },
  _minButtonContainerLeftOffset() {
    return this._cachedItemWidth - this._cachedButtonWidth;
  },
  _swipeEndHandler($itemElement, args) {
    this._cacheItemData($itemElement);
    const signCorrection = this._isRtlEnabled() ? 1 : -1;
    const offset = this._cachedItemWidth * args.offset;
    const endedAtReadyToDelete = !this._isReadyToDelete($itemElement) && offset * signCorrection > 0.2 * this._cachedButtonWidth;
    const readyToDelete = args.targetOffset === signCorrection && endedAtReadyToDelete;
    this._toggleDeleteReady($itemElement, readyToDelete);
    return true;
  },
  _enablePositioning($itemElement) {
    fx_default.stop(this._$cachedContent, true);
    this.callBase.apply(this, arguments);
    this._$buttonsContainer.appendTo($itemElement);
  },
  _disablePositioning() {
    this.callBase.apply(this, arguments);
    this._$buttonsContainer.detach();
  },
  _animatePrepareDeleteReady() {
    return this._animateToPositions(this._getPositions(1));
  },
  _animateForgetDeleteReady($itemElement) {
    this._cacheItemData($itemElement);
    return this._animateToPositions(this._getPositions(0));
  },
  _animateToPositions(positions) {
    const that = this;
    const currentPosition = this._getCurrentPositions();
    const durationTimePart = Math.min(Math.abs(currentPosition.content - positions.content) / this._cachedButtonWidth, 1);
    return fx_default.animate(this._$cachedContent, {
      from: currentPosition,
      to: positions,
      easing: SLIDE_MENU_ANIMATION_EASING,
      duration: 400 * durationTimePart,
      strategy: "frame",
      draw(positions2) {
        that._setPositions(positions2);
      }
    });
  },
  dispose() {
    if (this._menu) {
      this._menu.$element().remove();
    }
    if (this._$buttonsContainer) {
      this._$buttonsContainer.remove();
    }
    this.callBase.apply(this, arguments);
  }
}).include(m_list_edit_decorator_menu_helper_default));

// node_modules/devextreme/esm/__internal/ui/list/m_list.edit.decorator.static.js
var STATIC_DELETE_BUTTON_CONTAINER_CLASS = "dx-list-static-delete-button-container";
var STATIC_DELETE_BUTTON_CLASS = "dx-list-static-delete-button";
register("delete", "static", m_list_edit_decorator_default.inherit({
  afterBag(config) {
    const {
      $itemElement
    } = config;
    const {
      $container
    } = config;
    const $button = renderer_default("<div>").addClass(STATIC_DELETE_BUTTON_CLASS);
    this._list._createComponent($button, button_default, {
      icon: "remove",
      onClick: function(args) {
        args.event.stopPropagation();
        this._deleteItem($itemElement);
      }.bind(this),
      integrationOptions: {},
      elementAttr: {
        role: null,
        "aria-label": null
      },
      tabIndex: -1
    });
    $container.addClass(STATIC_DELETE_BUTTON_CONTAINER_CLASS).append($button);
  },
  _deleteItem($itemElement) {
    if ($itemElement.is(".dx-state-disabled, .dx-state-disabled *")) {
      return;
    }
    this._list.deleteItem($itemElement);
  }
}));

// node_modules/devextreme/esm/__internal/ui/list/m_list.edit.decorator.swipe.js
register("delete", "swipe", m_list_edit_decorator_default.inherit({
  _shouldHandleSwipe: true,
  _renderItemPosition($itemElement, offset, animate2) {
    const deferred = Deferred();
    const itemOffset = offset * this._itemElementWidth;
    if (animate2) {
      fx_default.animate($itemElement, {
        to: {
          left: itemOffset
        },
        type: "slide",
        complete() {
          deferred.resolve($itemElement, offset);
        }
      });
    } else {
      move($itemElement, {
        left: itemOffset
      });
      deferred.resolve();
    }
    return deferred.promise();
  },
  _swipeStartHandler($itemElement) {
    this._itemElementWidth = getWidth($itemElement);
    return true;
  },
  _swipeUpdateHandler($itemElement, args) {
    this._renderItemPosition($itemElement, args.offset);
    return true;
  },
  _swipeEndHandler($itemElement, args) {
    const offset = args.targetOffset;
    this._renderItemPosition($itemElement, offset, true).done(($itemElement2, offset2) => {
      if (Math.abs(offset2)) {
        this._list.deleteItem($itemElement2).fail(() => {
          this._renderItemPosition($itemElement2, 0, true);
        });
      }
    });
    return true;
  }
}));

// node_modules/devextreme/esm/__internal/m_draggable.js
var window2 = getWindow();
var DRAGGABLE = "dxDraggable";
var DRAGSTART_EVENT_NAME = addNamespace(DRAG_START_EVENT, DRAGGABLE);
var DRAG_EVENT_NAME = addNamespace(DRAG_EVENT, DRAGGABLE);
var DRAGEND_EVENT_NAME = addNamespace(DRAG_END_EVENT, DRAGGABLE);
var DRAG_ENTER_EVENT_NAME = addNamespace(DRAG_ENTER_EVENT, DRAGGABLE);
var DRAGEND_LEAVE_EVENT_NAME = addNamespace(DRAG_LEAVE_EVENT, DRAGGABLE);
var POINTERDOWN_EVENT_NAME = addNamespace(pointer_default.down, DRAGGABLE);
var KEYDOWN_EVENT_NAME = addNamespace("keydown", DRAGGABLE);
var targetDraggable;
var sourceDraggable;
var getMousePosition = (event) => ({
  x: event.pageX - renderer_default(window2).scrollLeft(),
  y: event.pageY - renderer_default(window2).scrollTop()
});
var ScrollHelper = class {
  constructor(orientation, component) {
    this._$scrollableAtPointer = null;
    this._preventScroll = true;
    this._component = component;
    if ("vertical" === orientation) {
      this._scrollValue = "scrollTop";
      this._overFlowAttr = "overflowY";
      this._sizeAttr = "height";
      this._scrollSizeProp = "scrollHeight";
      this._clientSizeProp = "clientHeight";
      this._limitProps = {
        start: "top",
        end: "bottom"
      };
    } else {
      this._scrollValue = "scrollLeft";
      this._overFlowAttr = "overflowX";
      this._sizeAttr = "width";
      this._scrollSizeProp = "scrollWidth";
      this._clientSizeProp = "clientWidth";
      this._limitProps = {
        start: "left",
        end: "right"
      };
    }
  }
  updateScrollable(elements, mousePosition) {
    let isScrollableFound = false;
    elements.some((element) => {
      const $element = renderer_default(element);
      const isTargetOverOverlayWrapper = $element.hasClass("dx-overlay-wrapper");
      const isTargetOverOverlayContent = $element.hasClass("dx-overlay-content");
      if (isTargetOverOverlayWrapper || isTargetOverOverlayContent) {
        return true;
      }
      isScrollableFound = this._trySetScrollable(element, mousePosition);
      return isScrollableFound;
    });
    if (!isScrollableFound) {
      this._$scrollableAtPointer = null;
      this._scrollSpeed = 0;
    }
  }
  isScrolling() {
    return !!this._scrollSpeed;
  }
  isScrollable($element) {
    return ("auto" === $element.css(this._overFlowAttr) || $element.hasClass("dx-scrollable-container")) && $element.prop(this._scrollSizeProp) > Math.ceil("width" === this._sizeAttr ? getWidth($element) : getHeight($element));
  }
  _trySetScrollable(element, mousePosition) {
    const that = this;
    const $element = renderer_default(element);
    let distanceToBorders;
    const sensitivity = that._component.option("scrollSensitivity");
    let isScrollable = that.isScrollable($element);
    if (isScrollable) {
      distanceToBorders = that._calculateDistanceToBorders($element, mousePosition);
      if (sensitivity > distanceToBorders[that._limitProps.start]) {
        if (!that._preventScroll) {
          that._scrollSpeed = -that._calculateScrollSpeed(distanceToBorders[that._limitProps.start]);
          that._$scrollableAtPointer = $element;
        }
      } else if (sensitivity > distanceToBorders[that._limitProps.end]) {
        if (!that._preventScroll) {
          that._scrollSpeed = that._calculateScrollSpeed(distanceToBorders[that._limitProps.end]);
          that._$scrollableAtPointer = $element;
        }
      } else {
        isScrollable = false;
        that._preventScroll = false;
      }
    }
    return isScrollable;
  }
  _calculateDistanceToBorders($area, mousePosition) {
    const area = $area.get(0);
    let areaBoundingRect;
    if (area) {
      areaBoundingRect = getBoundingRect(area);
      return {
        left: mousePosition.x - areaBoundingRect.left,
        top: mousePosition.y - areaBoundingRect.top,
        right: areaBoundingRect.right - mousePosition.x,
        bottom: areaBoundingRect.bottom - mousePosition.y
      };
    }
    return {};
  }
  _calculateScrollSpeed(distance) {
    const component = this._component;
    const sensitivity = component.option("scrollSensitivity");
    const maxSpeed = component.option("scrollSpeed");
    return Math.ceil(((sensitivity - distance) / sensitivity) ** 2 * maxSpeed);
  }
  scrollByStep() {
    const that = this;
    if (that._$scrollableAtPointer && that._scrollSpeed) {
      if (that._$scrollableAtPointer.hasClass("dx-scrollable-container")) {
        const $scrollable = that._$scrollableAtPointer.closest(".dx-scrollable");
        const scrollableInstance = $scrollable.data("dxScrollable") || $scrollable.data("dxScrollView");
        if (scrollableInstance) {
          const nextScrollPosition = scrollableInstance.scrollOffset()[that._limitProps.start] + that._scrollSpeed;
          scrollableInstance.scrollTo({
            [that._limitProps.start]: nextScrollPosition
          });
        }
      } else {
        const nextScrollPosition = that._$scrollableAtPointer[that._scrollValue]() + that._scrollSpeed;
        that._$scrollableAtPointer[that._scrollValue](nextScrollPosition);
      }
      const dragMoveArgs = that._component._dragMoveArgs;
      if (dragMoveArgs) {
        that._component._dragMoveHandler(dragMoveArgs);
      }
    }
  }
  reset() {
    this._$scrollableAtPointer = null;
    this._scrollSpeed = 0;
    this._preventScroll = true;
  }
  isOutsideScrollable($scrollable, event) {
    if (!$scrollable) {
      return false;
    }
    const scrollableSize = getBoundingRect($scrollable.get(0));
    const start = scrollableSize[this._limitProps.start];
    const size = scrollableSize[this._sizeAttr];
    const mousePosition = getMousePosition(event);
    const location = "width" === this._sizeAttr ? mousePosition.x : mousePosition.y;
    return location < start || location > start + size;
  }
};
var ScrollAnimator = m_animator_default.inherit({
  ctor(strategy) {
    this.callBase();
    this._strategy = strategy;
  },
  _step() {
    const horizontalScrollHelper = this._strategy._horizontalScrollHelper;
    const verticalScrollHelper = this._strategy._verticalScrollHelper;
    horizontalScrollHelper && horizontalScrollHelper.scrollByStep();
    verticalScrollHelper && verticalScrollHelper.scrollByStep();
  }
});
var Draggable = dom_component_default.inherit({
  reset: noop,
  dragMove: noop,
  dragEnter: noop,
  dragLeave: noop,
  dragEnd(sourceEvent) {
    const sourceDraggable2 = this._getSourceDraggable();
    sourceDraggable2._fireRemoveEvent(sourceEvent);
    return Deferred().resolve();
  },
  _fireRemoveEvent: noop,
  _getDefaultOptions() {
    return extend(this.callBase(), {
      onDragStart: null,
      onDragMove: null,
      onDragEnd: null,
      onDragEnter: null,
      onDragLeave: null,
      onDragCancel: null,
      onCancelByEsc: false,
      onDrop: null,
      immediate: true,
      dragDirection: "both",
      boundary: void 0,
      boundOffset: 0,
      allowMoveByClick: false,
      itemData: null,
      container: void 0,
      dragTemplate: void 0,
      contentTemplate: "content",
      handle: "",
      filter: "",
      clone: false,
      autoScroll: true,
      scrollSpeed: 30,
      scrollSensitivity: 60,
      group: void 0,
      data: void 0
    });
  },
  _setOptionsByReference() {
    this.callBase.apply(this, arguments);
    extend(this._optionsByReference, {
      component: true,
      group: true,
      itemData: true,
      data: true
    });
  },
  _init() {
    this.callBase();
    this._attachEventHandlers();
    this._scrollAnimator = new ScrollAnimator(this);
    this._horizontalScrollHelper = new ScrollHelper("horizontal", this);
    this._verticalScrollHelper = new ScrollHelper("vertical", this);
    this._initScrollTop = 0;
    this._initScrollLeft = 0;
  },
  _normalizeCursorOffset(offset) {
    if (isObject(offset)) {
      offset = {
        h: offset.x,
        v: offset.y
      };
    }
    offset = splitPair(offset).map((value2) => parseFloat(value2));
    return {
      left: offset[0],
      top: 1 === offset.length ? offset[0] : offset[1]
    };
  },
  _getNormalizedCursorOffset(offset, options) {
    if (isFunction(offset)) {
      offset = offset.call(this, options);
    }
    return this._normalizeCursorOffset(offset);
  },
  _calculateElementOffset(options) {
    let elementOffset;
    let dragElementOffset;
    const {
      event
    } = options;
    const $element = renderer_default(options.itemElement);
    const $dragElement = renderer_default(options.dragElement);
    const isCloned = this._dragElementIsCloned();
    const cursorOffset = this.option("cursorOffset");
    let normalizedCursorOffset = {
      left: 0,
      top: 0
    };
    const currentLocate = this._initialLocate = locate($dragElement);
    if (isCloned || options.initialOffset || cursorOffset) {
      elementOffset = options.initialOffset || $element.offset();
      if (cursorOffset) {
        normalizedCursorOffset = this._getNormalizedCursorOffset(cursorOffset, options);
        if (isFinite(normalizedCursorOffset.left)) {
          elementOffset.left = event.pageX;
        }
        if (isFinite(normalizedCursorOffset.top)) {
          elementOffset.top = event.pageY;
        }
      }
      dragElementOffset = $dragElement.offset();
      elementOffset.top -= dragElementOffset.top + (normalizedCursorOffset.top || 0) - currentLocate.top;
      elementOffset.left -= dragElementOffset.left + (normalizedCursorOffset.left || 0) - currentLocate.left;
    }
    return elementOffset;
  },
  _initPosition(options) {
    const $dragElement = renderer_default(options.dragElement);
    const elementOffset = this._calculateElementOffset(options);
    if (elementOffset) {
      this._move(elementOffset, $dragElement);
    }
    this._startPosition = locate($dragElement);
  },
  _startAnimator() {
    if (!this._scrollAnimator.inProgress()) {
      this._scrollAnimator.start();
    }
  },
  _stopAnimator() {
    this._scrollAnimator.stop();
  },
  _addWidgetPrefix(className) {
    const componentName = this.NAME;
    return dasherize(componentName) + (className ? `-${className}` : "");
  },
  _getItemsSelector() {
    return this.option("filter") || "";
  },
  _$content() {
    const $element = this.$element();
    const $wrapper = $element.children(".dx-template-wrapper");
    return $wrapper.length ? $wrapper : $element;
  },
  _attachEventHandlers() {
    if (this.option("disabled")) {
      return;
    }
    let $element = this._$content();
    let itemsSelector = this._getItemsSelector();
    const allowMoveByClick = this.option("allowMoveByClick");
    const data = {
      direction: this.option("dragDirection"),
      immediate: this.option("immediate"),
      checkDropTarget: ($target, event) => {
        const targetGroup = this.option("group");
        const sourceGroup = this._getSourceDraggable().option("group");
        const $scrollable = this._getScrollable($target);
        if (this._verticalScrollHelper.isOutsideScrollable($scrollable, event) || this._horizontalScrollHelper.isOutsideScrollable($scrollable, event)) {
          return false;
        }
        return sourceGroup && sourceGroup === targetGroup;
      }
    };
    if (allowMoveByClick) {
      $element = this._getArea();
      events_engine_default.on($element, POINTERDOWN_EVENT_NAME, data, this._pointerDownHandler.bind(this));
    }
    if (">" === itemsSelector[0]) {
      itemsSelector = itemsSelector.slice(1);
    }
    events_engine_default.on($element, DRAGSTART_EVENT_NAME, itemsSelector, data, this._dragStartHandler.bind(this));
    events_engine_default.on($element, DRAG_EVENT_NAME, data, this._dragMoveHandler.bind(this));
    events_engine_default.on($element, DRAGEND_EVENT_NAME, data, this._dragEndHandler.bind(this));
    events_engine_default.on($element, DRAG_ENTER_EVENT_NAME, data, this._dragEnterHandler.bind(this));
    events_engine_default.on($element, DRAGEND_LEAVE_EVENT_NAME, data, this._dragLeaveHandler.bind(this));
    if (this.option("onCancelByEsc")) {
      events_engine_default.on($element, KEYDOWN_EVENT_NAME, this._keydownHandler.bind(this));
    }
  },
  _dragElementIsCloned() {
    return this._$dragElement && this._$dragElement.hasClass(this._addWidgetPrefix("clone"));
  },
  _getDragTemplateArgs($element, $container) {
    return {
      container: getPublicElement($container),
      model: {
        itemData: this.option("itemData"),
        itemElement: getPublicElement($element)
      }
    };
  },
  _createDragElement($element) {
    let result = $element;
    const clone = this.option("clone");
    const $container = this._getContainer();
    let template = this.option("dragTemplate");
    if (template) {
      template = this._getTemplate(template);
      result = renderer_default("<div>").appendTo($container);
      template.render(this._getDragTemplateArgs($element, result));
    } else if (clone) {
      result = renderer_default("<div>").appendTo($container);
      $element.clone().css({
        width: $element.css("width"),
        height: $element.css("height")
      }).appendTo(result);
    }
    return result.toggleClass(this._addWidgetPrefix("clone"), result.get(0) !== $element.get(0)).toggleClass("dx-rtl", this.option("rtlEnabled"));
  },
  _resetDragElement() {
    if (this._dragElementIsCloned()) {
      this._$dragElement.remove();
    } else {
      this._toggleDraggingClass(false);
    }
    this._$dragElement = null;
  },
  _resetSourceElement() {
    this._toggleDragSourceClass(false);
    this._$sourceElement = null;
  },
  _detachEventHandlers() {
    events_engine_default.off(this._$content(), `.${DRAGGABLE}`);
    events_engine_default.off(this._getArea(), `.${DRAGGABLE}`);
  },
  _move(position, $element) {
    move($element || this._$dragElement, position);
  },
  _getDraggableElement(e) {
    const $sourceElement = this._getSourceElement();
    if ($sourceElement) {
      return $sourceElement;
    }
    const allowMoveByClick = this.option("allowMoveByClick");
    if (allowMoveByClick) {
      return this.$element();
    }
    let $target = renderer_default(e && e.target);
    const itemsSelector = this._getItemsSelector();
    if (">" === itemsSelector[0]) {
      const $items = this._$content().find(itemsSelector);
      if (!$items.is($target)) {
        $target = $target.closest($items);
      }
    }
    return $target;
  },
  _getSourceElement() {
    const draggable = this._getSourceDraggable();
    return draggable._$sourceElement;
  },
  _pointerDownHandler(e) {
    if (needSkipEvent(e)) {
      return;
    }
    const position = {};
    const $element = this.$element();
    const dragDirection = this.option("dragDirection");
    if ("horizontal" === dragDirection || "both" === dragDirection) {
      position.left = e.pageX - $element.offset().left + locate($element).left - getWidth($element) / 2;
    }
    if ("vertical" === dragDirection || "both" === dragDirection) {
      position.top = e.pageY - $element.offset().top + locate($element).top - getHeight($element) / 2;
    }
    this._move(position, $element);
    this._getAction("onDragMove")(this._getEventArgs(e));
  },
  _isValidElement(event, $element) {
    const handle = this.option("handle");
    const $target = renderer_default(event.originalEvent && event.originalEvent.target);
    if (handle && !$target.closest(handle).length) {
      return false;
    }
    if (!$element.length) {
      return false;
    }
    return !$element.is(".dx-state-disabled, .dx-state-disabled *");
  },
  _dragStartHandler(e) {
    const $element = this._getDraggableElement(e);
    this.dragInProgress = true;
    if (!this._isValidElement(e, $element)) {
      e.cancel = true;
      return;
    }
    if (this._$sourceElement) {
      return;
    }
    const dragStartArgs = this._getDragStartArgs(e, $element);
    this._getAction("onDragStart")(dragStartArgs);
    if (dragStartArgs.cancel) {
      e.cancel = true;
      return;
    }
    this.option("itemData", dragStartArgs.itemData);
    this._setSourceDraggable();
    this._$sourceElement = $element;
    let initialOffset = $element.offset();
    if (!this._hasClonedDraggable() && this.option("autoScroll")) {
      this._initScrollTop = this._getScrollableScrollTop();
      this._initScrollLeft = this._getScrollableScrollLeft();
      initialOffset = this._getDraggableElementOffset(initialOffset.left, initialOffset.top);
    }
    const $dragElement = this._$dragElement = this._createDragElement($element);
    this._toggleDraggingClass(true);
    this._toggleDragSourceClass(true);
    this._setGestureCoverCursor($dragElement.children());
    const isFixedPosition = "fixed" === $dragElement.css("position");
    this._initPosition(extend({}, dragStartArgs, {
      dragElement: $dragElement.get(0),
      initialOffset: isFixedPosition && initialOffset
    }));
    this._getAction("onDraggableElementShown")(_extends({}, dragStartArgs, {
      dragElement: $dragElement
    }));
    const $area = this._getArea();
    const areaOffset = this._getAreaOffset($area);
    const boundOffset = this._getBoundOffset();
    const areaWidth = getOuterWidth($area);
    const areaHeight = getOuterHeight($area);
    const elementWidth = getWidth($dragElement);
    const elementHeight = getHeight($dragElement);
    const startOffset_left = $dragElement.offset().left - areaOffset.left, startOffset_top = $dragElement.offset().top - areaOffset.top;
    if ($area.length) {
      e.maxLeftOffset = startOffset_left - boundOffset.left;
      e.maxRightOffset = areaWidth - startOffset_left - elementWidth - boundOffset.right;
      e.maxTopOffset = startOffset_top - boundOffset.top;
      e.maxBottomOffset = areaHeight - startOffset_top - elementHeight - boundOffset.bottom;
    }
    if (this.option("autoScroll")) {
      this._startAnimator();
    }
  },
  _getAreaOffset($area) {
    const offset = $area && position_default.offset($area);
    return offset || {
      left: 0,
      top: 0
    };
  },
  _toggleDraggingClass(value2) {
    this._$dragElement && this._$dragElement.toggleClass(this._addWidgetPrefix("dragging"), value2);
  },
  _toggleDragSourceClass(value2, $element) {
    const $sourceElement = $element || this._$sourceElement;
    $sourceElement && $sourceElement.toggleClass(this._addWidgetPrefix("source"), value2);
  },
  _setGestureCoverCursor($element) {
    renderer_default(".dx-gesture-cover").css("cursor", $element.css("cursor"));
  },
  _getBoundOffset() {
    let boundOffset = this.option("boundOffset");
    if (isFunction(boundOffset)) {
      boundOffset = boundOffset.call(this);
    }
    return quadToObject(boundOffset);
  },
  _getArea() {
    let area = this.option("boundary");
    if (isFunction(area)) {
      area = area.call(this);
    }
    return renderer_default(area);
  },
  _getContainer() {
    let container = this.option("container");
    if (void 0 === container) {
      container = value();
    }
    return renderer_default(container);
  },
  _getDraggableElementOffset(initialOffsetX, initialOffsetY) {
    var _this$_startPosition, _this$_startPosition2;
    const initScrollTop = this._initScrollTop;
    const initScrollLeft = this._initScrollLeft;
    const scrollTop = this._getScrollableScrollTop();
    const scrollLeft = this._getScrollableScrollLeft();
    const elementPosition = renderer_default(this.element()).css("position");
    const isFixedPosition = "fixed" === elementPosition;
    const result = {
      left: ((null === (_this$_startPosition = this._startPosition) || void 0 === _this$_startPosition ? void 0 : _this$_startPosition.left) ?? 0) + initialOffsetX,
      top: ((null === (_this$_startPosition2 = this._startPosition) || void 0 === _this$_startPosition2 ? void 0 : _this$_startPosition2.top) ?? 0) + initialOffsetY
    };
    if (isFixedPosition || this._hasClonedDraggable()) {
      return result;
    }
    return {
      left: isNumeric(scrollLeft) ? result.left + scrollLeft - initScrollLeft : result.left,
      top: isNumeric(scrollTop) ? result.top + scrollTop - initScrollTop : result.top
    };
  },
  _hasClonedDraggable() {
    return this.option("clone") || this.option("dragTemplate");
  },
  _dragMoveHandler(e) {
    this._dragMoveArgs = e;
    if (!this._$dragElement) {
      e.cancel = true;
      return;
    }
    const offset = this._getDraggableElementOffset(e.offset.x, e.offset.y);
    this._move(offset);
    this._updateScrollable(e);
    const eventArgs = this._getEventArgs(e);
    this._getAction("onDragMove")(eventArgs);
    if (true === eventArgs.cancel) {
      return;
    }
    const targetDraggable2 = this._getTargetDraggable();
    targetDraggable2.dragMove(e, scrollBy);
  },
  _updateScrollable(e) {
    const that = this;
    if (that.option("autoScroll")) {
      const mousePosition = getMousePosition(e);
      const allObjects = dom_adapter_default.elementsFromPoint(mousePosition.x, mousePosition.y, this.$element().get(0));
      that._verticalScrollHelper.updateScrollable(allObjects, mousePosition);
      that._horizontalScrollHelper.updateScrollable(allObjects, mousePosition);
    }
  },
  _getScrollable($element) {
    let $scrollable;
    $element.parents().toArray().some((parent) => {
      const $parent = renderer_default(parent);
      if (this._horizontalScrollHelper.isScrollable($parent) || this._verticalScrollHelper.isScrollable($parent)) {
        $scrollable = $parent;
        return true;
      }
      return false;
    });
    return $scrollable;
  },
  _getScrollableScrollTop() {
    var _this$_getScrollable;
    return (null === (_this$_getScrollable = this._getScrollable(renderer_default(this.element()))) || void 0 === _this$_getScrollable ? void 0 : _this$_getScrollable.scrollTop()) ?? 0;
  },
  _getScrollableScrollLeft() {
    var _this$_getScrollable2;
    return (null === (_this$_getScrollable2 = this._getScrollable(renderer_default(this.element()))) || void 0 === _this$_getScrollable2 ? void 0 : _this$_getScrollable2.scrollLeft()) ?? 0;
  },
  _defaultActionArgs() {
    const args = this.callBase.apply(this, arguments);
    const component = this.option("component");
    if (component) {
      args.component = component;
      args.element = component.element();
    }
    return args;
  },
  _getEventArgs(e) {
    const sourceDraggable2 = this._getSourceDraggable();
    const targetDraggable2 = this._getTargetDraggable();
    return {
      event: e,
      itemData: sourceDraggable2.option("itemData"),
      itemElement: getPublicElement(sourceDraggable2._$sourceElement),
      fromComponent: sourceDraggable2.option("component") || sourceDraggable2,
      toComponent: targetDraggable2.option("component") || targetDraggable2,
      fromData: sourceDraggable2.option("data"),
      toData: targetDraggable2.option("data")
    };
  },
  _getDragStartArgs(e, $itemElement) {
    const args = this._getEventArgs(e);
    return {
      event: args.event,
      itemData: args.itemData,
      itemElement: $itemElement,
      fromData: args.fromData
    };
  },
  _revertItemToInitialPosition() {
    !this._dragElementIsCloned() && this._move(this._initialLocate, this._$sourceElement);
  },
  _dragEndHandler(e) {
    const d = Deferred();
    const dragEndEventArgs = this._getEventArgs(e);
    const dropEventArgs = this._getEventArgs(e);
    const targetDraggable2 = this._getTargetDraggable();
    let needRevertPosition = true;
    this.dragInProgress = false;
    try {
      this._getAction("onDragEnd")(dragEndEventArgs);
    } finally {
      when(fromPromise(dragEndEventArgs.cancel)).done((cancel) => {
        if (!cancel) {
          if (targetDraggable2 !== this) {
            targetDraggable2._getAction("onDrop")(dropEventArgs);
          }
          if (!dropEventArgs.cancel) {
            needRevertPosition = false;
            when(fromPromise(targetDraggable2.dragEnd(dragEndEventArgs))).always(d.resolve);
            return;
          }
        }
        d.resolve();
      }).fail(d.resolve);
      d.done(() => {
        if (needRevertPosition) {
          this._revertItemToInitialPosition();
        }
        this._resetDragOptions(targetDraggable2);
      });
    }
  },
  _isTargetOverAnotherDraggable(e) {
    const sourceDraggable2 = this._getSourceDraggable();
    if (this === sourceDraggable2) {
      return false;
    }
    const $dragElement = sourceDraggable2._$dragElement;
    const $sourceDraggableElement = sourceDraggable2.$element();
    const $targetDraggableElement = this.$element();
    const mousePosition = getMousePosition(e);
    const elements = dom_adapter_default.elementsFromPoint(mousePosition.x, mousePosition.y, this.element());
    const firstWidgetElement = elements.filter((element) => {
      const $element = renderer_default(element);
      if ($element.hasClass(this._addWidgetPrefix())) {
        return !$element.closest($dragElement).length;
      }
      return false;
    })[0];
    const $sourceElement = this._getSourceElement();
    const isTargetOverItself = firstWidgetElement === $sourceDraggableElement.get(0);
    const isTargetOverNestedDraggable = renderer_default(firstWidgetElement).closest($sourceElement).length;
    return !firstWidgetElement || firstWidgetElement === $targetDraggableElement.get(0) && !isTargetOverItself && !isTargetOverNestedDraggable;
  },
  _dragEnterHandler(e) {
    this._fireDragEnterEvent(e);
    if (this._isTargetOverAnotherDraggable(e)) {
      this._setTargetDraggable();
    }
    const sourceDraggable2 = this._getSourceDraggable();
    sourceDraggable2.dragEnter(e);
  },
  _dragLeaveHandler(e) {
    this._fireDragLeaveEvent(e);
    this._resetTargetDraggable();
    if (this !== this._getSourceDraggable()) {
      this.reset();
    }
    const sourceDraggable2 = this._getSourceDraggable();
    sourceDraggable2.dragLeave(e);
  },
  _keydownHandler(e) {
    if (this.dragInProgress && "Escape" === e.key) {
      this._keydownEscapeHandler(e);
    }
  },
  _keydownEscapeHandler(e) {
    var _sourceDraggable;
    const $sourceElement = this._getSourceElement();
    if (!$sourceElement) {
      return;
    }
    const dragCancelEventArgs = this._getEventArgs(e);
    this._getAction("onDragCancel")(dragCancelEventArgs);
    if (dragCancelEventArgs.cancel) {
      return;
    }
    this.dragInProgress = false;
    null === (_sourceDraggable = sourceDraggable) || void 0 === _sourceDraggable || _sourceDraggable._toggleDraggingClass(false);
    this._detachEventHandlers();
    this._revertItemToInitialPosition();
    const targetDraggable2 = this._getTargetDraggable();
    this._resetDragOptions(targetDraggable2);
    this._attachEventHandlers();
  },
  _getAction(name) {
    return this[`_${name}Action`] || this._createActionByOption(name);
  },
  _getAnonymousTemplateName: () => "content",
  _initTemplates() {
    if (!this.option("contentTemplate")) {
      return;
    }
    this._templateManager.addDefaultTemplates({
      content: new EmptyTemplate()
    });
    this.callBase.apply(this, arguments);
  },
  _render() {
    this.callBase();
    this.$element().addClass(this._addWidgetPrefix());
    const transclude = this._templateManager.anonymousTemplateName === this.option("contentTemplate");
    const template = this._getTemplateByOption("contentTemplate");
    if (template) {
      renderer_default(template.render({
        container: this.element(),
        transclude
      }));
    }
  },
  _optionChanged(args) {
    const {
      name
    } = args;
    switch (name) {
      case "onDragStart":
      case "onDragMove":
      case "onDragEnd":
      case "onDrop":
      case "onDragEnter":
      case "onDragLeave":
      case "onDragCancel":
      case "onDraggableElementShown":
        this[`_${name}Action`] = this._createActionByOption(name);
        break;
      case "dragTemplate":
      case "contentTemplate":
      case "container":
      case "clone":
      case "scrollSensitivity":
      case "scrollSpeed":
      case "boundOffset":
      case "handle":
      case "group":
      case "data":
      case "itemData":
        break;
      case "allowMoveByClick":
      case "dragDirection":
      case "disabled":
      case "boundary":
      case "filter":
      case "immediate":
        this._resetDragElement();
        this._detachEventHandlers();
        this._attachEventHandlers();
        break;
      case "onCancelByEsc":
        this._keydownHandler();
        break;
      case "autoScroll":
        this._verticalScrollHelper.reset();
        this._horizontalScrollHelper.reset();
        break;
      default:
        this.callBase(args);
    }
  },
  _getTargetDraggable() {
    return targetDraggable || this;
  },
  _getSourceDraggable() {
    return sourceDraggable || this;
  },
  _setTargetDraggable() {
    const currentGroup = this.option("group");
    const sourceDraggable2 = this._getSourceDraggable();
    if (currentGroup && currentGroup === sourceDraggable2.option("group")) {
      targetDraggable = this;
    }
  },
  _setSourceDraggable() {
    sourceDraggable = this;
  },
  _resetSourceDraggable() {
    sourceDraggable = null;
  },
  _resetTargetDraggable() {
    targetDraggable = null;
  },
  _resetDragOptions(targetDraggable2) {
    this.reset();
    targetDraggable2.reset();
    this._stopAnimator();
    this._horizontalScrollHelper.reset();
    this._verticalScrollHelper.reset();
    this._resetDragElement();
    this._resetSourceElement();
    this._resetTargetDraggable();
    this._resetSourceDraggable();
  },
  _dispose() {
    this.callBase();
    this._detachEventHandlers();
    this._resetDragElement();
    this._resetTargetDraggable();
    this._resetSourceDraggable();
    this._$sourceElement = null;
    this._stopAnimator();
  },
  _fireDragEnterEvent(sourceEvent) {
    const args = this._getEventArgs(sourceEvent);
    this._getAction("onDragEnter")(args);
  },
  _fireDragLeaveEvent(sourceEvent) {
    const args = this._getEventArgs(sourceEvent);
    this._getAction("onDragLeave")(args);
  }
});
component_registrator_default(DRAGGABLE, Draggable);
var m_draggable_default = Draggable;

// node_modules/devextreme/esm/__internal/m_sortable.js
var window3 = getWindow();
var SORTABLE = "dxSortable";
var isElementVisible = (itemElement) => renderer_default(itemElement).is(":visible");
var animate = (element, config) => {
  var _config$to, _config$to2;
  if (!element) {
    return;
  }
  const left = (null === (_config$to = config.to) || void 0 === _config$to ? void 0 : _config$to.left) || 0;
  const top = (null === (_config$to2 = config.to) || void 0 === _config$to2 ? void 0 : _config$to2.top) || 0;
  element.style.transform = `translate(${left}px,${top}px)`;
  element.style.transition = fx_default.off ? "" : `transform ${config.duration}ms ${config.easing}`;
};
var stopAnimation = (element) => {
  if (!element) {
    return;
  }
  element.style.transform = "";
  element.style.transition = "";
};
function getScrollableBoundary($scrollable) {
  const offset = $scrollable.offset();
  const {
    style
  } = $scrollable[0];
  const paddingLeft = parseFloat(style.paddingLeft) || 0;
  const paddingRight = parseFloat(style.paddingRight) || 0;
  const paddingTop = parseFloat(style.paddingTop) || 0;
  const width = $scrollable[0].clientWidth - (paddingLeft + paddingRight);
  const height = getHeight($scrollable);
  const left = offset.left + paddingLeft;
  const top = offset.top + paddingTop;
  return {
    left,
    right: left + width,
    top,
    bottom: top + height
  };
}
var Sortable = m_draggable_default.inherit({
  _init() {
    this.callBase();
    this._sourceScrollHandler = this._handleSourceScroll.bind(this);
    this._sourceScrollableInfo = null;
  },
  _getDefaultOptions() {
    return extend(this.callBase(), {
      clone: true,
      filter: "> *",
      itemOrientation: "vertical",
      dropFeedbackMode: "push",
      allowDropInsideItem: false,
      allowReordering: true,
      moveItemOnDrop: false,
      onDragChange: null,
      onAdd: null,
      onRemove: null,
      onReorder: null,
      onPlaceholderPrepared: null,
      animation: {
        type: "slide",
        duration: 300,
        easing: "ease"
      },
      fromIndex: null,
      toIndex: null,
      dropInsideItem: false,
      itemPoints: null,
      fromIndexOffset: 0,
      offset: 0,
      autoUpdate: false,
      draggableElementSize: 0
    });
  },
  reset() {
    this.option({
      dropInsideItem: false,
      toIndex: null,
      fromIndex: null,
      itemPoints: null,
      fromIndexOffset: 0,
      draggableElementSize: 0
    });
    if (this._$placeholderElement) {
      this._$placeholderElement.remove();
    }
    this._$placeholderElement = null;
    if (!this._isIndicateMode() && this._$modifiedItem) {
      this._$modifiedItem.css("marginBottom", this._modifiedItemMargin);
      this._$modifiedItem = null;
    }
  },
  _getPrevVisibleItem: (items, index) => items.slice(0, index).reverse().filter(isElementVisible)[0],
  _dragStartHandler(e) {
    this.callBase.apply(this, arguments);
    if (true === e.cancel) {
      return;
    }
    const $sourceElement = this._getSourceElement();
    this._updateItemPoints();
    this._subscribeToSourceScroll(e);
    this.option("fromIndex", this._getElementIndex($sourceElement));
    this.option("fromIndexOffset", this.option("offset"));
  },
  _subscribeToSourceScroll(e) {
    const $scrollable = this._getScrollable(renderer_default(e.target));
    if ($scrollable) {
      this._sourceScrollableInfo = {
        element: $scrollable,
        scrollLeft: $scrollable.scrollLeft(),
        scrollTop: $scrollable.scrollTop()
      };
      events_engine_default.off($scrollable, "scroll", this._sourceScrollHandler);
      events_engine_default.on($scrollable, "scroll", this._sourceScrollHandler);
    }
  },
  _unsubscribeFromSourceScroll() {
    if (this._sourceScrollableInfo) {
      events_engine_default.off(this._sourceScrollableInfo.element, "scroll", this._sourceScrollHandler);
      this._sourceScrollableInfo = null;
    }
  },
  _handleSourceScroll(e) {
    const sourceScrollableInfo = this._sourceScrollableInfo;
    if (sourceScrollableInfo) {
      ["scrollLeft", "scrollTop"].forEach((scrollProp) => {
        if (e.target[scrollProp] !== sourceScrollableInfo[scrollProp]) {
          const scrollBy2 = e.target[scrollProp] - sourceScrollableInfo[scrollProp];
          this._correctItemPoints(scrollBy2);
          this._movePlaceholder();
          sourceScrollableInfo[scrollProp] = e.target[scrollProp];
        }
      });
    }
  },
  _dragEnterHandler(e) {
    this.callBase.apply(this, arguments);
    if (this === this._getSourceDraggable()) {
      return;
    }
    this._subscribeToSourceScroll(e);
    this._updateItemPoints();
    this.option("fromIndex", -1);
    if (!this._isIndicateMode()) {
      const itemPoints = this.option("itemPoints");
      const lastItemPoint = itemPoints[itemPoints.length - 1];
      if (lastItemPoint) {
        const $element = this.$element();
        const $sourceElement = this._getSourceElement();
        const isVertical = this._isVerticalOrientation();
        const sourceElementSize = isVertical ? getOuterHeight($sourceElement, true) : getOuterWidth($sourceElement, true);
        const scrollSize = $element.get(0)[isVertical ? "scrollHeight" : "scrollWidth"];
        const scrollPosition = $element.get(0)[isVertical ? "scrollTop" : "scrollLeft"];
        const positionProp = isVertical ? "top" : "left";
        const lastPointPosition = lastItemPoint[positionProp];
        const elementPosition = $element.offset()[positionProp];
        const freeSize = elementPosition + scrollSize - scrollPosition - lastPointPosition;
        if (freeSize < sourceElementSize) {
          if (isVertical) {
            const items = this._getItems();
            const $lastItem = renderer_default(this._getPrevVisibleItem(items));
            this._$modifiedItem = $lastItem;
            this._modifiedItemMargin = $lastItem.get(0).style.marginBottom;
            $lastItem.css("marginBottom", sourceElementSize - freeSize);
            const $sortable = $lastItem.closest(".dx-sortable");
            const sortable = $sortable.data("dxScrollable") || $sortable.data("dxScrollView");
            sortable && sortable.update();
          }
        }
      }
    }
  },
  _dragLeaveHandler() {
    this.callBase.apply(this, arguments);
    if (this !== this._getSourceDraggable()) {
      this._unsubscribeFromSourceScroll();
    }
  },
  dragEnter() {
    if (this !== this._getTargetDraggable()) {
      this.option("toIndex", -1);
    }
  },
  dragLeave() {
    if (this !== this._getTargetDraggable()) {
      this.option("toIndex", this.option("fromIndex"));
    }
  },
  _allowDrop(event) {
    const targetDraggable2 = this._getTargetDraggable();
    const $targetDraggable = targetDraggable2.$element();
    const $scrollable = this._getScrollable($targetDraggable);
    if ($scrollable) {
      const {
        left,
        right,
        top,
        bottom
      } = getScrollableBoundary($scrollable);
      const toIndex = this.option("toIndex");
      const itemPoints = this.option("itemPoints");
      const itemPoint = null === itemPoints || void 0 === itemPoints ? void 0 : itemPoints.filter((item) => item.index === toIndex)[0];
      if (itemPoint && void 0 !== itemPoint.top) {
        const isVertical = this._isVerticalOrientation();
        if (isVertical) {
          return top <= Math.ceil(itemPoint.top) && Math.floor(itemPoint.top) <= bottom;
        }
        return left <= Math.ceil(itemPoint.left) && Math.floor(itemPoint.left) <= right;
      }
    }
    return true;
  },
  dragEnd(sourceEvent) {
    this._unsubscribeFromSourceScroll();
    const $sourceElement = this._getSourceElement();
    const sourceDraggable2 = this._getSourceDraggable();
    const isSourceDraggable = sourceDraggable2.NAME !== this.NAME;
    const toIndex = this.option("toIndex");
    const {
      event
    } = sourceEvent;
    const allowDrop = this._allowDrop(event);
    if (null !== toIndex && toIndex >= 0 && allowDrop) {
      let cancelAdd;
      let cancelRemove;
      if (sourceDraggable2 !== this) {
        cancelAdd = this._fireAddEvent(event);
        if (!cancelAdd) {
          cancelRemove = this._fireRemoveEvent(event);
        }
      }
      if (isSourceDraggable) {
        resetPosition($sourceElement);
      }
      if (this.option("moveItemOnDrop")) {
        !cancelAdd && this._moveItem($sourceElement, toIndex, cancelRemove);
      }
      if (sourceDraggable2 === this) {
        return this._fireReorderEvent(event);
      }
    }
    return Deferred().resolve();
  },
  dragMove(e) {
    const itemPoints = this.option("itemPoints");
    if (!itemPoints) {
      return;
    }
    const isVertical = this._isVerticalOrientation();
    const axisName = isVertical ? "top" : "left";
    const cursorPosition = isVertical ? e.pageY : e.pageX;
    const rtlEnabled = this.option("rtlEnabled");
    let itemPoint;
    for (let i = itemPoints.length - 1; i >= 0; i--) {
      const centerPosition = itemPoints[i + 1] && (itemPoints[i][axisName] + itemPoints[i + 1][axisName]) / 2;
      if ((!isVertical && rtlEnabled ? cursorPosition > centerPosition : centerPosition > cursorPosition) || void 0 === centerPosition) {
        itemPoint = itemPoints[i];
      } else {
        break;
      }
    }
    if (itemPoint) {
      this._updatePlaceholderPosition(e, itemPoint);
      if (this._verticalScrollHelper.isScrolling() && this._isIndicateMode()) {
        this._movePlaceholder();
      }
    }
  },
  _isIndicateMode() {
    return "indicate" === this.option("dropFeedbackMode") || this.option("allowDropInsideItem");
  },
  _createPlaceholder() {
    let $placeholderContainer;
    if (this._isIndicateMode()) {
      $placeholderContainer = renderer_default("<div>").addClass(this._addWidgetPrefix("placeholder")).insertBefore(this._getSourceDraggable()._$dragElement);
    }
    this._$placeholderElement = $placeholderContainer;
    return $placeholderContainer;
  },
  _getItems() {
    const itemsSelector = this._getItemsSelector();
    return this._$content().find(itemsSelector).not(`.${this._addWidgetPrefix("placeholder")}`).not(`.${this._addWidgetPrefix("clone")}`).toArray();
  },
  _allowReordering() {
    const sourceDraggable2 = this._getSourceDraggable();
    const targetDraggable2 = this._getTargetDraggable();
    return sourceDraggable2 !== targetDraggable2 || this.option("allowReordering");
  },
  _isValidPoint(visibleIndex, draggableVisibleIndex, dropInsideItem) {
    const allowDropInsideItem = this.option("allowDropInsideItem");
    const allowReordering = dropInsideItem || this._allowReordering();
    if (!allowReordering && (0 !== visibleIndex || !allowDropInsideItem)) {
      return false;
    }
    if (!this._isIndicateMode()) {
      return true;
    }
    return -1 === draggableVisibleIndex || visibleIndex !== draggableVisibleIndex && (dropInsideItem || visibleIndex !== draggableVisibleIndex + 1);
  },
  _getItemPoints() {
    const that = this;
    let result = [];
    let $item;
    let offset;
    let itemWidth;
    const rtlEnabled = that.option("rtlEnabled");
    const isVertical = that._isVerticalOrientation();
    const itemElements = that._getItems();
    const visibleItemElements = itemElements.filter(isElementVisible);
    const visibleItemCount = visibleItemElements.length;
    const $draggableItem = this._getDraggableElement();
    const draggableVisibleIndex = visibleItemElements.indexOf($draggableItem.get(0));
    if (visibleItemCount) {
      for (let i = 0; i <= visibleItemCount; i++) {
        const needCorrectLeftPosition = !isVertical && rtlEnabled ^ i === visibleItemCount;
        const needCorrectTopPosition = isVertical && i === visibleItemCount;
        if (i < visibleItemCount) {
          $item = renderer_default(visibleItemElements[i]);
          offset = $item.offset();
          itemWidth = getOuterWidth($item);
        }
        result.push({
          dropInsideItem: false,
          left: offset.left + (needCorrectLeftPosition ? itemWidth : 0),
          top: offset.top + (needCorrectTopPosition ? result[i - 1].height : 0),
          index: i === visibleItemCount ? itemElements.length : itemElements.indexOf($item.get(0)),
          $item,
          width: getOuterWidth($item),
          height: getOuterHeight($item),
          isValid: that._isValidPoint(i, draggableVisibleIndex)
        });
      }
      if (this.option("allowDropInsideItem")) {
        const points = result;
        result = [];
        for (let i = 0; i < points.length; i++) {
          result.push(points[i]);
          if (points[i + 1]) {
            result.push(extend({}, points[i], {
              dropInsideItem: true,
              top: Math.floor((points[i].top + points[i + 1].top) / 2),
              left: Math.floor((points[i].left + points[i + 1].left) / 2),
              isValid: this._isValidPoint(i, draggableVisibleIndex, true)
            }));
          }
        }
      }
    } else {
      result.push({
        dropInsideItem: false,
        index: 0,
        isValid: true
      });
    }
    return result;
  },
  _updateItemPoints(forceUpdate) {
    if (forceUpdate || this.option("autoUpdate") || !this.option("itemPoints")) {
      this.option("itemPoints", this._getItemPoints());
    }
  },
  _correctItemPoints(scrollBy2) {
    const itemPoints = this.option("itemPoints");
    if (scrollBy2 && itemPoints && !this.option("autoUpdate")) {
      const isVertical = this._isVerticalOrientation();
      const positionPropName = isVertical ? "top" : "left";
      itemPoints.forEach((itemPoint) => {
        itemPoint[positionPropName] -= scrollBy2;
      });
    }
  },
  _getElementIndex($itemElement) {
    return this._getItems().indexOf($itemElement.get(0));
  },
  _getDragTemplateArgs($element) {
    const args = this.callBase.apply(this, arguments);
    args.model.fromIndex = this._getElementIndex($element);
    return args;
  },
  _togglePlaceholder(value2) {
    this._$placeholderElement && this._$placeholderElement.toggle(value2);
  },
  _isVerticalOrientation() {
    return "vertical" === this.option("itemOrientation");
  },
  _normalizeToIndex(toIndex, skipOffsetting) {
    const isAnotherDraggable = this._getSourceDraggable() !== this._getTargetDraggable();
    const fromIndex = this._getActualFromIndex();
    if (null === toIndex) {
      return fromIndex;
    }
    return Math.max(isAnotherDraggable || fromIndex >= toIndex || skipOffsetting ? toIndex : toIndex - 1, 0);
  },
  _updatePlaceholderPosition(e, itemPoint) {
    const sourceDraggable2 = this._getSourceDraggable();
    const toIndex = this._normalizeToIndex(itemPoint.index, itemPoint.dropInsideItem);
    const eventArgs = extend(this._getEventArgs(e), {
      toIndex,
      dropInsideItem: itemPoint.dropInsideItem
    });
    itemPoint.isValid && this._getAction("onDragChange")(eventArgs);
    if (eventArgs.cancel || !itemPoint.isValid) {
      if (!itemPoint.isValid) {
        this.option({
          dropInsideItem: false,
          toIndex: null
        });
      }
      return;
    }
    this.option({
      dropInsideItem: itemPoint.dropInsideItem,
      toIndex: itemPoint.index
    });
    this._getAction("onPlaceholderPrepared")(extend(this._getEventArgs(e), {
      placeholderElement: getPublicElement(this._$placeholderElement),
      dragElement: getPublicElement(sourceDraggable2._$dragElement)
    }));
    this._updateItemPoints();
  },
  _makeWidthCorrection($item, width) {
    this._$scrollable = this._getScrollable($item);
    if (this._$scrollable) {
      const scrollableWidth = getWidth(this._$scrollable);
      const overflowLeft = this._$scrollable.offset().left - $item.offset().left;
      const overflowRight = getOuterWidth($item) - overflowLeft - scrollableWidth;
      if (overflowLeft > 0) {
        width -= overflowLeft;
      }
      if (overflowRight > 0) {
        width -= overflowRight;
      }
    }
    return width;
  },
  _updatePlaceholderSizes($placeholderElement, itemElement) {
    const dropInsideItem = this.option("dropInsideItem");
    const $item = renderer_default(itemElement);
    const isVertical = this._isVerticalOrientation();
    let width = "";
    let height = "";
    $placeholderElement.toggleClass(this._addWidgetPrefix("placeholder-inside"), dropInsideItem);
    if (isVertical || dropInsideItem) {
      width = getOuterWidth($item);
    }
    if (!isVertical || dropInsideItem) {
      height = getOuterHeight($item);
    }
    width = this._makeWidthCorrection($item, width);
    $placeholderElement.css({
      width,
      height
    });
  },
  _moveItem($itemElement, index, cancelRemove) {
    let $prevTargetItemElement;
    const $itemElements = this._getItems();
    const $targetItemElement = $itemElements[index];
    const sourceDraggable2 = this._getSourceDraggable();
    if (cancelRemove) {
      $itemElement = $itemElement.clone();
      sourceDraggable2._toggleDragSourceClass(false, $itemElement);
    }
    if (!$targetItemElement) {
      $prevTargetItemElement = $itemElements[index - 1];
    }
    this._moveItemCore($itemElement, $targetItemElement, $prevTargetItemElement);
  },
  _moveItemCore($targetItem, item, prevItem) {
    if (!item && !prevItem) {
      $targetItem.appendTo(this.$element());
    } else if (prevItem) {
      $targetItem.insertAfter(renderer_default(prevItem));
    } else {
      $targetItem.insertBefore(renderer_default(item));
    }
  },
  _getDragStartArgs(e, $itemElement) {
    return extend(this.callBase.apply(this, arguments), {
      fromIndex: this._getElementIndex($itemElement)
    });
  },
  _getEventArgs(e) {
    const sourceDraggable2 = this._getSourceDraggable();
    const targetDraggable2 = this._getTargetDraggable();
    const dropInsideItem = targetDraggable2.option("dropInsideItem");
    return extend(this.callBase.apply(this, arguments), {
      fromIndex: sourceDraggable2.option("fromIndex"),
      toIndex: this._normalizeToIndex(targetDraggable2.option("toIndex"), dropInsideItem),
      dropInsideItem
    });
  },
  _optionChanged(args) {
    const {
      name
    } = args;
    switch (name) {
      case "onDragChange":
      case "onPlaceholderPrepared":
      case "onAdd":
      case "onRemove":
      case "onReorder":
        this[`_${name}Action`] = this._createActionByOption(name);
        break;
      case "itemOrientation":
      case "allowDropInsideItem":
      case "moveItemOnDrop":
      case "dropFeedbackMode":
      case "itemPoints":
      case "animation":
      case "allowReordering":
      case "fromIndexOffset":
      case "offset":
      case "draggableElementSize":
      case "autoUpdate":
        break;
      case "fromIndex":
        [false, true].forEach((isDragSource) => {
          const fromIndex = isDragSource ? args.value : args.previousValue;
          if (null !== fromIndex) {
            const $fromElement = renderer_default(this._getItems()[fromIndex]);
            this._toggleDragSourceClass(isDragSource, $fromElement);
          }
        });
        break;
      case "dropInsideItem":
        this._optionChangedDropInsideItem(args);
        break;
      case "toIndex":
        this._optionChangedToIndex(args);
        break;
      default:
        this.callBase(args);
    }
  },
  _optionChangedDropInsideItem() {
    if (this._isIndicateMode() && this._$placeholderElement) {
      this._movePlaceholder();
    }
  },
  _isPositionVisible(position) {
    const $element = this.$element();
    let scrollContainer;
    if ("hidden" !== $element.css("overflow")) {
      scrollContainer = $element.get(0);
    } else {
      $element.parents().each(function() {
        if ("visible" !== renderer_default(this).css("overflow")) {
          scrollContainer = this;
          return false;
        }
        return;
      });
    }
    if (scrollContainer) {
      const clientRect = getBoundingRect(scrollContainer);
      const isVerticalOrientation = this._isVerticalOrientation();
      const start = isVerticalOrientation ? "top" : "left";
      const end = isVerticalOrientation ? "bottom" : "right";
      const pageOffset = isVerticalOrientation ? window3.pageYOffset : window3.pageXOffset;
      if (position[start] < clientRect[start] + pageOffset || position[start] > clientRect[end] + pageOffset) {
        return false;
      }
    }
    return true;
  },
  _optionChangedToIndex(args) {
    const toIndex = args.value;
    if (this._isIndicateMode()) {
      const showPlaceholder = null !== toIndex && toIndex >= 0;
      this._togglePlaceholder(showPlaceholder);
      if (showPlaceholder) {
        this._movePlaceholder();
      }
    } else {
      this._moveItems(args.previousValue, args.value, args.fullUpdate);
    }
  },
  update() {
    if (null === this.option("fromIndex") && null === this.option("toIndex")) {
      return;
    }
    this._updateItemPoints(true);
    this._updateDragSourceClass();
    const toIndex = this.option("toIndex");
    this._optionChangedToIndex({
      value: toIndex,
      fullUpdate: true
    });
  },
  _updateDragSourceClass() {
    const fromIndex = this._getActualFromIndex();
    const $fromElement = renderer_default(this._getItems()[fromIndex]);
    if ($fromElement.length) {
      this._$sourceElement = $fromElement;
      this._toggleDragSourceClass(true, $fromElement);
    }
  },
  _makeLeftCorrection(left) {
    const $scrollable = this._$scrollable;
    if ($scrollable && this._isVerticalOrientation()) {
      const overflowLeft = $scrollable.offset().left - left;
      if (overflowLeft > 0) {
        left += overflowLeft;
      }
    }
    return left;
  },
  _movePlaceholder() {
    const that = this;
    const $placeholderElement = that._$placeholderElement || that._createPlaceholder();
    if (!$placeholderElement) {
      return;
    }
    const items = that._getItems();
    const toIndex = that.option("toIndex");
    const isVerticalOrientation = that._isVerticalOrientation();
    const rtlEnabled = this.option("rtlEnabled");
    const dropInsideItem = that.option("dropInsideItem");
    let position = null;
    let itemElement = items[toIndex];
    if (itemElement) {
      const $itemElement = renderer_default(itemElement);
      position = $itemElement.offset();
      if (!isVerticalOrientation && rtlEnabled && !dropInsideItem) {
        position.left += getOuterWidth($itemElement, true);
      }
    } else {
      const prevVisibleItemElement = itemElement = this._getPrevVisibleItem(items, toIndex);
      if (prevVisibleItemElement) {
        position = renderer_default(prevVisibleItemElement).offset();
        if (isVerticalOrientation) {
          position.top += getOuterHeight(prevVisibleItemElement, true);
        } else if (!rtlEnabled) {
          position.left += getOuterWidth(prevVisibleItemElement, true);
        }
      }
    }
    that._updatePlaceholderSizes($placeholderElement, itemElement);
    if (position && !that._isPositionVisible(position)) {
      position = null;
    }
    if (position) {
      const isLastVerticalPosition = isVerticalOrientation && toIndex === items.length;
      const outerPlaceholderHeight = getOuterHeight($placeholderElement);
      position.left = that._makeLeftCorrection(position.left);
      position.top = isLastVerticalPosition && position.top >= outerPlaceholderHeight ? position.top - outerPlaceholderHeight : position.top;
      that._move(position, $placeholderElement);
    }
    $placeholderElement.toggle(!!position);
  },
  _getPositions(items, elementSize, fromIndex, toIndex) {
    const positions = [];
    for (let i = 0; i < items.length; i++) {
      let position = 0;
      if (null === toIndex || null === fromIndex) {
        positions.push(position);
        continue;
      }
      if (-1 === fromIndex) {
        if (i >= toIndex) {
          position = elementSize;
        }
      } else if (-1 === toIndex) {
        if (i > fromIndex) {
          position = -elementSize;
        }
      } else if (fromIndex < toIndex) {
        if (i > fromIndex && i < toIndex) {
          position = -elementSize;
        }
      } else if (fromIndex > toIndex) {
        if (i >= toIndex && i < fromIndex) {
          position = elementSize;
        }
      }
      positions.push(position);
    }
    return positions;
  },
  _getDraggableElementSize(isVerticalOrientation) {
    const $draggableItem = this._getDraggableElement();
    let size = this.option("draggableElementSize");
    if (!size) {
      size = isVerticalOrientation ? (getOuterHeight($draggableItem) + getOuterHeight($draggableItem, true)) / 2 : (getOuterWidth($draggableItem) + getOuterWidth($draggableItem, true)) / 2;
      if (!this.option("autoUpdate")) {
        this.option("draggableElementSize", size);
      }
    }
    return size;
  },
  _getActualFromIndex() {
    const {
      fromIndex,
      fromIndexOffset,
      offset
    } = this.option();
    return null == fromIndex ? null : fromIndex + fromIndexOffset - offset;
  },
  _moveItems(prevToIndex, toIndex, fullUpdate) {
    const fromIndex = this._getActualFromIndex();
    const isVerticalOrientation = this._isVerticalOrientation();
    const positionPropName = isVerticalOrientation ? "top" : "left";
    const elementSize = this._getDraggableElementSize(isVerticalOrientation);
    const items = this._getItems();
    const prevPositions = this._getPositions(items, elementSize, fromIndex, prevToIndex);
    const positions = this._getPositions(items, elementSize, fromIndex, toIndex);
    const animationConfig = this.option("animation");
    const rtlEnabled = this.option("rtlEnabled");
    for (let i = 0; i < items.length; i++) {
      const itemElement = items[i];
      const prevPosition = prevPositions[i];
      const position = positions[i];
      if (null === toIndex || null === fromIndex) {
        stopAnimation(itemElement);
      } else if (prevPosition !== position || fullUpdate && isDefined(position)) {
        animate(itemElement, extend({}, animationConfig, {
          to: {
            [positionPropName]: !isVerticalOrientation && rtlEnabled ? -position : position
          }
        }));
      }
    }
  },
  _toggleDragSourceClass(value2, $element) {
    const $sourceElement = $element || this._$sourceElement;
    this.callBase.apply(this, arguments);
    if (!this._isIndicateMode()) {
      $sourceElement && $sourceElement.toggleClass(this._addWidgetPrefix("source-hidden"), value2);
    }
  },
  _dispose() {
    this.reset();
    this.callBase();
  },
  _fireAddEvent(sourceEvent) {
    const args = this._getEventArgs(sourceEvent);
    this._getAction("onAdd")(args);
    return args.cancel;
  },
  _fireRemoveEvent(sourceEvent) {
    const sourceDraggable2 = this._getSourceDraggable();
    const args = this._getEventArgs(sourceEvent);
    sourceDraggable2._getAction("onRemove")(args);
    return args.cancel;
  },
  _fireReorderEvent(sourceEvent) {
    const args = this._getEventArgs(sourceEvent);
    this._getAction("onReorder")(args);
    return args.promise || Deferred().resolve();
  }
});
component_registrator_default(SORTABLE, Sortable);
var m_sortable_default = Sortable;

// node_modules/devextreme/esm/ui/sortable.js
var sortable_default = m_sortable_default;

// node_modules/devextreme/esm/__internal/ui/list/m_list.edit.decorator.reorder.js
var REORDER_HANDLE_CONTAINER_CLASS = "dx-list-reorder-handle-container";
var REORDER_HANDLE_CLASS = "dx-list-reorder-handle";
var REORDERING_ITEM_GHOST_CLASS = "dx-list-item-ghost-reordering";
register("reorder", "default", m_list_edit_decorator_default.inherit({
  _init() {
    const list = this._list;
    this._groupedEnabled = this._list.option("grouped");
    this._lockedDrag = false;
    const filter = this._groupedEnabled ? "> .dx-list-items > .dx-list-group > .dx-list-group-body > .dx-list-item" : "> .dx-list-items > .dx-list-item";
    this._sortable = list._createComponent(list._scrollView.content(), sortable_default, extend({
      component: list,
      contentTemplate: null,
      allowReordering: false,
      filter,
      container: list.$element(),
      dragDirection: list.option("itemDragging.group") ? "both" : "vertical",
      handle: `.${REORDER_HANDLE_CLASS}`,
      dragTemplate: this._dragTemplate,
      onDragStart: this._dragStartHandler.bind(this),
      onDragChange: this._dragChangeHandler.bind(this),
      onReorder: this._reorderHandler.bind(this)
    }, list.option("itemDragging")));
  },
  afterRender() {
    this._sortable.update();
  },
  _dragTemplate(e) {
    const result = renderer_default(e.itemElement).clone().addClass(REORDERING_ITEM_GHOST_CLASS).addClass("dx-state-hover");
    setWidth(result, getWidth(e.itemElement));
    return result;
  },
  _dragStartHandler(e) {
    if (this._lockedDrag) {
      e.cancel = true;
    }
  },
  _dragChangeHandler(e) {
    if (this._groupedEnabled && !this._sameParent(e.fromIndex, e.toIndex)) {
      e.cancel = true;
    }
  },
  _sameParent(fromIndex, toIndex) {
    const $dragging = this._list.getItemElementByFlatIndex(fromIndex);
    const $over = this._list.getItemElementByFlatIndex(toIndex);
    return $over.parent().get(0) === $dragging.parent().get(0);
  },
  _reorderHandler(e) {
    const $targetElement = this._list.getItemElementByFlatIndex(e.toIndex);
    this._list.reorderItem(renderer_default(e.itemElement), $targetElement);
  },
  afterBag(config) {
    const $handle = renderer_default("<div>").addClass(REORDER_HANDLE_CLASS);
    events_engine_default.on($handle, "dxpointerdown", (e) => {
      this._lockedDrag = !isMouseEvent(e);
    });
    events_engine_default.on($handle, "dxhold", {
      timeout: 30
    }, (e) => {
      e.cancel = true;
      this._lockedDrag = false;
    });
    config.$container.addClass(REORDER_HANDLE_CONTAINER_CLASS).append($handle);
  }
}));

// node_modules/devextreme/esm/__internal/ui/list/modules/m_search.js
ui_search_box_mixin_default.setEditorClass(text_box_default);

// node_modules/devextreme/esm/ui/list.js
var list_default = list_light_default;

// node_modules/devextreme-angular/fesm2022/devextreme-angular-ui-list.mjs
var DxListComponent = class _DxListComponent extends DxComponent {
  _watcherHelper;
  _idh;
  instance = null;
  /**
   * Specifies the shortcut key that sets focus on the UI component.
  
   */
  get accessKey() {
    return this._getOption("accessKey");
  }
  set accessKey(value2) {
    this._setOption("accessKey", value2);
  }
  /**
   * Specifies whether the UI component changes its visual state as a result of user interaction.
  
   */
  get activeStateEnabled() {
    return this._getOption("activeStateEnabled");
  }
  set activeStateEnabled(value2) {
    this._setOption("activeStateEnabled", value2);
  }
  /**
   * Specifies whether or not an end user can delete list items.
  
   */
  get allowItemDeleting() {
    return this._getOption("allowItemDeleting");
  }
  set allowItemDeleting(value2) {
    this._setOption("allowItemDeleting", value2);
  }
  /**
   * A Boolean value specifying whether to enable or disable the bounce-back effect.
  
   */
  get bounceEnabled() {
    return this._getOption("bounceEnabled");
  }
  set bounceEnabled(value2) {
    this._setOption("bounceEnabled", value2);
  }
  /**
   * Specifies whether or not an end user can collapse groups.
  
   */
  get collapsibleGroups() {
    return this._getOption("collapsibleGroups");
  }
  set collapsibleGroups(value2) {
    this._setOption("collapsibleGroups", value2);
  }
  /**
   * Binds the UI component to data.
  
   */
  get dataSource() {
    return this._getOption("dataSource");
  }
  set dataSource(value2) {
    this._setOption("dataSource", value2);
  }
  /**
   * Specifies whether the UI component responds to user interaction.
  
   */
  get disabled() {
    return this._getOption("disabled");
  }
  set disabled(value2) {
    this._setOption("disabled", value2);
  }
  /**
   * Specifies the data field whose values should be displayed. Defaults to &apos;text&apos; when the data source contains objects.
  
   */
  get displayExpr() {
    return this._getOption("displayExpr");
  }
  set displayExpr(value2) {
    this._setOption("displayExpr", value2);
  }
  /**
   * Specifies the global attributes to be attached to the UI component&apos;s container element.
  
   */
  get elementAttr() {
    return this._getOption("elementAttr");
  }
  set elementAttr(value2) {
    this._setOption("elementAttr", value2);
  }
  /**
   * Specifies whether the UI component can be focused using keyboard navigation.
  
   */
  get focusStateEnabled() {
    return this._getOption("focusStateEnabled");
  }
  set focusStateEnabled(value2) {
    this._setOption("focusStateEnabled", value2);
  }
  /**
   * Specifies whether data items should be grouped.
  
   */
  get grouped() {
    return this._getOption("grouped");
  }
  set grouped(value2) {
    this._setOption("grouped", value2);
  }
  /**
   * Specifies a custom template for group captions.
  
   */
  get groupTemplate() {
    return this._getOption("groupTemplate");
  }
  set groupTemplate(value2) {
    this._setOption("groupTemplate", value2);
  }
  /**
   * Specifies the UI component&apos;s height.
  
   */
  get height() {
    return this._getOption("height");
  }
  set height(value2) {
    this._setOption("height", value2);
  }
  /**
   * Specifies text for a hint that appears when a user pauses on the UI component.
  
   */
  get hint() {
    return this._getOption("hint");
  }
  set hint(value2) {
    this._setOption("hint", value2);
  }
  /**
   * Specifies whether the UI component changes its state when a user pauses on it.
  
   */
  get hoverStateEnabled() {
    return this._getOption("hoverStateEnabled");
  }
  set hoverStateEnabled(value2) {
    this._setOption("hoverStateEnabled", value2);
  }
  /**
   * Specifies whether or not to show the loading panel when the DataSource bound to the UI component is loading data.
  
   */
  get indicateLoading() {
    return this._getOption("indicateLoading");
  }
  set indicateLoading(value2) {
    this._setOption("indicateLoading", value2);
  }
  /**
   * Specifies the way a user can delete items from the list.
  
   */
  get itemDeleteMode() {
    return this._getOption("itemDeleteMode");
  }
  set itemDeleteMode(value2) {
    this._setOption("itemDeleteMode", value2);
  }
  /**
   * Configures item reordering using drag and drop gestures.
  
   */
  get itemDragging() {
    return this._getOption("itemDragging");
  }
  set itemDragging(value2) {
    this._setOption("itemDragging", value2);
  }
  /**
   * The time period in milliseconds before the onItemHold event is raised.
  
   */
  get itemHoldTimeout() {
    return this._getOption("itemHoldTimeout");
  }
  set itemHoldTimeout(value2) {
    this._setOption("itemHoldTimeout", value2);
  }
  /**
   * An array of items displayed by the UI component.
  
   */
  get items() {
    return this._getOption("items");
  }
  set items(value2) {
    this._setOption("items", value2);
  }
  /**
   * Specifies a custom template for items.
  
   */
  get itemTemplate() {
    return this._getOption("itemTemplate");
  }
  set itemTemplate(value2) {
    this._setOption("itemTemplate", value2);
  }
  /**
   * Specifies the key property that provides key values to access data items. Each key value must be unique.
  
   */
  get keyExpr() {
    return this._getOption("keyExpr");
  }
  set keyExpr(value2) {
    this._setOption("keyExpr", value2);
  }
  /**
   * Specifies the array of items for a context menu called for a list item.
  
   */
  get menuItems() {
    return this._getOption("menuItems");
  }
  set menuItems(value2) {
    this._setOption("menuItems", value2);
  }
  /**
   * Specifies whether an item context menu is shown when a user holds or swipes an item.
  
   */
  get menuMode() {
    return this._getOption("menuMode");
  }
  set menuMode(value2) {
    this._setOption("menuMode", value2);
  }
  /**
   * The text displayed on the button used to load the next page from the data source.
  
   */
  get nextButtonText() {
    return this._getOption("nextButtonText");
  }
  set nextButtonText(value2) {
    this._setOption("nextButtonText", value2);
  }
  /**
   * Specifies the text or HTML markup displayed by the UI component if the item collection is empty.
  
   */
  get noDataText() {
    return this._getOption("noDataText");
  }
  set noDataText(value2) {
    this._setOption("noDataText", value2);
  }
  /**
   * Specifies the text shown in the pullDown panel, which is displayed when the list is scrolled to the bottom.
  
   */
  get pageLoadingText() {
    return this._getOption("pageLoadingText");
  }
  set pageLoadingText(value2) {
    this._setOption("pageLoadingText", value2);
  }
  /**
   * Specifies whether the next page is loaded when a user scrolls the UI component to the bottom or when the &apos;next&apos; button is clicked.
  
   */
  get pageLoadMode() {
    return this._getOption("pageLoadMode");
  }
  set pageLoadMode(value2) {
    this._setOption("pageLoadMode", value2);
  }
  /**
   * Specifies the text displayed in the pullDown panel when the list is pulled below the refresh threshold.
  
   */
  get pulledDownText() {
    return this._getOption("pulledDownText");
  }
  set pulledDownText(value2) {
    this._setOption("pulledDownText", value2);
  }
  /**
   * Specifies the text shown in the pullDown panel while the list is being pulled down to the refresh threshold.
  
   */
  get pullingDownText() {
    return this._getOption("pullingDownText");
  }
  set pullingDownText(value2) {
    this._setOption("pullingDownText", value2);
  }
  /**
   * A Boolean value specifying whether or not the UI component supports the &apos;pull down to refresh&apos; gesture.
  
   */
  get pullRefreshEnabled() {
    return this._getOption("pullRefreshEnabled");
  }
  set pullRefreshEnabled(value2) {
    this._setOption("pullRefreshEnabled", value2);
  }
  /**
   * Specifies the text displayed in the pullDown panel while the list is being refreshed.
  
   */
  get refreshingText() {
    return this._getOption("refreshingText");
  }
  set refreshingText(value2) {
    this._setOption("refreshingText", value2);
  }
  /**
   * Specifies whether to repaint only those elements whose data changed.
  
   */
  get repaintChangesOnly() {
    return this._getOption("repaintChangesOnly");
  }
  set repaintChangesOnly(value2) {
    this._setOption("repaintChangesOnly", value2);
  }
  /**
   * Switches the UI component to a right-to-left representation.
  
   */
  get rtlEnabled() {
    return this._getOption("rtlEnabled");
  }
  set rtlEnabled(value2) {
    this._setOption("rtlEnabled", value2);
  }
  /**
   * A Boolean value specifying if the list is scrolled by content.
  
   */
  get scrollByContent() {
    return this._getOption("scrollByContent");
  }
  set scrollByContent(value2) {
    this._setOption("scrollByContent", value2);
  }
  /**
   * Specifies whether a user can scroll the content with the scrollbar. Applies only if useNativeScrolling is false.
  
   */
  get scrollByThumb() {
    return this._getOption("scrollByThumb");
  }
  set scrollByThumb(value2) {
    this._setOption("scrollByThumb", value2);
  }
  /**
   * A Boolean value specifying whether to enable or disable list scrolling.
  
   */
  get scrollingEnabled() {
    return this._getOption("scrollingEnabled");
  }
  set scrollingEnabled(value2) {
    this._setOption("scrollingEnabled", value2);
  }
  /**
   * Configures the search panel.
  
   */
  get searchEditorOptions() {
    return this._getOption("searchEditorOptions");
  }
  set searchEditorOptions(value2) {
    this._setOption("searchEditorOptions", value2);
  }
  /**
   * Specifies whether the search panel is visible.
  
   */
  get searchEnabled() {
    return this._getOption("searchEnabled");
  }
  set searchEnabled(value2) {
    this._setOption("searchEnabled", value2);
  }
  /**
   * Specifies a data object&apos;s field name or an expression whose value is compared to the search string.
  
   */
  get searchExpr() {
    return this._getOption("searchExpr");
  }
  set searchExpr(value2) {
    this._setOption("searchExpr", value2);
  }
  /**
   * Specifies a comparison operation used to search UI component items.
  
   */
  get searchMode() {
    return this._getOption("searchMode");
  }
  set searchMode(value2) {
    this._setOption("searchMode", value2);
  }
  /**
   * Specifies a delay in milliseconds between when a user finishes typing, and the search is executed.
  
   */
  get searchTimeout() {
    return this._getOption("searchTimeout");
  }
  set searchTimeout(value2) {
    this._setOption("searchTimeout", value2);
  }
  /**
   * Specifies the current search string.
  
   */
  get searchValue() {
    return this._getOption("searchValue");
  }
  set searchValue(value2) {
    this._setOption("searchValue", value2);
  }
  /**
   * Specifies the mode in which all items are selected.
  
   */
  get selectAllMode() {
    return this._getOption("selectAllMode");
  }
  set selectAllMode(value2) {
    this._setOption("selectAllMode", value2);
  }
  /**
   * Specifies the text displayed at the &apos;Select All&apos; check box.
  
   */
  get selectAllText() {
    return this._getOption("selectAllText");
  }
  set selectAllText(value2) {
    this._setOption("selectAllText", value2);
  }
  /**
   * Specifies whether an item is selected if a user clicks it.
  
   */
  get selectByClick() {
    return this._getOption("selectByClick");
  }
  set selectByClick(value2) {
    this._setOption("selectByClick", value2);
  }
  /**
   * Specifies an array of currently selected item keys.
  
   */
  get selectedItemKeys() {
    return this._getOption("selectedItemKeys");
  }
  set selectedItemKeys(value2) {
    this._setOption("selectedItemKeys", value2);
  }
  /**
   * An array of currently selected item objects.
  
   */
  get selectedItems() {
    return this._getOption("selectedItems");
  }
  set selectedItems(value2) {
    this._setOption("selectedItems", value2);
  }
  /**
   * Specifies item selection mode.
  
   */
  get selectionMode() {
    return this._getOption("selectionMode");
  }
  set selectionMode(value2) {
    this._setOption("selectionMode", value2);
  }
  /**
   * Specifies when the UI component shows the scrollbar.
  
   */
  get showScrollbar() {
    return this._getOption("showScrollbar");
  }
  set showScrollbar(value2) {
    this._setOption("showScrollbar", value2);
  }
  /**
   * Specifies whether or not to display controls used to select list items.
  
   */
  get showSelectionControls() {
    return this._getOption("showSelectionControls");
  }
  set showSelectionControls(value2) {
    this._setOption("showSelectionControls", value2);
  }
  /**
   * Specifies the number of the element when the Tab key is used for navigating.
  
   */
  get tabIndex() {
    return this._getOption("tabIndex");
  }
  set tabIndex(value2) {
    this._setOption("tabIndex", value2);
  }
  /**
   * Specifies whether or not the UI component uses native scrolling.
  
   */
  get useNativeScrolling() {
    return this._getOption("useNativeScrolling");
  }
  set useNativeScrolling(value2) {
    this._setOption("useNativeScrolling", value2);
  }
  /**
   * Specifies whether the UI component is visible.
  
   */
  get visible() {
    return this._getOption("visible");
  }
  set visible(value2) {
    this._setOption("visible", value2);
  }
  /**
   * Specifies the UI component&apos;s width.
  
   */
  get width() {
    return this._getOption("width");
  }
  set width(value2) {
    this._setOption("width", value2);
  }
  /**
  
   * A function that is executed when the UI component is rendered and each time the component is repainted.
  
  
   */
  onContentReady;
  /**
  
   * A function that is executed before the UI component is disposed of.
  
  
   */
  onDisposing;
  /**
  
   * A function that is executed when a group element is rendered.
  
  
   */
  onGroupRendered;
  /**
  
   * A function used in JavaScript frameworks to save the UI component instance.
  
  
   */
  onInitialized;
  /**
  
   * A function that is executed when a collection item is clicked or tapped.
  
  
   */
  onItemClick;
  /**
  
   * A function that is executed when a collection item is right-clicked or pressed.
  
  
   */
  onItemContextMenu;
  /**
  
   * A function that is executed after a list item is deleted from the data source.
  
  
   */
  onItemDeleted;
  /**
  
   * A function that is executed before a collection item is deleted from the data source.
  
  
   */
  onItemDeleting;
  /**
  
   * A function that is executed when a collection item has been held for a specified period.
  
  
   */
  onItemHold;
  /**
  
   * A function that is executed after a collection item is rendered.
  
  
   */
  onItemRendered;
  /**
  
   * A function that is executed after a list item is moved to another position.
  
  
   */
  onItemReordered;
  /**
  
   * A function that is executed when a list item is swiped.
  
  
   */
  onItemSwipe;
  /**
  
   * A function that is executed after a UI component property is changed.
  
  
   */
  onOptionChanged;
  /**
  
   * A function that is executed before the next page is loaded.
  
  
   */
  onPageLoading;
  /**
  
   * A function that is executed when the &apos;pull to refresh&apos; gesture is performed. Supported on mobile devices only.
  
  
   */
  onPullRefresh;
  /**
  
   * A function that is executed on each scroll gesture.
  
  
   */
  onScroll;
  /**
  
   * A function that is executed when the &apos;Select All&apos; check box value is changed. Applies only if the selectionMode is &apos;all&apos;.
  
  
   */
  onSelectAllValueChanged;
  /**
  
   * A function that is executed when a collection item is selected or selection is canceled.
  
  
   */
  onSelectionChanged;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  accessKeyChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  activeStateEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  allowItemDeletingChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  bounceEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  collapsibleGroupsChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  dataSourceChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  disabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  displayExprChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  elementAttrChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  focusStateEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  groupedChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  groupTemplateChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  heightChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  hintChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  hoverStateEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  indicateLoadingChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  itemDeleteModeChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  itemDraggingChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  itemHoldTimeoutChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  itemsChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  itemTemplateChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  keyExprChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  menuItemsChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  menuModeChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  nextButtonTextChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  noDataTextChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  pageLoadingTextChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  pageLoadModeChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  pulledDownTextChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  pullingDownTextChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  pullRefreshEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  refreshingTextChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  repaintChangesOnlyChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  rtlEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  scrollByContentChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  scrollByThumbChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  scrollingEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  searchEditorOptionsChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  searchEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  searchExprChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  searchModeChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  searchTimeoutChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  searchValueChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  selectAllModeChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  selectAllTextChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  selectByClickChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  selectedItemKeysChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  selectedItemsChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  selectionModeChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  showScrollbarChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  showSelectionControlsChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  tabIndexChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  useNativeScrollingChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  visibleChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  widthChange;
  get itemsChildren() {
    return this._getOption("items");
  }
  set itemsChildren(value2) {
    this.setChildren("items", value2);
  }
  get menuItemsChildren() {
    return this._getOption("menuItems");
  }
  set menuItemsChildren(value2) {
    this.setChildren("menuItems", value2);
  }
  constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
    super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
    this._watcherHelper = _watcherHelper;
    this._idh = _idh;
    this._createEventEmitters([{
      subscribe: "contentReady",
      emit: "onContentReady"
    }, {
      subscribe: "disposing",
      emit: "onDisposing"
    }, {
      subscribe: "groupRendered",
      emit: "onGroupRendered"
    }, {
      subscribe: "initialized",
      emit: "onInitialized"
    }, {
      subscribe: "itemClick",
      emit: "onItemClick"
    }, {
      subscribe: "itemContextMenu",
      emit: "onItemContextMenu"
    }, {
      subscribe: "itemDeleted",
      emit: "onItemDeleted"
    }, {
      subscribe: "itemDeleting",
      emit: "onItemDeleting"
    }, {
      subscribe: "itemHold",
      emit: "onItemHold"
    }, {
      subscribe: "itemRendered",
      emit: "onItemRendered"
    }, {
      subscribe: "itemReordered",
      emit: "onItemReordered"
    }, {
      subscribe: "itemSwipe",
      emit: "onItemSwipe"
    }, {
      subscribe: "optionChanged",
      emit: "onOptionChanged"
    }, {
      subscribe: "pageLoading",
      emit: "onPageLoading"
    }, {
      subscribe: "pullRefresh",
      emit: "onPullRefresh"
    }, {
      subscribe: "scroll",
      emit: "onScroll"
    }, {
      subscribe: "selectAllValueChanged",
      emit: "onSelectAllValueChanged"
    }, {
      subscribe: "selectionChanged",
      emit: "onSelectionChanged"
    }, {
      emit: "accessKeyChange"
    }, {
      emit: "activeStateEnabledChange"
    }, {
      emit: "allowItemDeletingChange"
    }, {
      emit: "bounceEnabledChange"
    }, {
      emit: "collapsibleGroupsChange"
    }, {
      emit: "dataSourceChange"
    }, {
      emit: "disabledChange"
    }, {
      emit: "displayExprChange"
    }, {
      emit: "elementAttrChange"
    }, {
      emit: "focusStateEnabledChange"
    }, {
      emit: "groupedChange"
    }, {
      emit: "groupTemplateChange"
    }, {
      emit: "heightChange"
    }, {
      emit: "hintChange"
    }, {
      emit: "hoverStateEnabledChange"
    }, {
      emit: "indicateLoadingChange"
    }, {
      emit: "itemDeleteModeChange"
    }, {
      emit: "itemDraggingChange"
    }, {
      emit: "itemHoldTimeoutChange"
    }, {
      emit: "itemsChange"
    }, {
      emit: "itemTemplateChange"
    }, {
      emit: "keyExprChange"
    }, {
      emit: "menuItemsChange"
    }, {
      emit: "menuModeChange"
    }, {
      emit: "nextButtonTextChange"
    }, {
      emit: "noDataTextChange"
    }, {
      emit: "pageLoadingTextChange"
    }, {
      emit: "pageLoadModeChange"
    }, {
      emit: "pulledDownTextChange"
    }, {
      emit: "pullingDownTextChange"
    }, {
      emit: "pullRefreshEnabledChange"
    }, {
      emit: "refreshingTextChange"
    }, {
      emit: "repaintChangesOnlyChange"
    }, {
      emit: "rtlEnabledChange"
    }, {
      emit: "scrollByContentChange"
    }, {
      emit: "scrollByThumbChange"
    }, {
      emit: "scrollingEnabledChange"
    }, {
      emit: "searchEditorOptionsChange"
    }, {
      emit: "searchEnabledChange"
    }, {
      emit: "searchExprChange"
    }, {
      emit: "searchModeChange"
    }, {
      emit: "searchTimeoutChange"
    }, {
      emit: "searchValueChange"
    }, {
      emit: "selectAllModeChange"
    }, {
      emit: "selectAllTextChange"
    }, {
      emit: "selectByClickChange"
    }, {
      emit: "selectedItemKeysChange"
    }, {
      emit: "selectedItemsChange"
    }, {
      emit: "selectionModeChange"
    }, {
      emit: "showScrollbarChange"
    }, {
      emit: "showSelectionControlsChange"
    }, {
      emit: "tabIndexChange"
    }, {
      emit: "useNativeScrollingChange"
    }, {
      emit: "visibleChange"
    }, {
      emit: "widthChange"
    }]);
    this._idh.setHost(this);
    optionHost.setHost(this);
  }
  _createInstance(element, options) {
    return new list_default(element, options);
  }
  ngOnDestroy() {
    this._destroyWidget();
  }
  ngOnChanges(changes) {
    super.ngOnChanges(changes);
    this.setupChanges("dataSource", changes);
    this.setupChanges("items", changes);
    this.setupChanges("menuItems", changes);
    this.setupChanges("searchExpr", changes);
    this.setupChanges("selectedItemKeys", changes);
    this.setupChanges("selectedItems", changes);
  }
  setupChanges(prop, changes) {
    if (!(prop in this._optionsToUpdate)) {
      this._idh.setup(prop, changes);
    }
  }
  ngDoCheck() {
    this._idh.doCheck("dataSource");
    this._idh.doCheck("items");
    this._idh.doCheck("menuItems");
    this._idh.doCheck("searchExpr");
    this._idh.doCheck("selectedItemKeys");
    this._idh.doCheck("selectedItems");
    this._watcherHelper.checkWatchers();
    super.ngDoCheck();
    super.clearChangedOptions();
  }
  _setOption(name, value2) {
    let isSetup = this._idh.setupSingle(name, value2);
    let isChanged = this._idh.getChanges(name, value2) !== null;
    if (isSetup || isChanged) {
      super._setOption(name, value2);
    }
  }
  /** @nocollapse */
  static ɵfac = function DxListComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _DxListComponent)(ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(NgZone), ɵɵdirectiveInject(DxTemplateHost), ɵɵdirectiveInject(WatcherHelper), ɵɵdirectiveInject(IterableDifferHelper), ɵɵdirectiveInject(NestedOptionHost), ɵɵdirectiveInject(TransferState), ɵɵdirectiveInject(PLATFORM_ID));
  };
  /** @nocollapse */
  static ɵcmp = ɵɵdefineComponent({
    type: _DxListComponent,
    selectors: [["dx-list"]],
    contentQueries: function DxListComponent_ContentQueries(rf, ctx, dirIndex) {
      if (rf & 1) {
        ɵɵcontentQuery(dirIndex, DxiItemComponent, 4);
        ɵɵcontentQuery(dirIndex, DxiMenuItemComponent, 4);
      }
      if (rf & 2) {
        let _t;
        ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.itemsChildren = _t);
        ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.menuItemsChildren = _t);
      }
    },
    inputs: {
      accessKey: "accessKey",
      activeStateEnabled: "activeStateEnabled",
      allowItemDeleting: "allowItemDeleting",
      bounceEnabled: "bounceEnabled",
      collapsibleGroups: "collapsibleGroups",
      dataSource: "dataSource",
      disabled: "disabled",
      displayExpr: "displayExpr",
      elementAttr: "elementAttr",
      focusStateEnabled: "focusStateEnabled",
      grouped: "grouped",
      groupTemplate: "groupTemplate",
      height: "height",
      hint: "hint",
      hoverStateEnabled: "hoverStateEnabled",
      indicateLoading: "indicateLoading",
      itemDeleteMode: "itemDeleteMode",
      itemDragging: "itemDragging",
      itemHoldTimeout: "itemHoldTimeout",
      items: "items",
      itemTemplate: "itemTemplate",
      keyExpr: "keyExpr",
      menuItems: "menuItems",
      menuMode: "menuMode",
      nextButtonText: "nextButtonText",
      noDataText: "noDataText",
      pageLoadingText: "pageLoadingText",
      pageLoadMode: "pageLoadMode",
      pulledDownText: "pulledDownText",
      pullingDownText: "pullingDownText",
      pullRefreshEnabled: "pullRefreshEnabled",
      refreshingText: "refreshingText",
      repaintChangesOnly: "repaintChangesOnly",
      rtlEnabled: "rtlEnabled",
      scrollByContent: "scrollByContent",
      scrollByThumb: "scrollByThumb",
      scrollingEnabled: "scrollingEnabled",
      searchEditorOptions: "searchEditorOptions",
      searchEnabled: "searchEnabled",
      searchExpr: "searchExpr",
      searchMode: "searchMode",
      searchTimeout: "searchTimeout",
      searchValue: "searchValue",
      selectAllMode: "selectAllMode",
      selectAllText: "selectAllText",
      selectByClick: "selectByClick",
      selectedItemKeys: "selectedItemKeys",
      selectedItems: "selectedItems",
      selectionMode: "selectionMode",
      showScrollbar: "showScrollbar",
      showSelectionControls: "showSelectionControls",
      tabIndex: "tabIndex",
      useNativeScrolling: "useNativeScrolling",
      visible: "visible",
      width: "width"
    },
    outputs: {
      onContentReady: "onContentReady",
      onDisposing: "onDisposing",
      onGroupRendered: "onGroupRendered",
      onInitialized: "onInitialized",
      onItemClick: "onItemClick",
      onItemContextMenu: "onItemContextMenu",
      onItemDeleted: "onItemDeleted",
      onItemDeleting: "onItemDeleting",
      onItemHold: "onItemHold",
      onItemRendered: "onItemRendered",
      onItemReordered: "onItemReordered",
      onItemSwipe: "onItemSwipe",
      onOptionChanged: "onOptionChanged",
      onPageLoading: "onPageLoading",
      onPullRefresh: "onPullRefresh",
      onScroll: "onScroll",
      onSelectAllValueChanged: "onSelectAllValueChanged",
      onSelectionChanged: "onSelectionChanged",
      accessKeyChange: "accessKeyChange",
      activeStateEnabledChange: "activeStateEnabledChange",
      allowItemDeletingChange: "allowItemDeletingChange",
      bounceEnabledChange: "bounceEnabledChange",
      collapsibleGroupsChange: "collapsibleGroupsChange",
      dataSourceChange: "dataSourceChange",
      disabledChange: "disabledChange",
      displayExprChange: "displayExprChange",
      elementAttrChange: "elementAttrChange",
      focusStateEnabledChange: "focusStateEnabledChange",
      groupedChange: "groupedChange",
      groupTemplateChange: "groupTemplateChange",
      heightChange: "heightChange",
      hintChange: "hintChange",
      hoverStateEnabledChange: "hoverStateEnabledChange",
      indicateLoadingChange: "indicateLoadingChange",
      itemDeleteModeChange: "itemDeleteModeChange",
      itemDraggingChange: "itemDraggingChange",
      itemHoldTimeoutChange: "itemHoldTimeoutChange",
      itemsChange: "itemsChange",
      itemTemplateChange: "itemTemplateChange",
      keyExprChange: "keyExprChange",
      menuItemsChange: "menuItemsChange",
      menuModeChange: "menuModeChange",
      nextButtonTextChange: "nextButtonTextChange",
      noDataTextChange: "noDataTextChange",
      pageLoadingTextChange: "pageLoadingTextChange",
      pageLoadModeChange: "pageLoadModeChange",
      pulledDownTextChange: "pulledDownTextChange",
      pullingDownTextChange: "pullingDownTextChange",
      pullRefreshEnabledChange: "pullRefreshEnabledChange",
      refreshingTextChange: "refreshingTextChange",
      repaintChangesOnlyChange: "repaintChangesOnlyChange",
      rtlEnabledChange: "rtlEnabledChange",
      scrollByContentChange: "scrollByContentChange",
      scrollByThumbChange: "scrollByThumbChange",
      scrollingEnabledChange: "scrollingEnabledChange",
      searchEditorOptionsChange: "searchEditorOptionsChange",
      searchEnabledChange: "searchEnabledChange",
      searchExprChange: "searchExprChange",
      searchModeChange: "searchModeChange",
      searchTimeoutChange: "searchTimeoutChange",
      searchValueChange: "searchValueChange",
      selectAllModeChange: "selectAllModeChange",
      selectAllTextChange: "selectAllTextChange",
      selectByClickChange: "selectByClickChange",
      selectedItemKeysChange: "selectedItemKeysChange",
      selectedItemsChange: "selectedItemsChange",
      selectionModeChange: "selectionModeChange",
      showScrollbarChange: "showScrollbarChange",
      showSelectionControlsChange: "showSelectionControlsChange",
      tabIndexChange: "tabIndexChange",
      useNativeScrollingChange: "useNativeScrollingChange",
      visibleChange: "visibleChange",
      widthChange: "widthChange"
    },
    standalone: false,
    features: [ɵɵProvidersFeature([DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper]), ɵɵInheritDefinitionFeature, ɵɵNgOnChangesFeature],
    decls: 0,
    vars: 0,
    template: function DxListComponent_Template(rf, ctx) {
    },
    encapsulation: 2
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DxListComponent, [{
    type: Component,
    args: [{
      selector: "dx-list",
      template: "",
      providers: [DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper]
    }]
  }], function() {
    return [{
      type: ElementRef
    }, {
      type: NgZone
    }, {
      type: DxTemplateHost
    }, {
      type: WatcherHelper
    }, {
      type: IterableDifferHelper
    }, {
      type: NestedOptionHost
    }, {
      type: TransferState
    }, {
      type: void 0,
      decorators: [{
        type: Inject,
        args: [PLATFORM_ID]
      }]
    }];
  }, {
    accessKey: [{
      type: Input
    }],
    activeStateEnabled: [{
      type: Input
    }],
    allowItemDeleting: [{
      type: Input
    }],
    bounceEnabled: [{
      type: Input
    }],
    collapsibleGroups: [{
      type: Input
    }],
    dataSource: [{
      type: Input
    }],
    disabled: [{
      type: Input
    }],
    displayExpr: [{
      type: Input
    }],
    elementAttr: [{
      type: Input
    }],
    focusStateEnabled: [{
      type: Input
    }],
    grouped: [{
      type: Input
    }],
    groupTemplate: [{
      type: Input
    }],
    height: [{
      type: Input
    }],
    hint: [{
      type: Input
    }],
    hoverStateEnabled: [{
      type: Input
    }],
    indicateLoading: [{
      type: Input
    }],
    itemDeleteMode: [{
      type: Input
    }],
    itemDragging: [{
      type: Input
    }],
    itemHoldTimeout: [{
      type: Input
    }],
    items: [{
      type: Input
    }],
    itemTemplate: [{
      type: Input
    }],
    keyExpr: [{
      type: Input
    }],
    menuItems: [{
      type: Input
    }],
    menuMode: [{
      type: Input
    }],
    nextButtonText: [{
      type: Input
    }],
    noDataText: [{
      type: Input
    }],
    pageLoadingText: [{
      type: Input
    }],
    pageLoadMode: [{
      type: Input
    }],
    pulledDownText: [{
      type: Input
    }],
    pullingDownText: [{
      type: Input
    }],
    pullRefreshEnabled: [{
      type: Input
    }],
    refreshingText: [{
      type: Input
    }],
    repaintChangesOnly: [{
      type: Input
    }],
    rtlEnabled: [{
      type: Input
    }],
    scrollByContent: [{
      type: Input
    }],
    scrollByThumb: [{
      type: Input
    }],
    scrollingEnabled: [{
      type: Input
    }],
    searchEditorOptions: [{
      type: Input
    }],
    searchEnabled: [{
      type: Input
    }],
    searchExpr: [{
      type: Input
    }],
    searchMode: [{
      type: Input
    }],
    searchTimeout: [{
      type: Input
    }],
    searchValue: [{
      type: Input
    }],
    selectAllMode: [{
      type: Input
    }],
    selectAllText: [{
      type: Input
    }],
    selectByClick: [{
      type: Input
    }],
    selectedItemKeys: [{
      type: Input
    }],
    selectedItems: [{
      type: Input
    }],
    selectionMode: [{
      type: Input
    }],
    showScrollbar: [{
      type: Input
    }],
    showSelectionControls: [{
      type: Input
    }],
    tabIndex: [{
      type: Input
    }],
    useNativeScrolling: [{
      type: Input
    }],
    visible: [{
      type: Input
    }],
    width: [{
      type: Input
    }],
    onContentReady: [{
      type: Output
    }],
    onDisposing: [{
      type: Output
    }],
    onGroupRendered: [{
      type: Output
    }],
    onInitialized: [{
      type: Output
    }],
    onItemClick: [{
      type: Output
    }],
    onItemContextMenu: [{
      type: Output
    }],
    onItemDeleted: [{
      type: Output
    }],
    onItemDeleting: [{
      type: Output
    }],
    onItemHold: [{
      type: Output
    }],
    onItemRendered: [{
      type: Output
    }],
    onItemReordered: [{
      type: Output
    }],
    onItemSwipe: [{
      type: Output
    }],
    onOptionChanged: [{
      type: Output
    }],
    onPageLoading: [{
      type: Output
    }],
    onPullRefresh: [{
      type: Output
    }],
    onScroll: [{
      type: Output
    }],
    onSelectAllValueChanged: [{
      type: Output
    }],
    onSelectionChanged: [{
      type: Output
    }],
    accessKeyChange: [{
      type: Output
    }],
    activeStateEnabledChange: [{
      type: Output
    }],
    allowItemDeletingChange: [{
      type: Output
    }],
    bounceEnabledChange: [{
      type: Output
    }],
    collapsibleGroupsChange: [{
      type: Output
    }],
    dataSourceChange: [{
      type: Output
    }],
    disabledChange: [{
      type: Output
    }],
    displayExprChange: [{
      type: Output
    }],
    elementAttrChange: [{
      type: Output
    }],
    focusStateEnabledChange: [{
      type: Output
    }],
    groupedChange: [{
      type: Output
    }],
    groupTemplateChange: [{
      type: Output
    }],
    heightChange: [{
      type: Output
    }],
    hintChange: [{
      type: Output
    }],
    hoverStateEnabledChange: [{
      type: Output
    }],
    indicateLoadingChange: [{
      type: Output
    }],
    itemDeleteModeChange: [{
      type: Output
    }],
    itemDraggingChange: [{
      type: Output
    }],
    itemHoldTimeoutChange: [{
      type: Output
    }],
    itemsChange: [{
      type: Output
    }],
    itemTemplateChange: [{
      type: Output
    }],
    keyExprChange: [{
      type: Output
    }],
    menuItemsChange: [{
      type: Output
    }],
    menuModeChange: [{
      type: Output
    }],
    nextButtonTextChange: [{
      type: Output
    }],
    noDataTextChange: [{
      type: Output
    }],
    pageLoadingTextChange: [{
      type: Output
    }],
    pageLoadModeChange: [{
      type: Output
    }],
    pulledDownTextChange: [{
      type: Output
    }],
    pullingDownTextChange: [{
      type: Output
    }],
    pullRefreshEnabledChange: [{
      type: Output
    }],
    refreshingTextChange: [{
      type: Output
    }],
    repaintChangesOnlyChange: [{
      type: Output
    }],
    rtlEnabledChange: [{
      type: Output
    }],
    scrollByContentChange: [{
      type: Output
    }],
    scrollByThumbChange: [{
      type: Output
    }],
    scrollingEnabledChange: [{
      type: Output
    }],
    searchEditorOptionsChange: [{
      type: Output
    }],
    searchEnabledChange: [{
      type: Output
    }],
    searchExprChange: [{
      type: Output
    }],
    searchModeChange: [{
      type: Output
    }],
    searchTimeoutChange: [{
      type: Output
    }],
    searchValueChange: [{
      type: Output
    }],
    selectAllModeChange: [{
      type: Output
    }],
    selectAllTextChange: [{
      type: Output
    }],
    selectByClickChange: [{
      type: Output
    }],
    selectedItemKeysChange: [{
      type: Output
    }],
    selectedItemsChange: [{
      type: Output
    }],
    selectionModeChange: [{
      type: Output
    }],
    showScrollbarChange: [{
      type: Output
    }],
    showSelectionControlsChange: [{
      type: Output
    }],
    tabIndexChange: [{
      type: Output
    }],
    useNativeScrollingChange: [{
      type: Output
    }],
    visibleChange: [{
      type: Output
    }],
    widthChange: [{
      type: Output
    }],
    itemsChildren: [{
      type: ContentChildren,
      args: [DxiItemComponent]
    }],
    menuItemsChildren: [{
      type: ContentChildren,
      args: [DxiMenuItemComponent]
    }]
  });
})();
var DxListModule = class _DxListModule {
  /** @nocollapse */
  static ɵfac = function DxListModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _DxListModule)();
  };
  /** @nocollapse */
  static ɵmod = ɵɵdefineNgModule({
    type: _DxListModule,
    declarations: [DxListComponent],
    imports: [DxoItemDraggingModule, DxoCursorOffsetModule, DxiItemModule, DxiMenuItemModule, DxoSearchEditorOptionsModule, DxiButtonModule, DxoOptionsModule, DxIntegrationModule, DxTemplateModule],
    exports: [DxListComponent, DxoItemDraggingModule, DxoCursorOffsetModule, DxiItemModule, DxiMenuItemModule, DxoSearchEditorOptionsModule, DxiButtonModule, DxoOptionsModule, DxTemplateModule]
  });
  /** @nocollapse */
  static ɵinj = ɵɵdefineInjector({
    imports: [DxoItemDraggingModule, DxoCursorOffsetModule, DxiItemModule, DxiMenuItemModule, DxoSearchEditorOptionsModule, DxiButtonModule, DxoOptionsModule, DxIntegrationModule, DxTemplateModule, DxoItemDraggingModule, DxoCursorOffsetModule, DxiItemModule, DxiMenuItemModule, DxoSearchEditorOptionsModule, DxiButtonModule, DxoOptionsModule, DxTemplateModule]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DxListModule, [{
    type: NgModule,
    args: [{
      imports: [DxoItemDraggingModule, DxoCursorOffsetModule, DxiItemModule, DxiMenuItemModule, DxoSearchEditorOptionsModule, DxiButtonModule, DxoOptionsModule, DxIntegrationModule, DxTemplateModule],
      declarations: [DxListComponent],
      exports: [DxListComponent, DxoItemDraggingModule, DxoCursorOffsetModule, DxiItemModule, DxiMenuItemModule, DxoSearchEditorOptionsModule, DxiButtonModule, DxoOptionsModule, DxTemplateModule]
    }]
  }], null, null);
})();

export {
  PopoverPositionController,
  ui_popover_default,
  action_sheet_default,
  m_draggable_default,
  sortable_default,
  DxListComponent,
  DxListModule
};
/*! Bundled license information:

devextreme-angular/fesm2022/devextreme-angular-ui-list.mjs:
  (*!
   * devextreme-angular
   * Version: 24.1.4
   * Build date: Mon Jul 15 2024
   *
   * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
   *
   * This software may be modified and distributed under the terms
   * of the MIT license. See the LICENSE file in the root of the project for details.
   *
   * https://github.com/DevExpress/devextreme-angular
   *)
*/
//# sourceMappingURL=chunk-T7VSN2CD.js.map
