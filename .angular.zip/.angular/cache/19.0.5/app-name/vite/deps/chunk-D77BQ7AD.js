import {
  ui_collection_widget_edit_default
} from "./chunk-VOSGCXDL.js";
import {
  ui_widget_default
} from "./chunk-ZEY4S4J4.js";

// node_modules/devextreme/esm/__internal/ui/widget.js
var TypedWidget = ui_widget_default;
var widget_default = TypedWidget;

// node_modules/devextreme/esm/__internal/ui/collection/edit.js
var TypedCollectionWidget = ui_collection_widget_edit_default;
var edit_default = TypedCollectionWidget;

export {
  widget_default,
  edit_default
};
//# sourceMappingURL=chunk-D77BQ7AD.js.map
