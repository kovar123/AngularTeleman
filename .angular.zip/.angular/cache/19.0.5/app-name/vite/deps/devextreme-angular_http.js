import {
  HttpClient,
  HttpClientModule,
  HttpEventType,
  HttpParams
} from "./chunk-SYXCTEUS.js";
import {
  ajax_default,
  evalCrossDomainScript,
  evalScript,
  getAcceptHeader,
  getJsonpOptions,
  getMethod,
  getRequestHeaders,
  getRequestOptions,
  isCrossDomain
} from "./chunk-W35F6NCE.js";
import {
  Deferred,
  getWindow
} from "./chunk-4BRW6FUL.js";
import {
  isDefined
} from "./chunk-UTUFIS2B.js";
import "./chunk-FIIAYBZC.js";
import {
  NgModule,
  Subject,
  setClassMetadata,
  takeUntil,
  throwError,
  timeoutWith,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵinject
} from "./chunk-5YDKINUH.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-N6ESDQJH.js";

// node_modules/devextreme-angular/fesm2022/devextreme-angular-http.mjs
var PARSER_ERROR = "parsererror";
var SUCCESS = "success";
var ERROR = "error";
var NO_CONTENT = "nocontent";
var TIMEOUT = "timeout";
var STATUS_ABORT = 0;
var CONTENT_TYPE = "Content-Type";
var URLENCODED = "application/x-www-form-urlencoded";
function assignResponseProps(xhrSurrogate, response) {
  const getResponseHeader = (name) => response.headers.get(name);
  function makeResponseText() {
    const body = "error" in response ? response.error : response.body;
    if (typeof body !== "string" || String(getResponseHeader(CONTENT_TYPE)).startsWith("application/json")) {
      return JSON.stringify(body);
    }
    return body;
  }
  Object.assign(xhrSurrogate, {
    status: response.status,
    statusText: response.statusText,
    getResponseHeader,
    responseText: makeResponseText()
  });
  return xhrSurrogate;
}
function isGetMethod(options) {
  return getMethod(options) === "GET";
}
function isCacheNeed(options) {
  if (options.cache === void 0) {
    return !(isUsedScript(options) || isUsedJSONP(options));
  }
  return options.cache;
}
function isUsedScript(options) {
  return options.dataType === "script";
}
function isUsedJSONP(options) {
  return options.dataType === "jsonp";
}
function getRequestHeaders2(options) {
  const headers = getRequestHeaders(options);
  const {
    upload
  } = options;
  if (!headers.Accept) {
    headers.Accept = getAcceptHeader(options);
  }
  if (!upload && !isGetMethod(options) && !headers[CONTENT_TYPE]) {
    headers[CONTENT_TYPE] = options.contentType || `${URLENCODED};charset=utf-8`;
  }
  return Object.keys(headers).reduce((acc, key) => {
    if (isDefined(headers[key])) {
      acc[key] = headers[key];
    }
    return acc;
  }, {});
}
function rejectIfAborted(deferred, xhrSurrogate, callback) {
  if (xhrSurrogate.aborted) {
    deferred.reject({
      status: STATUS_ABORT,
      statusText: "aborted",
      ok: false
    });
    callback?.();
  }
}
function getJsonpParameters(options) {
  const patchedOptions = __spreadValues({}, options);
  const callbackName = getJsonpOptions(patchedOptions);
  return {
    callbackName,
    data: patchedOptions.data
  };
}
function addJsonpCallback(callbackName, deferred, xhrSurrogate) {
  getWindow()[callbackName] = (data) => deferred.resolve(data, SUCCESS, xhrSurrogate);
}
function sendRequestByScript(url, deferred, xhrSurrogate) {
  evalCrossDomainScript(url).then(() => deferred.resolve(null, SUCCESS, xhrSurrogate), () => deferred.reject(xhrSurrogate, ERROR));
}
function getRequestCallbacks(options, deferred, xhrSurrogate) {
  return {
    next(response) {
      if (isUsedJSONP(options)) {
        return options.crossDomain ? deferred.resolve(response, "success", assignResponseProps(xhrSurrogate, response)) : evalScript(response.body);
      }
      if (isUsedScript(options)) {
        evalScript(response.body);
      }
      return deferred.resolve(response.body, response.body ? "success" : NO_CONTENT, assignResponseProps(xhrSurrogate, response));
    },
    error(error) {
      error = error && typeof error === "object" ? error : {
        error
      };
      let errorStatus = error?.statusText === TIMEOUT ? TIMEOUT : "error";
      errorStatus = options.dataType === "json" && error?.message?.includes?.("parsing") ? PARSER_ERROR : errorStatus;
      return deferred.reject(assignResponseProps(xhrSurrogate, __spreadValues({
        status: 400
      }, error)), errorStatus, error);
    },
    complete() {
      rejectIfAborted(deferred, xhrSurrogate);
    }
  };
}
function getUploadCallbacks(options, deferred, xhrSurrogate) {
  let total = 0;
  let isUploadStarted = false;
  return {
    next: (event) => {
      if (!isUploadStarted && [HttpEventType.UploadProgress, HttpEventType.Sent].includes(event.type)) {
        options.upload.onloadstart?.(event);
        isUploadStarted = true;
      }
      if (event.type === HttpEventType.UploadProgress) {
        total += event.loaded;
        options.upload.onprogress?.(__spreadProps(__spreadValues({}, event), {
          total
        }));
      } else if (event.type === HttpEventType.Response) {
        return deferred.resolve(xhrSurrogate, SUCCESS);
      }
      return null;
    },
    error(error) {
      error = error && typeof error === "object" ? error : {
        error
      };
      return deferred.reject(assignResponseProps(xhrSurrogate, __spreadValues({
        status: 400
      }, error)), error.status, error);
    },
    complete() {
      rejectIfAborted(deferred, xhrSurrogate, () => {
        options.upload?.onabort?.(xhrSurrogate);
      });
    }
  };
}
var sendRequestFactory = (httpClient) => (options) => {
  const abort$ = new Subject();
  const deferred = Deferred();
  const result = deferred.promise();
  const isGet = isGetMethod(options);
  const isJSONP = isUsedJSONP(options);
  const isScript = isUsedScript(options);
  options.crossDomain = isCrossDomain(options.url);
  options.cache = isCacheNeed(options);
  const headers = getRequestHeaders2(options);
  const xhrSurrogate = {
    type: "XMLHttpRequestSurrogate",
    aborted: false,
    abort() {
      this.aborted = true;
      abort$.next();
    }
  };
  result.abort = () => xhrSurrogate.abort();
  if (!options.crossDomain && isJSONP) {
    const {
      callbackName,
      data: data2
    } = getJsonpParameters(options);
    options.data = __spreadValues(__spreadValues({}, options.data), data2);
    addJsonpCallback(callbackName, deferred, xhrSurrogate);
  }
  const {
    url,
    parameters: data
  } = getRequestOptions(options, headers);
  const {
    upload,
    beforeSend,
    xhrFields
  } = options;
  beforeSend?.(xhrSurrogate);
  if (options.crossDomain && isScript && !xhrSurrogate.aborted) {
    sendRequestByScript(url, deferred, xhrSurrogate);
    return result;
  }
  if (options.cache === false && isGet && data) {
    data._ = Date.now() + 1;
  }
  const makeBody = () => !upload && typeof data === "object" && headers[CONTENT_TYPE].indexOf(URLENCODED) === 0 ? Object.keys(data).reduce((httpParams, key) => httpParams.set(key, data[key]), new HttpParams()).toString() : data;
  const body = isGet ? void 0 : makeBody();
  const params = isGet ? data : void 0;
  const request = options.crossDomain && isJSONP ? httpClient.jsonp(url, options.jsonp || "callback") : httpClient.request(getMethod(options), url, {
    params,
    body,
    headers,
    reportProgress: true,
    withCredentials: xhrFields?.withCredentials,
    observe: upload ? "events" : "response",
    responseType: options.responseType || (isScript || isJSONP ? "text" : options.dataType)
  });
  const subscriptionCallbacks = upload ? getUploadCallbacks : getRequestCallbacks;
  request.pipe.apply(request, [takeUntil(abort$), ...options.timeout ? [timeoutWith(options.timeout, throwError({
    statusText: TIMEOUT,
    status: 0,
    ok: false
  }))] : []]).subscribe(subscriptionCallbacks(options, deferred, xhrSurrogate));
  return result;
};
var DxHttpModule = class _DxHttpModule {
  constructor(httpClient) {
    ajax_default.inject({
      sendRequest: sendRequestFactory(httpClient)
    });
  }
  /** @nocollapse */
  static ɵfac = function DxHttpModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _DxHttpModule)(ɵɵinject(HttpClient));
  };
  /** @nocollapse */
  static ɵmod = ɵɵdefineNgModule({
    type: _DxHttpModule,
    imports: [HttpClientModule]
  });
  /** @nocollapse */
  static ɵinj = ɵɵdefineInjector({
    imports: [HttpClientModule]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DxHttpModule, [{
    type: NgModule,
    args: [{
      exports: [],
      imports: [HttpClientModule],
      providers: []
    }]
  }], function() {
    return [{
      type: HttpClient
    }];
  }, null);
})();
export {
  DxHttpModule
};
/*! Bundled license information:

devextreme-angular/fesm2022/devextreme-angular-http.mjs:
  (*!
   * devextreme-angular
   * Version: 24.1.4
   * Build date: Mon Jul 15 2024
   *
   * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
   *
   * This software may be modified and distributed under the terms
   * of the MIT license. See the LICENSE file in the root of the project for details.
   *
   * https://github.com/DevExpress/devextreme-angular
   *)
*/
//# sourceMappingURL=devextreme-angular_http.js.map
