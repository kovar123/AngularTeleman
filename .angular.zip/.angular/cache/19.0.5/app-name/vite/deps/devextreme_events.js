import {
  Event,
  off,
  on,
  one,
  trigger,
  triggerHandler
} from "./chunk-IRP4I5CC.js";
import "./chunk-RC2BNL3X.js";
import "./chunk-4BRW6FUL.js";
import "./chunk-UTUFIS2B.js";
import "./chunk-N6ESDQJH.js";
export {
  Event,
  off,
  on,
  one,
  trigger,
  triggerHandler
};
//# sourceMappingURL=devextreme_events.js.map
