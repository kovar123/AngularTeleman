import {
  m_scrollable_default
} from "./chunk-CYLWHOEL.js";

// node_modules/devextreme/esm/ui/scroll_view/ui.scrollable.js
var ui_scrollable_default = m_scrollable_default;

export {
  ui_scrollable_default
};
//# sourceMappingURL=chunk-3HM2JABP.js.map
