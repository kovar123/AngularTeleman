import {
  BaseNestedOption,
  CollectionNestedOption,
  CollectionNestedOptionContainerImpl,
  DX_TEMPLATE_WRAPPER_CLASS,
  DxComponent,
  DxComponentExtension,
  DxIntegrationModule,
  DxServerTransferStateModule,
  DxTemplateDirective,
  DxTemplateHost,
  DxTemplateModule,
  EmitterHelper,
  IterableDifferHelper,
  NestedOption,
  NestedOptionHost,
  NgEventsStrategy,
  RenderData,
  WatcherHelper,
  extractTemplate,
  getElement,
  getServerStateKey
} from "./chunk-7YZ53GCH.js";
import "./chunk-IRP4I5CC.js";
import "./chunk-MU4Z4OEA.js";
import "./chunk-RC2BNL3X.js";
import "./chunk-W35F6NCE.js";
import "./chunk-4BRW6FUL.js";
import "./chunk-UTUFIS2B.js";
import "./chunk-FIIAYBZC.js";
import "./chunk-5YDKINUH.js";
import "./chunk-N6ESDQJH.js";
export {
  BaseNestedOption,
  CollectionNestedOption,
  CollectionNestedOptionContainerImpl,
  DX_TEMPLATE_WRAPPER_CLASS,
  DxComponent,
  DxComponentExtension,
  DxIntegrationModule,
  DxServerTransferStateModule,
  DxTemplateDirective,
  DxTemplateHost,
  DxTemplateModule,
  EmitterHelper,
  IterableDifferHelper,
  NestedOption,
  NestedOptionHost,
  NgEventsStrategy,
  RenderData,
  WatcherHelper,
  extractTemplate,
  getElement,
  getServerStateKey
};
//# sourceMappingURL=devextreme-angular_core.js.map
