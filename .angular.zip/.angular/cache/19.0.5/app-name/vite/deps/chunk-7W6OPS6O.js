import {
  editor_default,
  validation_message_default
} from "./chunk-HIIKPTPP.js";
import {
  BaseInfernoComponent,
  BaseWidgetProps,
  ConfigContext,
  InfernoComponent,
  InfernoEffect,
  InfernoWrapperComponent,
  Widget,
  WidgetProps,
  combineClasses,
  component_default,
  createComponentVNode,
  createFragment,
  createReRenderEffect,
  createRef,
  createVNode,
  hasTemplate,
  normalizeProps,
  normalizeStyles,
  renderTemplate,
  validation_engine_default
} from "./chunk-SXMMF6QJ.js";
import {
  _objectWithoutPropertiesLoose,
  component_registrator_default,
  convertRulesToOptions
} from "./chunk-MM4NENTZ.js";
import {
  devices_default
} from "./chunk-76GCZVPW.js";
import {
  data,
  normalizeStyleProp,
  renderer_default
} from "./chunk-MU4Z4OEA.js";
import {
  _extends,
  callbacks_default,
  guid_default
} from "./chunk-4BRW6FUL.js";
import {
  extend,
  isDefined,
  isPlainObject,
  type
} from "./chunk-UTUFIS2B.js";

// node_modules/devextreme/esm/renovation/utils/dom.js
function querySelectorInSameDocument(el, selector) {
  var _el$getRootNode;
  const root = (null === (_el$getRootNode = el.getRootNode) || void 0 === _el$getRootNode ? void 0 : _el$getRootNode.call(el)) ?? document;
  return root.querySelector(selector);
}

// node_modules/devextreme/esm/renovation/component_wrapper/editors/editor.js
var INVALID_MESSAGE_AUTO = "dx-invalid-message-auto";
var VALIDATION_TARGET = "dx-validation-target";
var Editor = class extends component_default {
  getProps() {
    const props = super.getProps();
    props.onFocusIn = () => {
      const isValidationMessageShownOnFocus = "auto" === this.option("validationMessageMode");
      if (isValidationMessageShownOnFocus) {
        const $validationMessageWrapper = renderer_default(querySelectorInSameDocument(this.element(), ".dx-invalid-message.dx-overlay-wrapper"));
        null === $validationMessageWrapper || void 0 === $validationMessageWrapper || $validationMessageWrapper.removeClass(INVALID_MESSAGE_AUTO);
        const timeToWaitBeforeShow = 150;
        if (this.showValidationMessageTimeout) {
          clearTimeout(this.showValidationMessageTimeout);
        }
        this.showValidationMessageTimeout = setTimeout(() => {
          null === $validationMessageWrapper || void 0 === $validationMessageWrapper || $validationMessageWrapper.addClass(INVALID_MESSAGE_AUTO);
        }, timeToWaitBeforeShow);
      }
    };
    props.saveValueChangeEvent = (e) => {
      this._valueChangeEventInstance = e;
    };
    return props;
  }
  _createElement(element) {
    super._createElement(element);
    this.showValidationMessageTimeout = void 0;
    this.validationRequest = callbacks_default();
    data(this.$element()[0], VALIDATION_TARGET, this);
  }
  _render() {
    var _this$option;
    null === (_this$option = this.option("_onMarkupRendered")) || void 0 === _this$option || _this$option();
  }
  _init() {
    super._init();
    this._initialValue = this.option("value");
  }
  _initializeComponent() {
    super._initializeComponent();
    this._valueChangeAction = this._createActionByOption("onValueChanged", {
      excludeValidators: ["disabled", "readOnly"]
    });
  }
  _initOptions(options) {
    super._initOptions(options);
    this.option(validation_engine_default.initValidationOptions(options));
  }
  _getDefaultOptions() {
    return extend(super._getDefaultOptions(), {
      validationMessageOffset: {
        h: 0,
        v: 0
      },
      validationTooltipOptions: {}
    });
  }
  _bindInnerWidgetOptions(innerWidget, optionsContainer) {
    const innerWidgetOptions = extend({}, innerWidget.option());
    const syncOptions = () => this._silent(optionsContainer, innerWidgetOptions);
    syncOptions();
    innerWidget.on("optionChanged", syncOptions);
  }
  _raiseValidation(value, previousValue) {
    const areValuesEmpty = !isDefined(value) && !isDefined(previousValue);
    if (value !== previousValue && !areValuesEmpty) {
      this.validationRequest.fire({
        value,
        editor: this
      });
    }
  }
  _raiseValueChangeAction(value, previousValue) {
    var _this$_valueChangeAct;
    null === (_this$_valueChangeAct = this._valueChangeAction) || void 0 === _this$_valueChangeAct || _this$_valueChangeAct.call(this, {
      element: this.$element(),
      previousValue,
      value,
      event: this._valueChangeEventInstance
    });
    this._valueChangeEventInstance = void 0;
  }
  _optionChanged(option) {
    const {
      name,
      previousValue,
      value
    } = option;
    if (name && void 0 !== this._getActionConfigs()[name]) {
      this._addAction(name);
    }
    switch (name) {
      case "value":
        this._raiseValidation(value, previousValue);
        this.option("isDirty", this._initialValue !== value);
        this._raiseValueChangeAction(value, previousValue);
        break;
      case "onValueChanged":
        this._valueChangeAction = this._createActionByOption("onValueChanged", {
          excludeValidators: ["disabled", "readOnly"]
        });
        break;
      case "isValid":
      case "validationError":
      case "validationErrors":
      case "validationStatus":
        this.option(validation_engine_default.synchronizeValidationOptions(option, this.option()));
    }
    super._optionChanged(option);
  }
  clear() {
    const {
      value
    } = this._getDefaultOptions();
    this.option({
      value
    });
  }
  reset() {
    let value = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : void 0;
    if (arguments.length) {
      this._initialValue = value;
    }
    this.option("value", this._initialValue);
    this.option("isDirty", false);
    this.option("isValid", true);
  }
  _dispose() {
    super._dispose();
    data(this.element(), VALIDATION_TARGET, null);
    if (this.showValidationMessageTimeout) {
      clearTimeout(this.showValidationMessageTimeout);
    }
  }
};
var prevIsEditor = editor_default.isEditor;
var newIsEditor = (instance) => prevIsEditor(instance) || instance instanceof Editor;
Editor.isEditor = newIsEditor;
editor_default.isEditor = newIsEditor;

// node_modules/devextreme/esm/renovation/component_wrapper/editors/check_box.js
var CheckBox = class extends Editor {
  _useTemplates() {
    return false;
  }
  _isFocused() {
    const focusTarget = this.$element()[0];
    return focusTarget.classList.contains("dx-state-focused");
  }
  getSupportedKeyNames() {
    return ["space"];
  }
  getProps() {
    const props = super.getProps();
    if (null !== props.value) {
      props.value = Boolean(props.value);
    }
    return props;
  }
};

// node_modules/devextreme/esm/renovation/ui/common/utils/get_updated_options.js
var defaultNotDeepCopyArrays = ["dataSource", "selectedRowKeys"];
var propsToIgnore = {
  integrationOptions: true
};
function getDiffItem(key, value, previousValue) {
  return {
    path: key,
    value,
    previousValue
  };
}
function compare(resultPaths, item1, item2, key, fullPropName, notDeepCopyArrays) {
  if (propsToIgnore[key]) {
    return;
  }
  const type1 = type(item1);
  const type2 = type(item2);
  if (item1 === item2) {
    return;
  }
  if (type1 !== type2) {
    resultPaths.push(getDiffItem(key, item2, item1));
  } else if ("object" === type1) {
    if (!isPlainObject(item2)) {
      resultPaths.push(getDiffItem(key, item2, item1));
    } else {
      const diffPaths = objectDiffs(item1, item2, fullPropName, notDeepCopyArrays);
      resultPaths.push(...diffPaths.map((item) => _extends({}, item, {
        path: `${key}.${item.path}`
      })));
    }
  } else if ("array" === type1) {
    const notDeepCopy = notDeepCopyArrays.some((prop) => fullPropName.includes(prop));
    if (notDeepCopy && item1 !== item2) {
      resultPaths.push(getDiffItem(key, item2, item1));
    } else if (item1.length !== item2.length) {
      resultPaths.push(getDiffItem(key, item2, item1));
    } else {
      const diffPaths = objectDiffs(item1, item2, fullPropName, notDeepCopyArrays);
      [].push.apply(resultPaths, diffPaths.map((item) => _extends({}, item, {
        path: `${key}${item.path}`
      })));
    }
  } else {
    resultPaths.push(getDiffItem(key, item2, item1));
  }
}
var objectDiffsFiltered = (propsEnumerator) => (oldProps, props, fullPropName, notDeepCopyArrays) => {
  const resultPaths = [];
  const processItem = !Array.isArray(oldProps) ? (propName) => {
    compare(resultPaths, oldProps[propName], props[propName], propName, `${fullPropName}.${propName}`, notDeepCopyArrays);
  } : (propName) => {
    compare(resultPaths, oldProps[propName], props[propName], `[${propName}]`, `${fullPropName}.${propName}`, notDeepCopyArrays);
  };
  propsEnumerator(oldProps).forEach(processItem);
  Object.keys(props).filter((propName) => !Object.prototype.hasOwnProperty.call(oldProps, propName) && oldProps[propName] !== props[propName]).forEach((propName) => {
    resultPaths.push({
      path: propName,
      value: props[propName],
      previousValue: oldProps[propName]
    });
  });
  return resultPaths;
};
var objectDiffs = objectDiffsFiltered((oldProps) => Object.keys(oldProps));
var reactProps = {
  key: true,
  ref: true,
  children: true,
  style: true
};
var objectDiffsWithoutReactProps = objectDiffsFiltered((prop) => Object.keys(prop).filter((p) => !reactProps[p]));
function getUpdatedOptions(oldProps, props) {
  let notDeepCopyArrays = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : defaultNotDeepCopyArrays;
  return objectDiffsWithoutReactProps(oldProps, props, "", notDeepCopyArrays);
}

// node_modules/devextreme/esm/renovation/ui/common/dom_component_wrapper.js
var _excluded = ["valueChange"];
var _excluded2 = ["componentProps", "componentType", "templateNames"];
var normalizeProps2 = (props) => Object.keys(props).reduce((accumulator, key) => {
  if (void 0 !== props[key]) {
    accumulator[key] = props[key];
  }
  return accumulator;
}, {});
var viewFunction = (_ref) => {
  let {
    props: {
      componentProps: {
        className
      }
    },
    restAttributes,
    widgetRef
  } = _ref;
  return normalizeProps2(createVNode(1, "div", className, null, 1, _extends({}, restAttributes), null, widgetRef));
};
var DomComponentWrapperProps = {};
var DomComponentWrapper = class extends InfernoComponent {
  get config() {
    if (this.context[ConfigContext.id]) {
      return this.context[ConfigContext.id];
    }
    return ConfigContext.defaultValue;
  }
  constructor(props) {
    super(props);
    this.state = {};
    this.widgetRef = createRef();
    this.getInstance = this.getInstance.bind(this);
    this.setupWidget = this.setupWidget.bind(this);
    this.updateWidget = this.updateWidget.bind(this);
  }
  createEffects() {
    return [new InfernoEffect(this.setupWidget, []), new InfernoEffect(this.updateWidget, [this.props.componentProps, this.config, this.props.templateNames])];
  }
  updateEffects() {
    var _this$_effects$;
    null === (_this$_effects$ = this._effects[1]) || void 0 === _this$_effects$ || _this$_effects$.update([this.props.componentProps, this.config, this.props.templateNames]);
  }
  setupWidget() {
    const componentInstance = new this.props.componentType(this.widgetRef.current, this.properties);
    this.instance = componentInstance;
    return () => {
      componentInstance.dispose();
      this.instance = null;
    };
  }
  updateWidget() {
    const instance = this.getInstance();
    if (!instance) {
      return;
    }
    const updatedOptions = getUpdatedOptions(this.prevProps || {}, this.properties);
    if (updatedOptions.length) {
      instance.beginUpdate();
      updatedOptions.forEach((_ref2) => {
        let {
          path,
          value
        } = _ref2;
        instance.option(path, value);
      });
      instance.endUpdate();
    }
    this.prevProps = this.properties;
  }
  get properties() {
    var _this$config;
    const normalizedProps = normalizeProps2(this.props.componentProps);
    const {
      valueChange
    } = normalizedProps, restProps = _objectWithoutPropertiesLoose(normalizedProps, _excluded);
    const properties = _extends({
      rtlEnabled: !!(null !== (_this$config = this.config) && void 0 !== _this$config && _this$config.rtlEnabled),
      isRenovated: true
    }, restProps);
    if (valueChange) {
      properties.onValueChanged = (_ref3) => {
        let {
          value
        } = _ref3;
        return valueChange(value);
      };
    }
    const templates = this.props.templateNames;
    templates.forEach((name) => {
      if (hasTemplate(name, properties, this)) {
        properties[name] = (item, index, container) => {
          renderTemplate(this.props.componentProps[name], {
            item,
            index,
            container
          }, this);
        };
      }
    });
    return properties;
  }
  get restAttributes() {
    const _this$props = this.props, restProps = _objectWithoutPropertiesLoose(_this$props, _excluded2);
    return restProps;
  }
  getInstance() {
    return this.instance;
  }
  render() {
    const props = this.props;
    return viewFunction({
      props: _extends({}, props),
      widgetRef: this.widgetRef,
      config: this.config,
      properties: this.properties,
      restAttributes: this.restAttributes
    });
  }
};
DomComponentWrapper.defaultProps = DomComponentWrapperProps;

// node_modules/devextreme/esm/renovation/ui/overlays/validation_message.js
var _excluded3 = ["accessKey", "activeStateEnabled", "boundary", "className", "contentId", "disabled", "focusStateEnabled", "height", "hint", "hoverStateEnabled", "mode", "offset", "onClick", "onKeyDown", "positionSide", "rtlEnabled", "tabIndex", "target", "validationErrors", "visible", "visualContainer", "width"];
var viewFunction2 = (_ref) => {
  let {
    componentProps,
    restAttributes
  } = _ref;
  return normalizeProps(createComponentVNode(2, DomComponentWrapper, _extends({
    componentType: validation_message_default,
    componentProps,
    templateNames: []
  }, restAttributes)));
};
var ValidationMessageProps = Object.create(Object.prototype, Object.assign(Object.getOwnPropertyDescriptors(BaseWidgetProps), Object.getOwnPropertyDescriptors({
  mode: "auto",
  positionSide: "top",
  offset: Object.freeze({
    h: 0,
    v: 0
  }),
  isReactComponentWrapper: true
})));
var ValidationMessage = class extends BaseInfernoComponent {
  constructor(props) {
    super(props);
    this.state = {};
  }
  get componentProps() {
    return this.props;
  }
  get restAttributes() {
    const _this$props = this.props, restProps = _objectWithoutPropertiesLoose(_this$props, _excluded3);
    return restProps;
  }
  render() {
    const props = this.props;
    return viewFunction2({
      props: _extends({}, props),
      componentProps: this.componentProps,
      restAttributes: this.restAttributes
    });
  }
};
ValidationMessage.defaultProps = ValidationMessageProps;

// node_modules/devextreme/esm/renovation/ui/editors/common/editor.js
var _excluded4 = ["accessKey", "activeStateEnabled", "aria", "children", "className", "classes", "defaultValue", "disabled", "focusStateEnabled", "height", "hint", "hoverStateEnabled", "inputAttr", "isDirty", "isValid", "name", "onClick", "onFocusIn", "onKeyDown", "readOnly", "rtlEnabled", "tabIndex", "validationError", "validationErrors", "validationMessageMode", "validationMessagePosition", "validationStatus", "value", "valueChange", "visible", "width"];
var getCssClasses = (model) => {
  const {
    classes,
    isValid,
    readOnly
  } = model;
  const classesMap = {
    "dx-state-readonly": !!readOnly,
    "dx-invalid": !isValid,
    [String(classes)]: !!classes
  };
  return combineClasses(classesMap);
};
var viewFunction3 = (viewModel) => {
  const {
    aria,
    cssClasses: classes,
    isValidationMessageVisible,
    onFocusIn,
    props: {
      accessKey,
      activeStateEnabled,
      children,
      className,
      disabled,
      focusStateEnabled,
      height,
      hint,
      hoverStateEnabled,
      onClick,
      onKeyDown,
      rtlEnabled,
      tabIndex,
      validationMessageMode,
      validationMessagePosition,
      visible,
      width
    },
    restAttributes,
    rootElementRef,
    validationErrors,
    validationMessageGuid,
    validationMessageTarget,
    widgetRef
  } = viewModel;
  return normalizeProps(createComponentVNode(2, Widget, _extends({
    rootElementRef,
    aria,
    classes,
    activeStateEnabled,
    focusStateEnabled,
    hoverStateEnabled,
    accessKey,
    className,
    rtlEnabled,
    hint,
    disabled,
    height,
    width,
    onFocusIn,
    onClick,
    onKeyDown,
    tabIndex,
    visible
  }, restAttributes, {
    children: createFragment([children, isValidationMessageVisible && createComponentVNode(2, ValidationMessage, {
      validationErrors,
      mode: validationMessageMode,
      positionSide: validationMessagePosition,
      rtlEnabled,
      target: validationMessageTarget,
      boundary: validationMessageTarget,
      visualContainer: validationMessageTarget,
      contentId: validationMessageGuid
    })], 0)
  }), null, widgetRef));
};
var EditorProps = Object.create(Object.prototype, Object.assign(Object.getOwnPropertyDescriptors(BaseWidgetProps), Object.getOwnPropertyDescriptors({
  readOnly: false,
  name: "",
  validationError: null,
  validationErrors: null,
  validationMessageMode: "auto",
  validationMessagePosition: "bottom",
  validationStatus: "valid",
  isValid: true,
  isDirty: false,
  inputAttr: Object.freeze({}),
  defaultValue: null,
  valueChange: () => {
  }
})));
var EditorPropsType = {
  get readOnly() {
    return EditorProps.readOnly;
  },
  get name() {
    return EditorProps.name;
  },
  get validationError() {
    return EditorProps.validationError;
  },
  get validationErrors() {
    return EditorProps.validationErrors;
  },
  get validationMessageMode() {
    return EditorProps.validationMessageMode;
  },
  get validationMessagePosition() {
    return EditorProps.validationMessagePosition;
  },
  get validationStatus() {
    return EditorProps.validationStatus;
  },
  get isValid() {
    return EditorProps.isValid;
  },
  get isDirty() {
    return EditorProps.isDirty;
  },
  get inputAttr() {
    return EditorProps.inputAttr;
  },
  get defaultValue() {
    return EditorProps.defaultValue;
  },
  get valueChange() {
    return EditorProps.valueChange;
  },
  get className() {
    return EditorProps.className;
  },
  get activeStateEnabled() {
    return EditorProps.activeStateEnabled;
  },
  get disabled() {
    return EditorProps.disabled;
  },
  get focusStateEnabled() {
    return EditorProps.focusStateEnabled;
  },
  get hoverStateEnabled() {
    return EditorProps.hoverStateEnabled;
  },
  get tabIndex() {
    return EditorProps.tabIndex;
  },
  get visible() {
    return EditorProps.visible;
  },
  get aria() {
    return WidgetProps.aria;
  },
  get classes() {
    return WidgetProps.classes;
  }
};
var Editor2 = class extends InfernoWrapperComponent {
  constructor(props) {
    super(props);
    this.widgetRef = createRef();
    this.rootElementRef = createRef();
    this.__getterCache = {};
    this.state = {
      validationMessageGuid: `dx-${new guid_default()}`,
      isValidationMessageVisible: false,
      value: void 0 !== this.props.value ? this.props.value : this.props.defaultValue
    };
    this.updateValidationMessageVisibility = this.updateValidationMessageVisibility.bind(this);
    this.focus = this.focus.bind(this);
    this.blur = this.blur.bind(this);
    this.onFocusIn = this.onFocusIn.bind(this);
  }
  createEffects() {
    return [new InfernoEffect(this.updateValidationMessageVisibility, [this.props.isValid, this.props.validationStatus, this.props.validationError, this.props.validationErrors]), createReRenderEffect()];
  }
  updateEffects() {
    var _this$_effects$;
    null === (_this$_effects$ = this._effects[0]) || void 0 === _this$_effects$ || _this$_effects$.update([this.props.isValid, this.props.validationStatus, this.props.validationError, this.props.validationErrors]);
  }
  updateValidationMessageVisibility() {
    this.setState((__state_argument) => ({
      isValidationMessageVisible: this.shouldShowValidationMessage
    }));
  }
  onFocusIn(event) {
    const {
      onFocusIn
    } = this.props;
    null === onFocusIn || void 0 === onFocusIn || onFocusIn(event);
  }
  get cssClasses() {
    return `${getCssClasses(_extends({}, this.props, {
      value: void 0 !== this.props.value ? this.props.value : this.state.value
    }))}`;
  }
  get shouldShowValidationMessage() {
    const {
      isValid,
      validationStatus
    } = this.props;
    const validationErrors = this.validationErrors ?? [];
    const isEditorValid = isValid && "invalid" !== validationStatus;
    return !isEditorValid && validationErrors.length > 0;
  }
  get aria() {
    const {
      isValid,
      readOnly
    } = this.props;
    const result = {
      readonly: readOnly ? "true" : "false",
      invalid: !isValid ? "true" : "false"
    };
    if (this.shouldShowValidationMessage) {
      result.describedBy = this.state.validationMessageGuid;
    }
    return _extends({}, result, this.props.aria);
  }
  get validationErrors() {
    if (void 0 !== this.__getterCache.validationErrors) {
      return this.__getterCache.validationErrors;
    }
    return this.__getterCache.validationErrors = (() => {
      const {
        validationError,
        validationErrors
      } = this.props;
      let allValidationErrors = validationErrors && [...validationErrors];
      if (!allValidationErrors && validationError) {
        allValidationErrors = [_extends({}, validationError)];
      }
      return allValidationErrors;
    })();
  }
  get validationMessageTarget() {
    var _this$rootElementRef;
    return null === (_this$rootElementRef = this.rootElementRef) || void 0 === _this$rootElementRef ? void 0 : _this$rootElementRef.current;
  }
  get restAttributes() {
    const _this$props$value = _extends({}, this.props, {
      value: void 0 !== this.props.value ? this.props.value : this.state.value
    }), restProps = _objectWithoutPropertiesLoose(_this$props$value, _excluded4);
    return restProps;
  }
  focus() {
    this.widgetRef.current.focus();
  }
  blur() {
    this.widgetRef.current.blur();
  }
  componentWillUpdate(nextProps, nextState, context) {
    super.componentWillUpdate();
    if (this.props.validationError !== nextProps.validationError || this.props.validationErrors !== nextProps.validationErrors) {
      this.__getterCache.validationErrors = void 0;
    }
  }
  render() {
    const props = this.props;
    return viewFunction3({
      props: _extends({}, props, {
        value: void 0 !== this.props.value ? this.props.value : this.state.value
      }),
      validationMessageGuid: this.state.validationMessageGuid,
      isValidationMessageVisible: this.state.isValidationMessageVisible,
      rootElementRef: this.rootElementRef,
      widgetRef: this.widgetRef,
      onFocusIn: this.onFocusIn,
      cssClasses: this.cssClasses,
      shouldShowValidationMessage: this.shouldShowValidationMessage,
      aria: this.aria,
      validationErrors: this.validationErrors,
      validationMessageTarget: this.validationMessageTarget,
      restAttributes: this.restAttributes
    });
  }
};
Editor2.defaultProps = EditorPropsType;

// node_modules/devextreme/esm/renovation/ui/editors/check_box/check_box_icon.js
var _excluded5 = ["size"];
var viewFunction4 = (viewModel) => {
  const {
    cssStyles,
    elementRef
  } = viewModel;
  return createVNode(1, "span", "dx-checkbox-icon", null, 1, {
    style: normalizeStyles(cssStyles)
  }, null, elementRef);
};
var CheckBoxIconProps = {};
var CheckBoxIcon = class extends BaseInfernoComponent {
  constructor(props) {
    super(props);
    this.state = {};
    this.elementRef = createRef();
    this.__getterCache = {};
  }
  get cssStyles() {
    if (void 0 !== this.__getterCache.cssStyles) {
      return this.__getterCache.cssStyles;
    }
    return this.__getterCache.cssStyles = (() => {
      const {
        size
      } = this.props;
      const fontSize = normalizeStyleProp("fontSize", size);
      return {
        fontSize
      };
    })();
  }
  get restAttributes() {
    const _this$props = this.props, restProps = _objectWithoutPropertiesLoose(_this$props, _excluded5);
    return restProps;
  }
  componentWillUpdate(nextProps, nextState, context) {
    if (this.props.size !== nextProps.size) {
      this.__getterCache.cssStyles = void 0;
    }
  }
  render() {
    const props = this.props;
    return viewFunction4({
      props: _extends({}, props),
      elementRef: this.elementRef,
      cssStyles: this.cssStyles,
      restAttributes: this.restAttributes
    });
  }
};
CheckBoxIcon.defaultProps = CheckBoxIconProps;

// node_modules/devextreme/esm/renovation/ui/editors/check_box/check_box.js
var _excluded6 = ["accessKey", "activeStateEnabled", "aria", "className", "defaultValue", "disabled", "enableThreeStateBehavior", "focusStateEnabled", "height", "hint", "hoverStateEnabled", "iconSize", "inputAttr", "isDirty", "isValid", "name", "onClick", "onFocusIn", "onKeyDown", "readOnly", "rtlEnabled", "saveValueChangeEvent", "tabIndex", "text", "validationError", "validationErrors", "validationMessageMode", "validationMessagePosition", "validationStatus", "value", "valueChange", "visible", "width"];
var getCssClasses2 = (model) => {
  const {
    text,
    value
  } = model;
  const checked = value;
  const indeterminate = null === checked;
  const classesMap = {
    "dx-checkbox": true,
    "dx-checkbox-checked": true === checked,
    "dx-checkbox-has-text": !!text,
    "dx-checkbox-indeterminate": indeterminate
  };
  return combineClasses(classesMap);
};
var viewFunction5 = (viewModel) => {
  const {
    aria,
    cssClasses: classes,
    editorRef,
    keyDown: onKeyDown,
    onWidgetClick: onClick,
    props: {
      accessKey,
      activeStateEnabled,
      className,
      disabled,
      focusStateEnabled,
      height,
      hint,
      hoverStateEnabled,
      iconSize,
      isValid,
      name,
      onFocusIn,
      readOnly,
      rtlEnabled,
      tabIndex,
      text,
      validationError,
      validationErrors,
      validationMessageMode,
      validationMessagePosition,
      validationStatus,
      value,
      visible,
      width
    },
    restAttributes
  } = viewModel;
  return normalizeProps(createComponentVNode(2, Editor2, _extends({
    aria,
    classes,
    onClick,
    onKeyDown,
    accessKey,
    activeStateEnabled,
    focusStateEnabled,
    hoverStateEnabled,
    className,
    disabled,
    readOnly,
    hint,
    height,
    width,
    rtlEnabled,
    tabIndex,
    visible,
    validationError,
    validationErrors,
    validationMessageMode,
    validationMessagePosition,
    validationStatus,
    isValid,
    onFocusIn
  }, restAttributes, {
    children: createFragment([normalizeProps(createVNode(64, "input", null, null, 1, _extends({
      type: "hidden",
      value: `${value}`
    }, name && {
      name
    }))), createVNode(1, "div", "dx-checkbox-container", [createComponentVNode(2, CheckBoxIcon, {
      size: iconSize,
      isChecked: true === value
    }), text && createVNode(1, "span", "dx-checkbox-text", text, 0)], 0)], 4)
  }), null, editorRef));
};
var CheckBoxProps = Object.create(Object.prototype, Object.assign(Object.getOwnPropertyDescriptors(EditorProps), Object.getOwnPropertyDescriptors({
  text: "",
  enableThreeStateBehavior: false,
  activeStateEnabled: true,
  hoverStateEnabled: true,
  get focusStateEnabled() {
    return "desktop" === devices_default.real().deviceType && !devices_default.isSimulator();
  },
  defaultValue: false,
  valueChange: () => {
  }
})));
var CheckBoxPropsType = {
  get text() {
    return CheckBoxProps.text;
  },
  get enableThreeStateBehavior() {
    return CheckBoxProps.enableThreeStateBehavior;
  },
  get activeStateEnabled() {
    return CheckBoxProps.activeStateEnabled;
  },
  get hoverStateEnabled() {
    return CheckBoxProps.hoverStateEnabled;
  },
  get focusStateEnabled() {
    return CheckBoxProps.focusStateEnabled;
  },
  get defaultValue() {
    return CheckBoxProps.defaultValue;
  },
  get valueChange() {
    return CheckBoxProps.valueChange;
  },
  get readOnly() {
    return CheckBoxProps.readOnly;
  },
  get name() {
    return CheckBoxProps.name;
  },
  get validationError() {
    return CheckBoxProps.validationError;
  },
  get validationErrors() {
    return CheckBoxProps.validationErrors;
  },
  get validationMessageMode() {
    return CheckBoxProps.validationMessageMode;
  },
  get validationMessagePosition() {
    return CheckBoxProps.validationMessagePosition;
  },
  get validationStatus() {
    return CheckBoxProps.validationStatus;
  },
  get isValid() {
    return CheckBoxProps.isValid;
  },
  get isDirty() {
    return CheckBoxProps.isDirty;
  },
  get inputAttr() {
    return CheckBoxProps.inputAttr;
  },
  get className() {
    return CheckBoxProps.className;
  },
  get disabled() {
    return CheckBoxProps.disabled;
  },
  get tabIndex() {
    return CheckBoxProps.tabIndex;
  },
  get visible() {
    return CheckBoxProps.visible;
  },
  get aria() {
    return WidgetProps.aria;
  }
};
var CheckBox2 = class extends InfernoWrapperComponent {
  constructor(props) {
    super(props);
    this.editorRef = createRef();
    this.state = {
      value: void 0 !== this.props.value ? this.props.value : this.props.defaultValue
    };
    this.focus = this.focus.bind(this);
    this.blur = this.blur.bind(this);
    this.onWidgetClick = this.onWidgetClick.bind(this);
    this.keyDown = this.keyDown.bind(this);
  }
  createEffects() {
    return [createReRenderEffect()];
  }
  onWidgetClick(event) {
    const {
      enableThreeStateBehavior,
      readOnly,
      saveValueChangeEvent
    } = this.props;
    if (!readOnly) {
      null === saveValueChangeEvent || void 0 === saveValueChangeEvent || saveValueChangeEvent(event);
      if (enableThreeStateBehavior) {
        let __newValue;
        this.setState((__state_argument) => {
          __newValue = null === (void 0 !== this.props.value ? this.props.value : __state_argument.value) || (!(void 0 !== this.props.value ? this.props.value : __state_argument.value) ? null : false);
          return {
            value: __newValue
          };
        });
        this.props.valueChange(__newValue);
      } else {
        let __newValue;
        this.setState((__state_argument) => {
          __newValue = !((void 0 !== this.props.value ? this.props.value : __state_argument.value) ?? false);
          return {
            value: __newValue
          };
        });
        this.props.valueChange(__newValue);
      }
    }
  }
  keyDown(e) {
    const {
      onKeyDown
    } = this.props;
    const {
      keyName,
      originalEvent,
      which
    } = e;
    const result = null === onKeyDown || void 0 === onKeyDown ? void 0 : onKeyDown(e);
    if (null !== result && void 0 !== result && result.cancel) {
      return result;
    }
    if ("space" === keyName || "space" === which) {
      originalEvent.preventDefault();
      this.onWidgetClick(originalEvent);
    }
    return;
  }
  get cssClasses() {
    return getCssClasses2(_extends({}, this.props, {
      value: void 0 !== this.props.value ? this.props.value : this.state.value
    }));
  }
  get aria() {
    const checked = true === (void 0 !== this.props.value ? this.props.value : this.state.value);
    const indeterminate = null === (void 0 !== this.props.value ? this.props.value : this.state.value);
    const result = {
      role: "checkbox",
      checked: indeterminate ? "mixed" : `${checked}`
    };
    return _extends({}, result, this.props.aria);
  }
  get restAttributes() {
    const _this$props$value = _extends({}, this.props, {
      value: void 0 !== this.props.value ? this.props.value : this.state.value
    }), restProps = _objectWithoutPropertiesLoose(_this$props$value, _excluded6);
    return restProps;
  }
  focus() {
    this.editorRef.current.focus();
  }
  blur() {
    this.editorRef.current.blur();
  }
  render() {
    const props = this.props;
    return viewFunction5({
      props: _extends({}, props, {
        value: void 0 !== this.props.value ? this.props.value : this.state.value
      }),
      editorRef: this.editorRef,
      onWidgetClick: this.onWidgetClick,
      keyDown: this.keyDown,
      cssClasses: this.cssClasses,
      aria: this.aria,
      restAttributes: this.restAttributes
    });
  }
};
function __processTwoWayProps(defaultProps) {
  const twoWayProps = ["value"];
  return Object.keys(defaultProps).reduce((props, propName) => {
    const propValue = defaultProps[propName];
    const defaultPropName = twoWayProps.some((p) => p === propName) ? "default" + propName.charAt(0).toUpperCase() + propName.slice(1) : propName;
    props[defaultPropName] = propValue;
    return props;
  }, {});
}
CheckBox2.defaultProps = CheckBoxPropsType;
var __defaultOptionRules = [];
function defaultOptions(rule) {
  __defaultOptionRules.push(rule);
  CheckBox2.defaultProps = Object.create(Object.prototype, Object.assign(Object.getOwnPropertyDescriptors(CheckBox2.defaultProps), Object.getOwnPropertyDescriptors(__processTwoWayProps(convertRulesToOptions(__defaultOptionRules)))));
}

// node_modules/devextreme/esm/renovation/ui/editors/check_box/check_box.j.js
var CheckBox3 = class extends CheckBox {
  getProps() {
    const props = super.getProps();
    props.onKeyDown = this._wrapKeyDownHandler(props.onKeyDown);
    return props;
  }
  focus() {
    var _this$viewRef;
    return null === (_this$viewRef = this.viewRef) || void 0 === _this$viewRef ? void 0 : _this$viewRef.focus(...arguments);
  }
  blur() {
    var _this$viewRef2;
    return null === (_this$viewRef2 = this.viewRef) || void 0 === _this$viewRef2 ? void 0 : _this$viewRef2.blur(...arguments);
  }
  _getActionConfigs() {
    return {
      onFocusIn: {},
      onClick: {}
    };
  }
  get _propsInfo() {
    return {
      twoWay: [["value", "defaultValue", "valueChange"]],
      allowNull: ["defaultValue", "validationError", "validationErrors", "value"],
      elements: [],
      templates: [],
      props: ["text", "iconSize", "enableThreeStateBehavior", "activeStateEnabled", "hoverStateEnabled", "focusStateEnabled", "saveValueChangeEvent", "defaultValue", "valueChange", "readOnly", "name", "validationError", "validationErrors", "validationMessageMode", "validationMessagePosition", "validationStatus", "isValid", "isDirty", "inputAttr", "onFocusIn", "className", "accessKey", "disabled", "height", "hint", "onClick", "onKeyDown", "rtlEnabled", "tabIndex", "visible", "width", "aria", "value"]
    };
  }
  get _viewComponent() {
    return CheckBox2;
  }
};
component_registrator_default("dxCheckBox", CheckBox3);
CheckBox3.defaultOptions = defaultOptions;

// node_modules/devextreme/esm/ui/check_box.js
var check_box_default = CheckBox3;

export {
  DomComponentWrapper,
  EditorProps,
  check_box_default
};
//# sourceMappingURL=chunk-7W6OPS6O.js.map
