import {
  DxDrawerComponent,
  DxDrawerModule
} from "./chunk-HILWVBJW.js";
import "./chunk-DOIRN5IG.js";
import "./chunk-CADIH4ZJ.js";
import "./chunk-ZEY4S4J4.js";
import "./chunk-MM4NENTZ.js";
import "./chunk-76GCZVPW.js";
import "./chunk-7YZ53GCH.js";
import "./chunk-IRP4I5CC.js";
import "./chunk-MU4Z4OEA.js";
import "./chunk-RC2BNL3X.js";
import "./chunk-W35F6NCE.js";
import "./chunk-4BRW6FUL.js";
import "./chunk-UTUFIS2B.js";
import "./chunk-FIIAYBZC.js";
import "./chunk-5YDKINUH.js";
import "./chunk-N6ESDQJH.js";
export {
  DxDrawerComponent,
  DxDrawerModule
};
//# sourceMappingURL=devextreme-angular_ui_drawer.js.map
