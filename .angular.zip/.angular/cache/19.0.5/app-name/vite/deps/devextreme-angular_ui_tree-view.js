import {
  DxTreeViewComponent,
  DxTreeViewModule
} from "./chunk-2B7VLMEQ.js";
import "./chunk-QFMTCW2W.js";
import "./chunk-42TRBWEA.js";
import "./chunk-3HM2JABP.js";
import "./chunk-7W6OPS6O.js";
import "./chunk-HIIKPTPP.js";
import "./chunk-VOSGCXDL.js";
import "./chunk-FQJQBZFP.js";
import "./chunk-SXMMF6QJ.js";
import "./chunk-CYLWHOEL.js";
import "./chunk-AF6BX6BR.js";
import "./chunk-DOIRN5IG.js";
import "./chunk-CADIH4ZJ.js";
import "./chunk-DGNKDK3D.js";
import "./chunk-M7JKWUQP.js";
import "./chunk-6PD6EB72.js";
import "./chunk-ZEY4S4J4.js";
import "./chunk-MM4NENTZ.js";
import "./chunk-76GCZVPW.js";
import "./chunk-7YZ53GCH.js";
import "./chunk-IRP4I5CC.js";
import "./chunk-MU4Z4OEA.js";
import "./chunk-RC2BNL3X.js";
import "./chunk-W35F6NCE.js";
import "./chunk-4BRW6FUL.js";
import "./chunk-UTUFIS2B.js";
import "./chunk-FIIAYBZC.js";
import "./chunk-5YDKINUH.js";
import "./chunk-N6ESDQJH.js";
export {
  DxTreeViewComponent,
  DxTreeViewModule
};
//# sourceMappingURL=devextreme-angular_ui_tree-view.js.map
