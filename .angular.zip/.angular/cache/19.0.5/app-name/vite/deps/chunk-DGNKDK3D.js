import {
  message_default
} from "./chunk-M7JKWUQP.js";
import {
  current,
  isGeneric,
  isMaterialBased
} from "./chunk-6PD6EB72.js";
import {
  ui_widget_default
} from "./chunk-ZEY4S4J4.js";
import {
  animation,
  component_registrator_default
} from "./chunk-MM4NENTZ.js";
import {
  devices_default
} from "./chunk-76GCZVPW.js";
import {
  getHeight,
  getWidth,
  renderer_default
} from "./chunk-MU4Z4OEA.js";
import {
  getNavigator
} from "./chunk-4BRW6FUL.js";
import {
  extend
} from "./chunk-UTUFIS2B.js";

// node_modules/devextreme/esm/__internal/ui/m_load_indicator.js
var navigator = getNavigator();
var LoadIndicator = ui_widget_default.inherit({
  _getDefaultOptions() {
    return extend(this.callBase(), {
      indicatorSrc: "",
      activeStateEnabled: false,
      hoverStateEnabled: false,
      _animatingSegmentCount: 1,
      _animatingSegmentInner: false
    });
  },
  _defaultOptionsRules() {
    const themeName = current();
    return this.callBase().concat([{
      device() {
        const realDevice = devices_default.real();
        const obsoleteAndroid = "android" === realDevice.platform && !/chrome/i.test(navigator.userAgent);
        return obsoleteAndroid;
      },
      options: {
        viaImage: true
      }
    }, {
      device: () => isMaterialBased(themeName),
      options: {
        _animatingSegmentCount: 2,
        _animatingSegmentInner: true
      }
    }, {
      device: () => isGeneric(themeName),
      options: {
        _animatingSegmentCount: 7
      }
    }]);
  },
  _useTemplates: () => false,
  _init() {
    this.callBase();
    this.$element().addClass("dx-loadindicator");
    const label = message_default.format("Loading");
    const aria = {
      role: "alert",
      label
    };
    this.setAria(aria);
  },
  _initMarkup() {
    this.callBase();
    this._renderWrapper();
    this._renderIndicatorContent();
    this._renderMarkup();
  },
  _renderWrapper() {
    this._$wrapper = renderer_default("<div>").addClass("dx-loadindicator-wrapper");
    this.$element().append(this._$wrapper);
  },
  _renderIndicatorContent() {
    this._$content = renderer_default("<div>").addClass("dx-loadindicator-content");
    this._$wrapper.append(this._$content);
  },
  _renderMarkup() {
    const {
      viaImage,
      indicatorSrc
    } = this.option();
    if (animation() && !viaImage && !indicatorSrc) {
      this._renderMarkupForAnimation();
    } else {
      this._renderMarkupForImage();
    }
  },
  _renderMarkupForAnimation() {
    const animatingSegmentInner = this.option("_animatingSegmentInner");
    this._$indicator = renderer_default("<div>").addClass("dx-loadindicator-icon");
    this._$content.append(this._$indicator);
    for (let i = this.option("_animatingSegmentCount"); i >= 0; --i) {
      const $segment = renderer_default("<div>").addClass("dx-loadindicator-segment").addClass("dx-loadindicator-segment" + i);
      if (animatingSegmentInner) {
        $segment.append(renderer_default("<div>").addClass("dx-loadindicator-segment-inner"));
      }
      this._$indicator.append($segment);
    }
  },
  _renderMarkupForImage() {
    const {
      indicatorSrc
    } = this.option();
    if (indicatorSrc) {
      this._$wrapper.addClass("dx-loadindicator-image");
      this._$wrapper.css("backgroundImage", `url(${indicatorSrc})`);
    } else if (animation()) {
      this._renderMarkupForAnimation();
    }
  },
  _renderDimensions() {
    this.callBase();
    this._updateContentSizeForAnimation();
  },
  _updateContentSizeForAnimation() {
    if (!this._$indicator) {
      return;
    }
    let width = this.option("width");
    let height = this.option("height");
    if (width || height) {
      width = getWidth(this.$element());
      height = getHeight(this.$element());
      const minDimension = Math.min(height, width);
      this._$wrapper.css({
        height: minDimension,
        width: minDimension,
        fontSize: minDimension
      });
    }
  },
  _clean() {
    this.callBase();
    this._removeMarkupForAnimation();
    this._removeMarkupForImage();
  },
  _removeMarkupForAnimation() {
    if (!this._$indicator) {
      return;
    }
    this._$indicator.remove();
    delete this._$indicator;
  },
  _removeMarkupForImage() {
    this._$wrapper.css("backgroundImage", "none");
  },
  _optionChanged(args) {
    switch (args.name) {
      case "_animatingSegmentCount":
      case "_animatingSegmentInner":
      case "indicatorSrc":
        this._invalidate();
        break;
      default:
        this.callBase(args);
    }
  }
});
component_registrator_default("dxLoadIndicator", LoadIndicator);
var m_load_indicator_default = LoadIndicator;

// node_modules/devextreme/esm/ui/load_indicator.js
var load_indicator_default = m_load_indicator_default;

export {
  load_indicator_default
};
//# sourceMappingURL=chunk-DGNKDK3D.js.map
