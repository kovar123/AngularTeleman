import {
  ListBase,
  m_toolbar_base_default
} from "./chunk-MJ4KNKI6.js";
import {
  widget_default
} from "./chunk-D77BQ7AD.js";
import {
  DxiItemComponent,
  DxiItemModule
} from "./chunk-FQJQBZFP.js";
import {
  button_default
} from "./chunk-SXMMF6QJ.js";
import {
  isFluent,
  isMaterialBased
} from "./chunk-6PD6EB72.js";
import {
  ChildDefaultTemplate,
  component_registrator_default
} from "./chunk-MM4NENTZ.js";
import {
  devices_default
} from "./chunk-76GCZVPW.js";
import {
  DxComponent,
  DxIntegrationModule,
  DxTemplateHost,
  DxTemplateModule,
  IterableDifferHelper,
  NestedOptionHost,
  WatcherHelper
} from "./chunk-7YZ53GCH.js";
import {
  getOuterHeight,
  getOuterWidth,
  getWidth,
  renderer_default
} from "./chunk-MU4Z4OEA.js";
import {
  _extends,
  compileGetter,
  deferRender,
  each,
  getWindow,
  grep
} from "./chunk-4BRW6FUL.js";
import {
  extend
} from "./chunk-UTUFIS2B.js";
import {
  Component,
  ContentChildren,
  ElementRef,
  Inject,
  Input,
  NgModule,
  NgZone,
  Output,
  PLATFORM_ID,
  TransferState,
  setClassMetadata,
  ɵɵInheritDefinitionFeature,
  ɵɵNgOnChangesFeature,
  ɵɵProvidersFeature,
  ɵɵcontentQuery,
  ɵɵdefineComponent,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdirectiveInject,
  ɵɵloadQuery,
  ɵɵqueryRefresh
} from "./chunk-5YDKINUH.js";

// node_modules/devextreme/esm/__internal/ui/toolbar/m_toolbar.utils.js
var TOOLBAR_ITEMS = ["dxAutocomplete", "dxButton", "dxCheckBox", "dxDateBox", "dxMenu", "dxSelectBox", "dxTabs", "dxTextBox", "dxButtonGroup", "dxDropDownButton"];
var getItemInstance = function($element) {
  const itemData = $element.data && $element.data();
  const dxComponents = itemData && itemData.dxComponents;
  const widgetName = dxComponents && dxComponents[0];
  return widgetName && itemData[widgetName];
};
function toggleItemFocusableElementTabIndex(context, item) {
  var _itemData$options;
  if (!context) {
    return;
  }
  const $item = context._findItemElementByItem(item);
  if (!$item.length) {
    return;
  }
  const itemData = context._getItemData($item);
  const isItemNotFocusable = !!(null !== (_itemData$options = itemData.options) && void 0 !== _itemData$options && _itemData$options.disabled || itemData.disabled || context.option("disabled"));
  const {
    widget
  } = itemData;
  if (widget && TOOLBAR_ITEMS.includes(widget)) {
    const $widget = $item.find(widget.toLowerCase().replace("dx", ".dx-"));
    if ($widget.length) {
      var _itemInstance$_focusT, _itemData$options2;
      const itemInstance = getItemInstance($widget);
      if (!itemInstance) {
        return;
      }
      let $focusTarget = null === (_itemInstance$_focusT = itemInstance._focusTarget) || void 0 === _itemInstance$_focusT ? void 0 : _itemInstance$_focusT.call(itemInstance);
      if ("dxDropDownButton" === widget) {
        $focusTarget = $focusTarget && $focusTarget.find(".dx-buttongroup");
      } else {
        $focusTarget = $focusTarget ?? renderer_default(itemInstance.element());
      }
      const tabIndex = null === (_itemData$options2 = itemData.options) || void 0 === _itemData$options2 ? void 0 : _itemData$options2.tabIndex;
      if (isItemNotFocusable) {
        $focusTarget.attr("tabIndex", -1);
      } else {
        $focusTarget.attr("tabIndex", tabIndex ?? 0);
      }
    }
  }
}

// node_modules/devextreme/esm/__internal/ui/toolbar/strategy/m_toolbar.multiline.js
var MultiLineStrategy = class {
  constructor(toolbar) {
    this._toolbar = toolbar;
  }
  _initMarkup() {
  }
  _updateMenuVisibility() {
  }
  _renderMenuItems() {
  }
  _renderItem() {
  }
  _getMenuItems() {
  }
  _getToolbarItems() {
    return this._toolbar.option("items") ?? [];
  }
  _getItemsWidth() {
    return this._toolbar._getSummaryItemsSize("width", this._toolbar._itemElements(), true);
  }
  _arrangeItems() {
    const $label = this._toolbar._$toolbarItemsContainer.find(".dx-toolbar-label").eq(0);
    if (!$label.length) {
      return;
    }
    const elementWidth = getWidth(this._toolbar.$element());
    const labelPaddings = getOuterWidth($label) - getWidth($label);
    $label.css("maxWidth", elementWidth - labelPaddings);
  }
  _hideOverflowItems() {
  }
  _dimensionChanged() {
  }
  _itemOptionChanged() {
  }
  _optionChanged() {
  }
};

// node_modules/devextreme/esm/__internal/ui/toolbar/internal/m_toolbar.menu.list.js
var ToolbarMenuList = class extends ListBase {
  _init() {
    super._init();
    this._activeStateUnit = ".dx-toolbar-menu-action:not(.dx-toolbar-hidden-button-group)";
  }
  _initMarkup() {
    this._renderSections();
    super._initMarkup();
    this._setMenuRole();
  }
  _getSections() {
    return this._itemContainer().children();
  }
  _itemElements() {
    return this._getSections().children(this._itemSelector());
  }
  _renderSections() {
    const $container = this._itemContainer();
    each(["before", "center", "after", "menu"], (_, section) => {
      const sectionName = `_$${section}Section`;
      if (!this[sectionName]) {
        this[sectionName] = renderer_default("<div>").addClass("dx-toolbar-menu-section");
      }
      this[sectionName].appendTo($container);
    });
  }
  _renderItems() {
    super._renderItems.apply(this, arguments);
    this._updateSections();
  }
  _setMenuRole() {
    const $menuContainer = this.$element().find(".dx-scrollview-content");
    $menuContainer.attr("role", "menu");
  }
  _updateSections() {
    const $sections = this.$element().find(".dx-toolbar-menu-section");
    $sections.removeClass("dx-toolbar-menu-last-section");
    $sections.not(":empty").eq(-1).addClass("dx-toolbar-menu-last-section");
  }
  _renderItem(index, item, itemContainer, $after) {
    const location = item.location ?? "menu";
    const $container = this[`_$${location}Section`];
    const itemElement = super._renderItem(index, item, $container, $after);
    if (this._getItemTemplateName({
      itemData: item
    })) {
      itemElement.addClass("dx-toolbar-menu-custom");
    }
    if ("menu" === location || "dxButton" === item.widget || "dxButtonGroup" === item.widget || item.isAction) {
      itemElement.addClass("dx-toolbar-menu-action");
    }
    if ("dxButton" === item.widget) {
      itemElement.addClass("dx-toolbar-hidden-button");
    }
    if ("dxButtonGroup" === item.widget) {
      itemElement.addClass("dx-toolbar-hidden-button-group");
    }
    itemElement.addClass(item.cssClass);
    return itemElement;
  }
  _getItemTemplateName(args) {
    const template = super._getItemTemplateName(args);
    const data = args.itemData;
    const menuTemplate = data && data.menuItemTemplate;
    return menuTemplate || template;
  }
  _dataSourceOptions() {
    return {
      paginate: false
    };
  }
  _itemClickHandler(e, args, config) {
    if (renderer_default(e.target).closest(".dx-toolbar-menu-action").length) {
      super._itemClickHandler(e, args, config);
    }
  }
  _clean() {
    this._getSections().empty();
    super._clean();
  }
};

// node_modules/devextreme/esm/__internal/ui/toolbar/internal/m_toolbar.menu.js
var DropDownMenu = class extends widget_default {
  _supportedKeys() {
    var _this$_list;
    let extension = {};
    if (!this.option("opened") || !(null !== (_this$_list = this._list) && void 0 !== _this$_list && _this$_list.option("focusedElement"))) {
      extension = this._button._supportedKeys();
    }
    return extend(super._supportedKeys(), extension, {
      tab() {
        this._popup && this._popup.hide();
      }
    });
  }
  _getDefaultOptions() {
    return _extends({}, super._getDefaultOptions(), {
      items: [],
      onItemClick: null,
      dataSource: null,
      itemTemplate: "item",
      onButtonClick: null,
      activeStateEnabled: true,
      hoverStateEnabled: true,
      opened: false,
      onItemRendered: null,
      closeOnClick: true,
      useInkRipple: false,
      container: void 0,
      animation: {
        show: {
          type: "fade",
          from: 0,
          to: 1
        },
        hide: {
          type: "fade",
          to: 0
        }
      }
    });
  }
  _defaultOptionsRules() {
    return super._defaultOptionsRules().concat([{
      device: () => "desktop" === devices_default.real().deviceType && !devices_default.isSimulator(),
      options: {
        focusStateEnabled: true
      }
    }, {
      device: () => isMaterialBased(),
      options: {
        useInkRipple: true,
        animation: {
          show: {
            type: "pop",
            duration: 200,
            from: {
              scale: 0
            },
            to: {
              scale: 1
            }
          },
          hide: {
            type: "pop",
            duration: 200,
            from: {
              scale: 1
            },
            to: {
              scale: 0
            }
          }
        }
      }
    }]);
  }
  _init() {
    super._init();
    this.$element().addClass("dx-dropdownmenu");
    this._initItemClickAction();
    this._initButtonClickAction();
  }
  _initItemClickAction() {
    this._itemClickAction = this._createActionByOption("onItemClick");
  }
  _initButtonClickAction() {
    this._buttonClickAction = this._createActionByOption("onButtonClick");
  }
  _initTemplates() {
    this._templateManager.addDefaultTemplates({
      content: new ChildDefaultTemplate("content")
    });
    super._initTemplates();
  }
  _initMarkup() {
    this._renderButton();
    super._initMarkup();
  }
  _render() {
    super._render();
    this.setAria({
      haspopup: true,
      expanded: this.option("opened")
    });
  }
  _renderContentImpl() {
    if (this.option("opened")) {
      this._renderPopup();
    }
  }
  _clean() {
    this._cleanFocusState();
    this._list && this._list.$element().remove();
    this._popup && this._popup.$element().remove();
    delete this._list;
    delete this._popup;
  }
  _renderButton() {
    const $button = this.$element().addClass("dx-dropdownmenu-button");
    this._button = this._createComponent($button, button_default, {
      icon: "overflow",
      template: "content",
      stylingMode: isFluent() ? "text" : "contained",
      useInkRipple: this.option("useInkRipple"),
      hoverStateEnabled: false,
      focusStateEnabled: false,
      onClick: (e) => {
        this.option("opened", !this.option("opened"));
        this._buttonClickAction(e);
      }
    });
  }
  _toggleActiveState($element, value, e) {
    this._button._toggleActiveState($element, value, e);
  }
  _toggleMenuVisibility(opened) {
    var _this$_popup, _this$_popup2;
    const state = opened ?? !(null !== (_this$_popup = this._popup) && void 0 !== _this$_popup && _this$_popup.option("visible"));
    if (opened) {
      this._renderPopup();
    }
    null === (_this$_popup2 = this._popup) || void 0 === _this$_popup2 || _this$_popup2.toggle(state);
    this.setAria("expanded", state);
  }
  _renderPopup() {
    if (this._$popup) {
      return;
    }
    this._$popup = renderer_default("<div>").appendTo(this.$element());
    const {
      rtlEnabled,
      container,
      animation
    } = this.option();
    this._popup = this._createComponent(this._$popup, "dxPopup", {
      onInitialized(_ref) {
        let {
          component
        } = _ref;
        component.$wrapper().addClass("dx-dropdownmenu-popup-wrapper").addClass("dx-dropdownmenu-popup");
      },
      deferRendering: false,
      preventScrollEvents: false,
      contentTemplate: (contentElement) => this._renderList(contentElement),
      _ignoreFunctionValueDeprecation: true,
      maxHeight: () => this._getMaxHeight(),
      position: {
        my: "top " + (rtlEnabled ? "left" : "right"),
        at: "bottom " + (rtlEnabled ? "left" : "right"),
        collision: "fit flip",
        offset: {
          v: 3
        },
        of: this.$element()
      },
      animation,
      onOptionChanged: (_ref2) => {
        let {
          name,
          value
        } = _ref2;
        if ("visible" === name) {
          this.option("opened", value);
        }
      },
      container,
      autoResizeEnabled: false,
      height: "auto",
      width: "auto",
      hideOnOutsideClick: (e) => this._closeOutsideDropDownHandler(e),
      hideOnParentScroll: true,
      shading: false,
      dragEnabled: false,
      showTitle: false,
      fullScreen: false,
      _fixWrapperPosition: true
    });
  }
  _getMaxHeight() {
    const $element = this.$element();
    const offsetTop = $element.offset().top;
    const windowHeight = getOuterHeight(getWindow());
    const maxHeight = Math.max(offsetTop, windowHeight - offsetTop - getOuterHeight($element));
    return Math.min(windowHeight, maxHeight - 3 - 10);
  }
  _closeOutsideDropDownHandler(e) {
    const isOutsideClick = !renderer_default(e.target).closest(this.$element()).length;
    return isOutsideClick;
  }
  _renderList(contentElement) {
    const $content = renderer_default(contentElement);
    $content.addClass("dx-dropdownmenu-list");
    this._list = this._createComponent($content, ToolbarMenuList, {
      dataSource: this._getListDataSource(),
      pageLoadMode: "scrollBottom",
      indicateLoading: false,
      noDataText: "",
      itemTemplate: this.option("itemTemplate"),
      onItemClick: (e) => {
        if (this.option("closeOnClick")) {
          this.option("opened", false);
        }
        this._itemClickAction(e);
      },
      tabIndex: -1,
      focusStateEnabled: false,
      activeStateEnabled: true,
      onItemRendered: this.option("onItemRendered"),
      _itemAttributes: {
        role: "menuitem"
      }
    });
  }
  _itemOptionChanged(item, property, value) {
    var _this$_list2;
    null === (_this$_list2 = this._list) || void 0 === _this$_list2 || _this$_list2._itemOptionChanged(item, property, value);
    toggleItemFocusableElementTabIndex(this._list, item);
  }
  _getListDataSource() {
    return this.option("dataSource") ?? this.option("items");
  }
  _setListDataSource() {
    var _this$_list3;
    null === (_this$_list3 = this._list) || void 0 === _this$_list3 || _this$_list3.option("dataSource", this._getListDataSource());
    delete this._deferRendering;
  }
  _getKeyboardListeners() {
    return super._getKeyboardListeners().concat([this._list]);
  }
  _toggleVisibility(visible) {
    var _this$_button;
    super._toggleVisibility(visible);
    null === (_this$_button = this._button) || void 0 === _this$_button || _this$_button.option("visible", visible);
  }
  _optionChanged(args) {
    var _this$_list4, _this$_list5, _this$_list6;
    const {
      name,
      value
    } = args;
    switch (name) {
      case "items":
      case "dataSource":
        if (!this.option("opened")) {
          this._deferRendering = true;
        } else {
          this._setListDataSource();
        }
        break;
      case "itemTemplate":
        null === (_this$_list4 = this._list) || void 0 === _this$_list4 || _this$_list4.option(name, this._getTemplate(value));
        break;
      case "onItemClick":
        this._initItemClickAction();
        break;
      case "onButtonClick":
        this._buttonClickAction();
        break;
      case "useInkRipple":
        this._invalidate();
        break;
      case "focusStateEnabled":
        null === (_this$_list5 = this._list) || void 0 === _this$_list5 || _this$_list5.option(name, value);
        super._optionChanged(args);
        break;
      case "onItemRendered":
        null === (_this$_list6 = this._list) || void 0 === _this$_list6 || _this$_list6.option(name, value);
        break;
      case "opened":
        if (this._deferRendering) {
          this._setListDataSource();
        }
        this._toggleMenuVisibility(value);
        this._updateFocusableItemsTabIndex();
        break;
      case "closeOnClick":
        break;
      case "container":
        this._popup && this._popup.option(name, value);
        break;
      case "disabled":
        if (this._list) {
          this._updateFocusableItemsTabIndex();
        }
        break;
      default:
        super._optionChanged(args);
    }
  }
  _updateFocusableItemsTabIndex() {
    this.option("items").forEach((item) => toggleItemFocusableElementTabIndex(this._list, item));
  }
};

// node_modules/devextreme/esm/__internal/ui/toolbar/strategy/m_toolbar.singleline.js
var TOOLBAR_HIDDEN_ITEM = "dx-toolbar-item-invisible";
var SingleLineStrategy = class {
  constructor(toolbar) {
    this._toolbar = toolbar;
  }
  _initMarkup() {
    deferRender(() => {
      this._renderOverflowMenu();
      this._renderMenuItems();
    });
  }
  _renderOverflowMenu() {
    if (!this._hasVisibleMenuItems()) {
      return;
    }
    this._renderMenuButtonContainer();
    const $menu = renderer_default("<div>").appendTo(this._overflowMenuContainer());
    const itemClickAction = this._toolbar._createActionByOption("onItemClick");
    const menuItemTemplate = this._toolbar._getTemplateByOption("menuItemTemplate");
    this._menu = this._toolbar._createComponent($menu, DropDownMenu, {
      disabled: this._toolbar.option("disabled"),
      itemTemplate: () => menuItemTemplate,
      onItemClick: (e) => {
        itemClickAction(e);
      },
      container: this._toolbar.option("menuContainer"),
      onOptionChanged: (_ref) => {
        let {
          name,
          value
        } = _ref;
        if ("opened" === name) {
          this._toolbar.option("overflowMenuVisible", value);
        }
        if ("items" === name) {
          this._updateMenuVisibility(value);
        }
      }
    });
  }
  renderMenuItems() {
    if (!this._menu) {
      this._renderOverflowMenu();
    }
    this._menu && this._menu.option("items", this._getMenuItems());
    if (this._menu && !this._menu.option("items").length) {
      this._menu.option("opened", false);
    }
  }
  _renderMenuButtonContainer() {
    this._$overflowMenuContainer = renderer_default("<div>").appendTo(this._toolbar._$afterSection).addClass("dx-toolbar-button").addClass("dx-toolbar-menu-container");
  }
  _overflowMenuContainer() {
    return this._$overflowMenuContainer;
  }
  _updateMenuVisibility(menuItems) {
    const items = menuItems ?? this._getMenuItems();
    const isMenuVisible = items.length && this._hasVisibleMenuItems(items);
    this._toggleMenuVisibility(isMenuVisible);
  }
  _toggleMenuVisibility(value) {
    if (!this._overflowMenuContainer()) {
      return;
    }
    this._overflowMenuContainer().toggleClass("dx-state-invisible", !value);
  }
  _renderMenuItems() {
    deferRender(() => {
      this.renderMenuItems();
    });
  }
  _dimensionChanged() {
    this.renderMenuItems();
  }
  _getToolbarItems() {
    return grep(this._toolbar.option("items") ?? [], (item) => !this._toolbar._isMenuItem(item));
  }
  _getHiddenItems() {
    return this._toolbar._itemContainer().children(`.dx-toolbar-item-auto-hide.${TOOLBAR_HIDDEN_ITEM}`).not(".dx-state-invisible");
  }
  _getMenuItems() {
    const menuItems = grep(this._toolbar.option("items") ?? [], (item) => this._toolbar._isMenuItem(item));
    const $hiddenItems = this._getHiddenItems();
    this._restoreItems = this._restoreItems ?? [];
    const overflowItems = [].slice.call($hiddenItems).map((hiddenItem) => {
      const itemData = this._toolbar._getItemData(hiddenItem);
      const $itemContainer = renderer_default(hiddenItem);
      const $itemMarkup = $itemContainer.children();
      return extend({
        menuItemTemplate: () => {
          this._restoreItems.push({
            container: $itemContainer,
            item: $itemMarkup
          });
          const $container = renderer_default("<div>").addClass("dx-toolbar-item-auto-hide");
          return $container.append($itemMarkup);
        }
      }, itemData);
    });
    return [...overflowItems, ...menuItems];
  }
  _hasVisibleMenuItems(items) {
    const menuItems = items ?? this._toolbar.option("items");
    let result = false;
    const optionGetter = compileGetter("visible");
    const overflowGetter = compileGetter("locateInMenu");
    each(menuItems, (index, item) => {
      const itemVisible = optionGetter(item, {
        functionsAsIs: true
      });
      const itemOverflow = overflowGetter(item, {
        functionsAsIs: true
      });
      if (false !== itemVisible && ("auto" === itemOverflow || "always" === itemOverflow) || "menu" === item.location) {
        result = true;
      }
    });
    return result;
  }
  _arrangeItems() {
    this._toolbar._$centerSection.css({
      margin: "0 auto",
      float: "none"
    });
    each(this._restoreItems ?? [], (_, obj) => {
      renderer_default(obj.container).append(obj.item);
    });
    this._restoreItems = [];
    const elementWidth = getWidth(this._toolbar.$element());
    this._hideOverflowItems(elementWidth);
    return elementWidth;
  }
  _hideOverflowItems(width) {
    const overflowItems = this._toolbar.$element().find(".dx-toolbar-item-auto-hide");
    if (!overflowItems.length) {
      return;
    }
    const elementWidth = width ?? getWidth(this._toolbar.$element());
    renderer_default(overflowItems).removeClass(TOOLBAR_HIDDEN_ITEM);
    let itemsWidth = this._getItemsWidth();
    while (overflowItems.length && elementWidth < itemsWidth) {
      const $item = overflowItems.eq(-1);
      $item.addClass(TOOLBAR_HIDDEN_ITEM);
      itemsWidth = this._getItemsWidth();
      overflowItems.splice(-1, 1);
    }
  }
  _getItemsWidth() {
    return this._toolbar._getSummaryItemsSize("width", [this._toolbar._$beforeSection, this._toolbar._$centerSection, this._toolbar._$afterSection]);
  }
  _itemOptionChanged(item, property, value) {
    if ("disabled" === property || "options.disabled" === property) {
      if (this._toolbar._isMenuItem(item)) {
        var _this$_menu;
        null === (_this$_menu = this._menu) || void 0 === _this$_menu || _this$_menu._itemOptionChanged(item, property, value);
        return;
      }
    }
    this.renderMenuItems();
  }
  _renderItem(item, itemElement) {
    if ("auto" === item.locateInMenu) {
      itemElement.addClass("dx-toolbar-item-auto-hide");
    }
  }
  _optionChanged(name, value) {
    var _this$_menu2, _this$_menu3, _this$_menu4, _this$_menu5, _this$_menu6;
    switch (name) {
      case "disabled":
        null === (_this$_menu2 = this._menu) || void 0 === _this$_menu2 || _this$_menu2.option(name, value);
        break;
      case "overflowMenuVisible":
        null === (_this$_menu3 = this._menu) || void 0 === _this$_menu3 || _this$_menu3.option("opened", value);
        break;
      case "onItemClick":
        null === (_this$_menu4 = this._menu) || void 0 === _this$_menu4 || _this$_menu4.option(name, value);
        break;
      case "menuContainer":
        null === (_this$_menu5 = this._menu) || void 0 === _this$_menu5 || _this$_menu5.option("container", value);
        break;
      case "menuItemTemplate":
        null === (_this$_menu6 = this._menu) || void 0 === _this$_menu6 || _this$_menu6.option("itemTemplate", value);
    }
  }
};

// node_modules/devextreme/esm/__internal/ui/toolbar/m_toolbar.js
var Toolbar = class extends m_toolbar_base_default {
  _getDefaultOptions() {
    return _extends({}, super._getDefaultOptions(), {
      menuItemTemplate: "menuItem",
      menuContainer: void 0,
      overflowMenuVisible: false,
      multiline: false
    });
  }
  _isMultiline() {
    return this.option("multiline");
  }
  _dimensionChanged(dimension) {
    if ("height" === dimension) {
      return;
    }
    super._dimensionChanged();
    this._layoutStrategy._dimensionChanged();
  }
  _initMarkup() {
    super._initMarkup();
    this._updateFocusableItemsTabIndex();
    this._layoutStrategy._initMarkup();
  }
  _renderToolbar() {
    super._renderToolbar();
    this._renderLayoutStrategy();
  }
  _itemContainer() {
    if (this._isMultiline()) {
      return this._$toolbarItemsContainer;
    }
    return super._itemContainer();
  }
  _renderLayoutStrategy() {
    this.$element().toggleClass("dx-toolbar-multiline", this._isMultiline());
    this._layoutStrategy = this._isMultiline() ? new MultiLineStrategy(this) : new SingleLineStrategy(this);
  }
  _renderSections() {
    if (this._isMultiline()) {
      return;
    }
    return super._renderSections();
  }
  _postProcessRenderItems() {
    this._layoutStrategy._hideOverflowItems();
    this._layoutStrategy._updateMenuVisibility();
    super._postProcessRenderItems();
    this._layoutStrategy._renderMenuItems();
  }
  _renderItem(index, item, itemContainer, $after) {
    const itemElement = super._renderItem(index, item, itemContainer, $after);
    this._layoutStrategy._renderItem(item, itemElement);
    const {
      widget,
      showText
    } = item;
    if ("dxButton" === widget && "inMenu" === showText) {
      itemElement.toggleClass("dx-toolbar-text-auto-hide");
    }
    return itemElement;
  }
  _getItemsWidth() {
    return this._layoutStrategy._getItemsWidth();
  }
  _getMenuItems() {
    return this._layoutStrategy._getMenuItems();
  }
  _getToolbarItems() {
    return this._layoutStrategy._getToolbarItems();
  }
  _arrangeItems() {
    if (this.$element().is(":hidden")) {
      return;
    }
    const elementWidth = this._layoutStrategy._arrangeItems();
    if (!this._isMultiline()) {
      super._arrangeItems(elementWidth);
    }
  }
  _itemOptionChanged(item, property, value, prevValue) {
    if (!this._isMenuItem(item)) {
      super._itemOptionChanged(item, property, value, prevValue);
    }
    this._layoutStrategy._itemOptionChanged(item, property, value);
    if ("disabled" === property || "options.disabled" === property) {
      toggleItemFocusableElementTabIndex(this, item);
    }
    if ("location" === property) {
      this.repaint();
    }
  }
  _updateFocusableItemsTabIndex() {
    this._getToolbarItems().forEach((item) => toggleItemFocusableElementTabIndex(this, item));
  }
  _isMenuItem(itemData) {
    return "menu" === itemData.location || "always" === itemData.locateInMenu;
  }
  _isToolbarItem(itemData) {
    return void 0 === itemData.location || "never" === itemData.locateInMenu;
  }
  _optionChanged(args) {
    const {
      name,
      value
    } = args;
    this._layoutStrategy._optionChanged(name, value);
    switch (name) {
      case "menuContainer":
      case "menuItemTemplate":
      case "overflowMenuVisible":
        break;
      case "multiline":
        this._invalidate();
        break;
      case "disabled":
        super._optionChanged(args);
        this._updateFocusableItemsTabIndex();
        break;
      default:
        super._optionChanged(args);
    }
  }
  updateDimensions() {
    this._dimensionChanged();
  }
};
component_registrator_default("dxToolbar", Toolbar);
var m_toolbar_default = Toolbar;

// node_modules/devextreme/esm/ui/toolbar/ui.toolbar.js
var ui_toolbar_default = m_toolbar_default;

// node_modules/devextreme/esm/ui/toolbar.js
var toolbar_default = ui_toolbar_default;

// node_modules/devextreme-angular/fesm2022/devextreme-angular-ui-toolbar.mjs
var DxToolbarComponent = class _DxToolbarComponent extends DxComponent {
  _watcherHelper;
  _idh;
  instance = null;
  /**
   * Binds the UI component to data.
  
   */
  get dataSource() {
    return this._getOption("dataSource");
  }
  set dataSource(value) {
    this._setOption("dataSource", value);
  }
  /**
   * Specifies whether the UI component responds to user interaction.
  
   */
  get disabled() {
    return this._getOption("disabled");
  }
  set disabled(value) {
    this._setOption("disabled", value);
  }
  /**
   * Specifies the global attributes to be attached to the UI component&apos;s container element.
  
   */
  get elementAttr() {
    return this._getOption("elementAttr");
  }
  set elementAttr(value) {
    this._setOption("elementAttr", value);
  }
  /**
   * Specifies text for a hint that appears when a user pauses on the UI component.
  
   */
  get hint() {
    return this._getOption("hint");
  }
  set hint(value) {
    this._setOption("hint", value);
  }
  /**
   * Specifies whether the UI component changes its state when a user pauses on it.
  
   */
  get hoverStateEnabled() {
    return this._getOption("hoverStateEnabled");
  }
  set hoverStateEnabled(value) {
    this._setOption("hoverStateEnabled", value);
  }
  /**
   * The time period in milliseconds before the onItemHold event is raised.
  
   */
  get itemHoldTimeout() {
    return this._getOption("itemHoldTimeout");
  }
  set itemHoldTimeout(value) {
    this._setOption("itemHoldTimeout", value);
  }
  /**
   * An array of items displayed by the UI component.
  
   */
  get items() {
    return this._getOption("items");
  }
  set items(value) {
    this._setOption("items", value);
  }
  /**
   * Specifies a custom template for items.
  
   */
  get itemTemplate() {
    return this._getOption("itemTemplate");
  }
  set itemTemplate(value) {
    this._setOption("itemTemplate", value);
  }
  /**
   * Specifies a custom template for menu items.
  
   */
  get menuItemTemplate() {
    return this._getOption("menuItemTemplate");
  }
  set menuItemTemplate(value) {
    this._setOption("menuItemTemplate", value);
  }
  /**
   * Specifies whether or not the Toolbar arranges items into multiple lines when their combined width exceeds the Toolbar width.
  
   */
  get multiline() {
    return this._getOption("multiline");
  }
  set multiline(value) {
    this._setOption("multiline", value);
  }
  /**
   * Specifies the text or HTML markup displayed by the UI component if the item collection is empty.
  
   */
  get noDataText() {
    return this._getOption("noDataText");
  }
  set noDataText(value) {
    this._setOption("noDataText", value);
  }
  /**
   * Switches the UI component to a right-to-left representation.
  
   */
  get rtlEnabled() {
    return this._getOption("rtlEnabled");
  }
  set rtlEnabled(value) {
    this._setOption("rtlEnabled", value);
  }
  /**
   * Specifies whether the UI component is visible.
  
   */
  get visible() {
    return this._getOption("visible");
  }
  set visible(value) {
    this._setOption("visible", value);
  }
  /**
   * Specifies the UI component&apos;s width.
  
   */
  get width() {
    return this._getOption("width");
  }
  set width(value) {
    this._setOption("width", value);
  }
  /**
  
   * A function that is executed when the UI component is rendered and each time the component is repainted.
  
  
   */
  onContentReady;
  /**
  
   * A function that is executed before the UI component is disposed of.
  
  
   */
  onDisposing;
  /**
  
   * A function used in JavaScript frameworks to save the UI component instance.
  
  
   */
  onInitialized;
  /**
  
   * A function that is executed when a collection item is clicked or tapped.
  
  
   */
  onItemClick;
  /**
  
   * A function that is executed when a collection item is right-clicked or pressed.
  
  
   */
  onItemContextMenu;
  /**
  
   * A function that is executed when a collection item has been held for a specified period.
  
  
   */
  onItemHold;
  /**
  
   * A function that is executed after a collection item is rendered.
  
  
   */
  onItemRendered;
  /**
  
   * A function that is executed after a UI component property is changed.
  
  
   */
  onOptionChanged;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  dataSourceChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  disabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  elementAttrChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  hintChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  hoverStateEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  itemHoldTimeoutChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  itemsChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  itemTemplateChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  menuItemTemplateChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  multilineChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  noDataTextChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  rtlEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  visibleChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  widthChange;
  get itemsChildren() {
    return this._getOption("items");
  }
  set itemsChildren(value) {
    this.setChildren("items", value);
  }
  constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
    super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
    this._watcherHelper = _watcherHelper;
    this._idh = _idh;
    this._createEventEmitters([{
      subscribe: "contentReady",
      emit: "onContentReady"
    }, {
      subscribe: "disposing",
      emit: "onDisposing"
    }, {
      subscribe: "initialized",
      emit: "onInitialized"
    }, {
      subscribe: "itemClick",
      emit: "onItemClick"
    }, {
      subscribe: "itemContextMenu",
      emit: "onItemContextMenu"
    }, {
      subscribe: "itemHold",
      emit: "onItemHold"
    }, {
      subscribe: "itemRendered",
      emit: "onItemRendered"
    }, {
      subscribe: "optionChanged",
      emit: "onOptionChanged"
    }, {
      emit: "dataSourceChange"
    }, {
      emit: "disabledChange"
    }, {
      emit: "elementAttrChange"
    }, {
      emit: "hintChange"
    }, {
      emit: "hoverStateEnabledChange"
    }, {
      emit: "itemHoldTimeoutChange"
    }, {
      emit: "itemsChange"
    }, {
      emit: "itemTemplateChange"
    }, {
      emit: "menuItemTemplateChange"
    }, {
      emit: "multilineChange"
    }, {
      emit: "noDataTextChange"
    }, {
      emit: "rtlEnabledChange"
    }, {
      emit: "visibleChange"
    }, {
      emit: "widthChange"
    }]);
    this._idh.setHost(this);
    optionHost.setHost(this);
  }
  _createInstance(element, options) {
    return new toolbar_default(element, options);
  }
  ngOnDestroy() {
    this._destroyWidget();
  }
  ngOnChanges(changes) {
    super.ngOnChanges(changes);
    this.setupChanges("dataSource", changes);
    this.setupChanges("items", changes);
  }
  setupChanges(prop, changes) {
    if (!(prop in this._optionsToUpdate)) {
      this._idh.setup(prop, changes);
    }
  }
  ngDoCheck() {
    this._idh.doCheck("dataSource");
    this._idh.doCheck("items");
    this._watcherHelper.checkWatchers();
    super.ngDoCheck();
    super.clearChangedOptions();
  }
  _setOption(name, value) {
    let isSetup = this._idh.setupSingle(name, value);
    let isChanged = this._idh.getChanges(name, value) !== null;
    if (isSetup || isChanged) {
      super._setOption(name, value);
    }
  }
  /** @nocollapse */
  static ɵfac = function DxToolbarComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _DxToolbarComponent)(ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(NgZone), ɵɵdirectiveInject(DxTemplateHost), ɵɵdirectiveInject(WatcherHelper), ɵɵdirectiveInject(IterableDifferHelper), ɵɵdirectiveInject(NestedOptionHost), ɵɵdirectiveInject(TransferState), ɵɵdirectiveInject(PLATFORM_ID));
  };
  /** @nocollapse */
  static ɵcmp = ɵɵdefineComponent({
    type: _DxToolbarComponent,
    selectors: [["dx-toolbar"]],
    contentQueries: function DxToolbarComponent_ContentQueries(rf, ctx, dirIndex) {
      if (rf & 1) {
        ɵɵcontentQuery(dirIndex, DxiItemComponent, 4);
      }
      if (rf & 2) {
        let _t;
        ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.itemsChildren = _t);
      }
    },
    inputs: {
      dataSource: "dataSource",
      disabled: "disabled",
      elementAttr: "elementAttr",
      hint: "hint",
      hoverStateEnabled: "hoverStateEnabled",
      itemHoldTimeout: "itemHoldTimeout",
      items: "items",
      itemTemplate: "itemTemplate",
      menuItemTemplate: "menuItemTemplate",
      multiline: "multiline",
      noDataText: "noDataText",
      rtlEnabled: "rtlEnabled",
      visible: "visible",
      width: "width"
    },
    outputs: {
      onContentReady: "onContentReady",
      onDisposing: "onDisposing",
      onInitialized: "onInitialized",
      onItemClick: "onItemClick",
      onItemContextMenu: "onItemContextMenu",
      onItemHold: "onItemHold",
      onItemRendered: "onItemRendered",
      onOptionChanged: "onOptionChanged",
      dataSourceChange: "dataSourceChange",
      disabledChange: "disabledChange",
      elementAttrChange: "elementAttrChange",
      hintChange: "hintChange",
      hoverStateEnabledChange: "hoverStateEnabledChange",
      itemHoldTimeoutChange: "itemHoldTimeoutChange",
      itemsChange: "itemsChange",
      itemTemplateChange: "itemTemplateChange",
      menuItemTemplateChange: "menuItemTemplateChange",
      multilineChange: "multilineChange",
      noDataTextChange: "noDataTextChange",
      rtlEnabledChange: "rtlEnabledChange",
      visibleChange: "visibleChange",
      widthChange: "widthChange"
    },
    standalone: false,
    features: [ɵɵProvidersFeature([DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper]), ɵɵInheritDefinitionFeature, ɵɵNgOnChangesFeature],
    decls: 0,
    vars: 0,
    template: function DxToolbarComponent_Template(rf, ctx) {
    },
    encapsulation: 2
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DxToolbarComponent, [{
    type: Component,
    args: [{
      selector: "dx-toolbar",
      template: "",
      providers: [DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper]
    }]
  }], function() {
    return [{
      type: ElementRef
    }, {
      type: NgZone
    }, {
      type: DxTemplateHost
    }, {
      type: WatcherHelper
    }, {
      type: IterableDifferHelper
    }, {
      type: NestedOptionHost
    }, {
      type: TransferState
    }, {
      type: void 0,
      decorators: [{
        type: Inject,
        args: [PLATFORM_ID]
      }]
    }];
  }, {
    dataSource: [{
      type: Input
    }],
    disabled: [{
      type: Input
    }],
    elementAttr: [{
      type: Input
    }],
    hint: [{
      type: Input
    }],
    hoverStateEnabled: [{
      type: Input
    }],
    itemHoldTimeout: [{
      type: Input
    }],
    items: [{
      type: Input
    }],
    itemTemplate: [{
      type: Input
    }],
    menuItemTemplate: [{
      type: Input
    }],
    multiline: [{
      type: Input
    }],
    noDataText: [{
      type: Input
    }],
    rtlEnabled: [{
      type: Input
    }],
    visible: [{
      type: Input
    }],
    width: [{
      type: Input
    }],
    onContentReady: [{
      type: Output
    }],
    onDisposing: [{
      type: Output
    }],
    onInitialized: [{
      type: Output
    }],
    onItemClick: [{
      type: Output
    }],
    onItemContextMenu: [{
      type: Output
    }],
    onItemHold: [{
      type: Output
    }],
    onItemRendered: [{
      type: Output
    }],
    onOptionChanged: [{
      type: Output
    }],
    dataSourceChange: [{
      type: Output
    }],
    disabledChange: [{
      type: Output
    }],
    elementAttrChange: [{
      type: Output
    }],
    hintChange: [{
      type: Output
    }],
    hoverStateEnabledChange: [{
      type: Output
    }],
    itemHoldTimeoutChange: [{
      type: Output
    }],
    itemsChange: [{
      type: Output
    }],
    itemTemplateChange: [{
      type: Output
    }],
    menuItemTemplateChange: [{
      type: Output
    }],
    multilineChange: [{
      type: Output
    }],
    noDataTextChange: [{
      type: Output
    }],
    rtlEnabledChange: [{
      type: Output
    }],
    visibleChange: [{
      type: Output
    }],
    widthChange: [{
      type: Output
    }],
    itemsChildren: [{
      type: ContentChildren,
      args: [DxiItemComponent]
    }]
  });
})();
var DxToolbarModule = class _DxToolbarModule {
  /** @nocollapse */
  static ɵfac = function DxToolbarModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _DxToolbarModule)();
  };
  /** @nocollapse */
  static ɵmod = ɵɵdefineNgModule({
    type: _DxToolbarModule,
    declarations: [DxToolbarComponent],
    imports: [DxiItemModule, DxIntegrationModule, DxTemplateModule],
    exports: [DxToolbarComponent, DxiItemModule, DxTemplateModule]
  });
  /** @nocollapse */
  static ɵinj = ɵɵdefineInjector({
    imports: [DxiItemModule, DxIntegrationModule, DxTemplateModule, DxiItemModule, DxTemplateModule]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DxToolbarModule, [{
    type: NgModule,
    args: [{
      imports: [DxiItemModule, DxIntegrationModule, DxTemplateModule],
      declarations: [DxToolbarComponent],
      exports: [DxToolbarComponent, DxiItemModule, DxTemplateModule]
    }]
  }], null, null);
})();

export {
  toolbar_default,
  DxToolbarComponent,
  DxToolbarModule
};
/*! Bundled license information:

devextreme-angular/fesm2022/devextreme-angular-ui-toolbar.mjs:
  (*!
   * devextreme-angular
   * Version: 24.1.4
   * Build date: Mon Jul 15 2024
   *
   * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
   *
   * This software may be modified and distributed under the terms
   * of the MIT license. See the LICENSE file in the root of the project for details.
   *
   * https://github.com/DevExpress/devextreme-angular
   *)
*/
//# sourceMappingURL=chunk-T2FRFQ2E.js.map
