import {
  notify_default
} from "./chunk-EIJYND3T.js";
import "./chunk-DOIRN5IG.js";
import "./chunk-CADIH4ZJ.js";
import "./chunk-6PD6EB72.js";
import "./chunk-ZEY4S4J4.js";
import "./chunk-MM4NENTZ.js";
import "./chunk-76GCZVPW.js";
import "./chunk-MU4Z4OEA.js";
import "./chunk-RC2BNL3X.js";
import "./chunk-4BRW6FUL.js";
import "./chunk-UTUFIS2B.js";
import "./chunk-N6ESDQJH.js";
export {
  notify_default as default
};
//# sourceMappingURL=devextreme_ui_notify.js.map
