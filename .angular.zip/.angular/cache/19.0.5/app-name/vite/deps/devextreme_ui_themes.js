import {
  attachCssClasses,
  current,
  detachCssClasses,
  init,
  initialized,
  isCompact,
  isDark,
  isFluent,
  isGeneric,
  isMaterial,
  isMaterialBased,
  isPendingThemeLoaded,
  isWebFontLoaded,
  resetTheme,
  setDefaultTimeout,
  themeReady,
  themes_default,
  waitForThemeLoad,
  waitWebFont
} from "./chunk-6PD6EB72.js";
import "./chunk-76GCZVPW.js";
import "./chunk-MU4Z4OEA.js";
import "./chunk-RC2BNL3X.js";
import "./chunk-4BRW6FUL.js";
import "./chunk-UTUFIS2B.js";
import "./chunk-N6ESDQJH.js";
export {
  attachCssClasses,
  current,
  themes_default as default,
  detachCssClasses,
  init,
  initialized,
  isCompact,
  isDark,
  isFluent,
  isGeneric,
  isMaterial,
  isMaterialBased,
  isPendingThemeLoaded,
  isWebFontLoaded,
  themeReady as ready,
  resetTheme,
  setDefaultTimeout,
  waitForThemeLoad,
  waitWebFont
};
//# sourceMappingURL=devextreme_ui_themes.js.map
